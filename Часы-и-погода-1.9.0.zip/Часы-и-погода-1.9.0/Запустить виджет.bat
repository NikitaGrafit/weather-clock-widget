@echo off
rem Запуск виджета «Часы и погода» (альтернатива VBS-файлу).
setlocal
cd /d "%~dp0"

set "PYW=C:\Users\konog\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\pythonw.exe"
if not exist "%PYW%" set "PYW=%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
if not exist "%PYW%" set "PYW=%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe"
if not exist "%PYW%" set "PYW=pythonw.exe"

start "" "%PYW%" "weather_widget.py"
endlocal
