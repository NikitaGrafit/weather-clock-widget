#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Виджет рабочего стола «Часы и погода».

Запуск:
    pythonw weather_widget.py              — обычный запуск без консоли
    python  weather_widget.py --help       — параметры (отладка, скриншот)

Горячие клавиши: F5 — обновить, Ctrl+G — выбор города, Ctrl+± — масштаб, Ctrl+Q — выход.
Правая кнопка мыши — меню.
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from wclock.app import run  # noqa: E402

_MUTEX_HANDLE = None


def _single_instance_guard() -> bool:
    """True, если это первый запущенный экземпляр виджета."""
    global _MUTEX_HANDLE
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        _MUTEX_HANDLE = kernel32.CreateMutexW(None, False, "Local\\WeatherClockWidgetDSH")
        if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            return False
    except Exception:
        return True
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Виджет рабочего стола: часы и погода")
    parser.add_argument("--config", help="путь к файлу настроек (по умолчанию settings.json рядом)")
    parser.add_argument("--screenshot", help="сохранить снимок окна в файл (отладка)")
    parser.add_argument("--exit-after-screenshot", action="store_true",
                        help="закрыть виджет после снимка (отладка)")
    args = parser.parse_args()
    if not args.screenshot and not _single_instance_guard():
        print("Виджет уже запущен — второй экземпляр не нужен.")
        return 0
    run(screenshot=args.screenshot, exit_after=args.exit_after_screenshot,
        config_path=args.config)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
