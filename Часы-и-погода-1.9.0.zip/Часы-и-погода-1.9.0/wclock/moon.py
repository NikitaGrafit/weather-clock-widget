# -*- coding: utf-8 -*-
"""Фаза Луны — считается офлайн, сеть не нужна.

Возвращаем долю освещённости и короткое имя фазы, а рисование значка живёт
в `icons.draw_moon`.
"""

from __future__ import annotations

import math
from datetime import date, datetime, timedelta, timezone

# Средняя длина синодического месяца и опорное новолуние (2000-01-06 18:14 UTC)
SYNODIC_DAYS = 29.530588853
KNOWN_NEW_MOON = datetime(2000, 1, 6, 18, 14, tzinfo=timezone.utc)

PHASES = ("new", "waxing", "full", "waning")


def age_days(moment: datetime | date) -> float:
    """Сколько дней прошло с последнего новолуния (0 … 29.53)."""
    if isinstance(moment, date) and not isinstance(moment, datetime):
        moment = datetime(moment.year, moment.month, moment.day, 12, tzinfo=timezone.utc)
    elif moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    delta = moment.astimezone(timezone.utc) - KNOWN_NEW_MOON
    days = delta.total_seconds() / 86400.0
    return days % SYNODIC_DAYS


def illumination(moment: datetime | date) -> float:
    """Доля освещённого диска: 0 — новолуние, 1 — полнолуние."""
    phase = age_days(moment) / SYNODIC_DAYS          # 0 … 1
    return (1 - math.cos(2 * math.pi * phase)) / 2.0


def name(moment: datetime | date) -> str:
    """Короткое имя фазы: new | waxing | full | waning."""
    age = age_days(moment)
    if age < 1.5 or age > SYNODIC_DAYS - 1.5:
        return "new"
    if abs(age - SYNODIC_DAYS / 2) < 1.5:
        return "full"
    return "waxing" if age < SYNODIC_DAYS / 2 else "waning"


def text_key(moment: datetime | date) -> str:
    """Ключ подписи для перевода (moon.new, moon.waxing, …)."""
    return f"moon.{name(moment)}"


def next_full_moon(moment: datetime) -> datetime:
    """Когда будет ближайшее полнолуние (для карточки подробностей)."""
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    age = age_days(moment)
    remaining = (SYNODIC_DAYS / 2 - age) % SYNODIC_DAYS
    return moment + timedelta(days=remaining)
