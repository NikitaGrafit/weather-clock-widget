# -*- coding: utf-8 -*-
"""Локализация виджета: даты, длительности, единицы и коды погоды WMO.

Модуль обслуживает оба языка (русский и английский); текущий берётся из
`texts.language()`. Название файла историческое — раньше язык был один.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from . import texts

MONTHS_GENITIVE = [
    "января", "февраля", "марта", "апреля", "мая", "июня",
    "июля", "августа", "сентября", "октября", "ноября", "декабря",
]
MONTHS_NOMINATIVE = [
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
]
MONTHS_EN = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]
WEEKDAYS = [
    "понедельник", "вторник", "среда", "четверг",
    "пятница", "суббота", "воскресенье",
]
WEEKDAYS_EN = [
    "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday",
]

# Русские названия кодов погоды WMO (как их отдаёт Open-Meteo)
DESCRIPTIONS = {
    0: "Ясно",
    1: "Преимущественно ясно",
    2: "Переменная облачность",
    3: "Пасмурно",
    45: "Туман",
    48: "Изморозь, туман",
    51: "Слабая морось",
    53: "Морось",
    55: "Сильная морось",
    56: "Слабая переохлаждённая морось",
    57: "Переохлаждённая морось",
    61: "Небольшой дождь",
    63: "Дождь",
    65: "Сильный дождь",
    66: "Слабый ледяной дождь",
    67: "Ледяной дождь",
    71: "Небольшой снег",
    73: "Снег",
    75: "Сильный снег",
    77: "Снежные зёрна",
    80: "Небольшие ливни",
    81: "Ливни",
    82: "Сильные ливни",
    85: "Небольшой снегопад",
    86: "Сильный снегопад",
    95: "Гроза",
    96: "Гроза с градом",
    99: "Сильная гроза с градом",
}

# Английские названия тех же кодов
DESCRIPTIONS_EN = {
    0: "Clear",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Drizzle",
    55: "Dense drizzle",
    56: "Light freezing drizzle",
    57: "Freezing drizzle",
    61: "Slight rain",
    63: "Rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Freezing rain",
    71: "Slight snow",
    73: "Snow",
    75: "Heavy snow",
    77: "Snow grains",
    80: "Slight rain showers",
    81: "Rain showers",
    82: "Violent rain showers",
    85: "Slight snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with hail",
    99: "Thunderstorm with heavy hail",
}

SNOW_CODES = {71, 73, 75, 77, 85, 86}
SLEET_CODES = {56, 57, 66, 67}
THUNDER_CODES = {95, 96, 99}
RAIN_CODES = {51, 53, 55, 61, 63, 65, 80, 81, 82}
FOG_CODES = {45, 48}
PRECIP_CODES = SNOW_CODES | SLEET_CODES | THUNDER_CODES | RAIN_CODES

WIND_DIRECTIONS = ["С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ"]
WIND_DIRECTIONS_EN = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]


# --------------------------------------------------------------------------- даты

def format_day(dt: datetime) -> str:
    """День месяца без ведущего нуля: 5 или 25."""
    return str(dt.day)


def format_month(dt: datetime) -> str:
    """Название месяца с большой буквы: «Октября» / «October»."""
    if texts.is_english():
        return MONTHS_EN[dt.month - 1]
    return MONTHS_GENITIVE[dt.month - 1].capitalize()


def format_date_parts(dt: datetime, with_weekday: bool = True) -> tuple[str, str]:
    """Дата и день недели отдельными строками (чтобы красить их по-разному).

    Русский: «2 Октября 2026» и «(ПЯТНИЦА)».
    Английский: «2 October 2026» и «(FRIDAY)».
    """
    date_text = f"{dt.day} {format_month(dt)} {dt.year:04d}"
    if with_weekday:
        name = (WEEKDAYS_EN if texts.is_english() else WEEKDAYS)[dt.weekday()]
        weekday_text = f"({name.upper()})"
    else:
        weekday_text = ""
    return date_text, weekday_text


def format_date(dt: datetime, with_weekday: bool = False) -> str:
    """Строка даты целиком: «2 Октября 2026 (ПЯТНИЦА)»."""
    date_text, weekday_text = format_date_parts(dt, with_weekday)
    return f"{date_text} {weekday_text}" if weekday_text else date_text


def is_weekend(dt: datetime) -> bool:
    """Суббота или воскресенье."""
    return dt.weekday() >= 5


def format_hhmm(dt: datetime) -> str:
    return dt.strftime("%H:%M")


def format_clock(dt: datetime, with_seconds: bool = True, hour12: bool = False) -> str:
    """Время для больших часов: «03:42:17» или «03:42 PM» (без суффикса)."""
    pattern = "%I:%M:%S" if with_seconds else "%I:%M"
    return dt.strftime(pattern if hour12 else ("%H:%M:%S" if with_seconds else "%H:%M"))


def clock_suffix(dt: datetime, hour12: bool = False) -> str:
    """AM/PM для 12-часового формата (иначе пусто)."""
    if not hour12:
        return ""
    return texts.t("clock.pm") if dt.hour >= 12 else texts.t("clock.am")


def format_hour_label(dt: datetime, hour12: bool = False) -> str:
    """Подпись часа в почасовом ряду: «14:00» или «2 PM»."""
    if hour12:
        return dt.strftime("%I %p").lstrip("0")
    return dt.strftime("%H:00")


def plural(number: int, forms: tuple[str, str, str]) -> str:
    """forms = (1 час, 2 часа, 5 часов)."""
    n = abs(int(number)) % 100
    if 11 <= n <= 14:
        return forms[2]
    n %= 10
    if n == 1:
        return forms[0]
    if 2 <= n <= 4:
        return forms[1]
    return forms[2]


def plural_hours(number: int) -> str:
    """«4 часа» по-русски, «4 hours» по-английски."""
    if texts.is_english():
        return "hour" if abs(int(number)) == 1 else "hours"
    return plural(number, ("час", "часа", "часов"))


def format_hours_word(hours: int) -> str:
    return f"{hours} {plural_hours(hours)}"


def format_daylight(seconds: float) -> str:
    """«10 ч 24 мин» / «10 h 24 min» из секунд."""
    if seconds is None or seconds <= 0:
        return "—"
    total_minutes = int(round(seconds / 60.0))
    hours, minutes = divmod(total_minutes, 60)
    if minutes == 60:
        hours, minutes = hours + 1, 0
    if texts.is_english():
        return f"{hours} h {minutes:02d} min"
    return f"{hours} ч {minutes:02d} мин"


def format_duration(hours: float) -> str:
    """«3 ч» / «1 ч 30 мин» / «40 мин» — приблизительная длительность."""
    english = texts.is_english()
    if hours <= 0:
        return "0 h" if english else "0 ч"
    total_minutes = int(round(hours * 60))
    if total_minutes < 60:
        total_minutes = max(10, int(round(total_minutes / 10.0)) * 10)
        return f"{total_minutes} min" if english else f"{total_minutes} мин"
    whole, minutes = divmod(total_minutes, 60)
    if minutes >= 45:
        whole += 1
        minutes = 0
    if minutes and minutes < 15:
        minutes = 0
    if minutes:
        return f"{whole} h {minutes:02d} min" if english else f"{whole} ч {minutes:02d} мин"
    return f"{whole} {plural_hours(whole)}"


# --------------------------------------------------------------------------- погода

def describe(code: int) -> str:
    table = DESCRIPTIONS_EN if texts.is_english() else DESCRIPTIONS
    return table.get(int(code), "Unknown" if texts.is_english() else "Неизвестно")


def weather_kind(code: int, is_day: bool = True) -> str:
    """Ключ иконки для кода погоды с учётом дня/ночи."""
    code = int(code)
    if code in (0, 1):
        return "clear" if is_day else "clear-night"
    if code == 2:
        return "partly" if is_day else "partly-night"
    if code == 3:
        return "overcast"
    if code in FOG_CODES:
        return "fog"
    if code in (51, 53, 55):
        return "drizzle"
    if code in (56, 57, 66, 67):
        return "sleet"
    if code in (61, 63, 80, 81):
        return "rain"
    if code in (65, 82):
        return "rain-heavy"
    if code in SNOW_CODES:
        return "snow"
    if code in THUNDER_CODES:
        return "thunder"
    return "cloudy"


def precipitation_kind(code: int) -> str:
    """'rain' | 'snow' | 'sleet' | 'thunder' | 'none'."""
    code = int(code)
    if code in SNOW_CODES:
        return "snow"
    if code in SLEET_CODES:
        return "sleet"
    if code in THUNDER_CODES:
        return "thunder"
    if code in RAIN_CODES or code in FOG_CODES:
        return "rain"
    return "none"


def precipitation_noun(kind: str) -> str:
    """Название осадков на текущем языке."""
    keys = {
        "rain": "precip.rain",
        "snow": "precip.snow",
        "sleet": "precip.sleet",
        "thunder": "precip.thunder",
    }
    return texts.t(keys.get(kind, "precip.fallback"))


ICON_FOR_PRECIP = {
    "rain": "rain",
    "snow": "snow",
    "sleet": "sleet",
    "thunder": "thunder",
    "none": "cloudy",
}


def format_temperature(value: float, with_sign: bool = True) -> str:
    if value is None:
        return "—"
    text = f"{value:+.0f}" if with_sign else f"{value:.0f}"
    return text.replace("-", "\u2212") + "\u00b0"


def format_wind(direction: float, speed: float) -> str:
    if direction is None or speed is None:
        return "—"
    index = int((direction % 360) / 45.0 + 0.5) % 8
    directions = WIND_DIRECTIONS_EN if texts.is_english() else WIND_DIRECTIONS
    unit = "m/s" if texts.is_english() else "м/с"
    return f"{speed:.0f} {unit} ({directions[index]})"


def format_pressure(hpa: float) -> str:
    if not hpa:
        return "—"
    if texts.is_english():
        return f"{hpa * 0.750062:.0f} mmHg"
    return f"{hpa * 0.750062:.0f} мм рт. ст."


# --------------------------------------------------------------------------- время дня

DAYPART_LABELS = {
    "dawn": "Утро",
    "day": "День",
    "dusk": "Вечер",
    "night": "Ночь",
}

DAYPART_LABELS_EN = {
    "dawn": "Morning",
    "day": "Day",
    "dusk": "Evening",
    "night": "Night",
}

DAYPART_ICONS = {
    "dawn": "sunrise",
    "day": "sun",
    "dusk": "sunset",
    "night": "moon",
}


def daypart(now: datetime, sunrise: datetime | None, sunset: datetime | None) -> str:
    """Время дня по восходу/закату: dawn | day | dusk | night."""
    if sunrise is None or sunset is None:
        return daypart_by_hour(now.hour)
    # восход и закат могли прийти за другой день (например, из кэша) — тогда
    # ориентируемся на час, иначе днём показывалась бы «ночь»
    if sunrise.date() != now.date() or sunset.date() != now.date():
        return daypart_by_hour(now.hour)
    dawn_start = sunrise - timedelta(minutes=45)
    morning_end = sunrise + timedelta(hours=1)
    evening_start = sunset - timedelta(hours=1)
    dusk_end = sunset + timedelta(minutes=45)
    try:
        if dawn_start <= now < morning_end:
            return "dawn"
        if morning_end <= now < evening_start:
            return "day"
        if evening_start <= now <= dusk_end:
            return "dusk"
    except TypeError:  # несравнимые datetime (наивный и aware)
        return daypart_by_hour(now.hour)
    return "night"


def daypart_by_hour(hour: int) -> str:
    if 5 <= hour < 11:
        return "dawn"
    if 11 <= hour < 17:
        return "day"
    if 17 <= hour < 22:
        return "dusk"
    return "night"


def daypart_label(key: str) -> str:
    table = DAYPART_LABELS_EN if texts.is_english() else DAYPART_LABELS
    return table.get(key, "")


def daypart_icon(key: str) -> str:
    return DAYPART_ICONS.get(key, "sun")
