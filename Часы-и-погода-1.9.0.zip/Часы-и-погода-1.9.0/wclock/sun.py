# -*- coding: utf-8 -*-
"""Расчёт восхода и заката без обращения к сети (уравнение восхода, NOAA).

Нужен для источника MET Norway (он не отдаёт времена восхода/заката) и как
страховка, если метеослужба вернула неполные суточные данные.
"""

from __future__ import annotations

import math
from datetime import date, datetime, timedelta, timezone

J2000 = 2451545.0
J2000_EPOCH = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
RAD = math.pi / 180.0
# поправка на рефракцию и видимый диск Солнца
SUN_ALTITUDE = -0.833


def _to_radians(degrees: float) -> float:
    return degrees * RAD


def _julian_to_datetime(julian: float, tzinfo) -> datetime:
    moment = J2000_EPOCH + timedelta(days=julian - J2000)
    return moment.astimezone(tzinfo)


def sun_times(day: date, latitude: float, longitude: float, tzinfo):
    """Восход и закат для даты и координат в часовом поясе tzinfo.

    Возвращает (sunrise, sunset) либо (None, None) в полярный день и полярную ночь.
    """
    if latitude is None or longitude is None:
        return None, None
    latitude = max(-89.8, min(89.8, float(latitude)))
    # число дней от 2000-01-01: для 1 января 2000 года должно быть 0,
    # иначе восход и закат уезжают на сутки вперёд
    order = day.toordinal() - date(2000, 1, 1).toordinal()
    mean_solar_time = order - longitude / 360.0

    mean_anomaly = (357.5291 + 0.98560028 * mean_solar_time) % 360.0
    m_rad = _to_radians(mean_anomaly)
    center = (1.9148 * math.sin(m_rad) + 0.0200 * math.sin(2 * m_rad)
              + 0.0003 * math.sin(3 * m_rad))
    ecliptic_longitude = (mean_anomaly + center + 180.0 + 102.9372) % 360.0
    lam_rad = _to_radians(ecliptic_longitude)

    transit = (J2000 + mean_solar_time + 0.0053 * math.sin(m_rad)
               - 0.0069 * math.sin(2 * lam_rad))
    declination = math.asin(math.sin(lam_rad) * math.sin(_to_radians(23.4397)))

    try:
        cos_hour_angle = (
            (math.sin(_to_radians(SUN_ALTITUDE))
             - math.sin(_to_radians(latitude)) * math.sin(declination))
            / (math.cos(_to_radians(latitude)) * math.cos(declination))
        )
    except ZeroDivisionError:
        return None, None
    if cos_hour_angle > 1 or cos_hour_angle < -1:
        return None, None  # полярная ночь или полярный день

    hour_angle = math.degrees(math.acos(cos_hour_angle))
    sunrise = _julian_to_datetime(transit - hour_angle / 360.0, tzinfo)
    sunset = _julian_to_datetime(transit + hour_angle / 360.0, tzinfo)
    return sunrise, sunset


def daylight_seconds(day: date, latitude: float, longitude: float, tzinfo) -> float:
    sunrise, sunset = sun_times(day, latitude, longitude, tzinfo)
    if sunrise is None or sunset is None:
        return 0.0
    return max(0.0, (sunset - sunrise).total_seconds())
