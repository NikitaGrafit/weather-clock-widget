# -*- coding: utf-8 -*-
"""Настройки виджета и кэш последнего прогноза (settings.json рядом с программой)."""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

from .api import City

APP_DIR = Path(__file__).resolve().parent.parent
CONFIG_NAME = "settings.json"
FALLBACK_DIR = Path(os.environ.get("APPDATA") or Path.home()) / "WeatherClockWidget"

DEFAULT_OPTIONS = {
    "topmost": True,
    "frameless": True,
    "seconds": True,
    "weekday": True,
    "hourly": True,
    "rounded": True,
    "alpha": 1.0,            # прозрачность содержимого (текст, иконки)
    "plate_alpha": 0.92,     # прозрачность подложки: 0 — подложки нет
    "plate_top": None,       # цвет подложки сверху, «#RRGGBB» (None — из темы)
    "plate_bottom": None,    # цвет подложки снизу, «#RRGGBB» (None — из темы)
    "clock_font": None,      # шрифт времени (None — моноширинный по умолчанию)
    "language": "ru",        # язык интерфейса: ru или en
    "hour12": False,         # 12-часовой формат времени вместо 24-часового
    "traffic": True,         # показывать блок пробок (тестовый режим)
    "icon_style": "mono",    # стиль иконок погоды: mono или vivid
    "text_outline": False,   # тёмная обводка текста (для светлых обоев)
    "tomorrow": True,        # строка «Завтра: …»
    "sun_countdown": True,   # вместо времени восхода — отсчёт до заката
    "week_number": True,     # «· неделя 40» в строке даты
    "moon_phase": True,      # значок фазы Луны рядом с датой
    "hourly_count": 8,       # сколько часов показывать в почасовом ряду
    "skip_update": "",       # версия, о которой больше не напоминать
    "night_dim": True,       # ночью приглушать виджет
    "hide_fullscreen": True,  # прятаться, когда на весь экран идёт игра или фильм
    "hotkey": True,          # Ctrl+Alt+W — показать или спрятать
    "zoom": 1.0,
}

# Пресеты вида: меняют только оформление, не трогая город, цвета и шрифт
PRESETS = {
    "minimal": {
        "seconds": False, "weekday": False, "hourly": False, "traffic": False,
        "tomorrow": False, "sun_countdown": False, "week_number": False,
        "moon_phase": False, "hourly_count": 6,
    },
    "normal": {
        "seconds": True, "weekday": True, "hourly": True, "traffic": True,
        "tomorrow": True, "sun_countdown": True, "week_number": True,
        "moon_phase": True, "hourly_count": 8,
    },
    "detailed": {
        "seconds": True, "weekday": True, "hourly": True, "traffic": True,
        "tomorrow": True, "sun_countdown": True, "week_number": True,
        "moon_phase": True, "hourly_count": 12,
    },
}
PRESET_ORDER = ("minimal", "normal", "detailed")
HOURLY_CHOICES = (6, 8, 12)

DEFAULT_GEOMETRY = ""


class Config:
    """Простое хранилище настроек с отказоустойчивой записью."""

    def __init__(self, path: Path | str | None = None):
        self.path = Path(path) if path else APP_DIR / CONFIG_NAME
        self.data: dict = {}
        self.load()

    # -- чтение/запись -----------------------------------------------------
    def load(self) -> None:
        try:
            # utf-8-sig — на случай, если файл сохранили в Блокноте (он добавляет BOM)
            with open(self.path, "r", encoding="utf-8-sig") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                self.data = loaded
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            self.data = {}
        self.data.setdefault("options", {})
        self.data.setdefault("refresh_minutes", 10)
        self.data.setdefault("geometry", DEFAULT_GEOMETRY)
        for key, value in DEFAULT_OPTIONS.items():
            self.data["options"].setdefault(key, value)
        self._migrate()

    def _migrate(self) -> None:
        """Настройки старого образца: прозрачность гасила виджет целиком.

        Теперь прозрачностью заведует отдельная подложка, поэтому «прозрачность
        содержимого» возвращаем к 100 %, иначе текст остаётся бледным.
        """
        options = self.data["options"]
        if self.data.get("_plate_migrated"):
            return
        self.data["_plate_migrated"] = True
        try:
            if float(options.get("alpha") or 1.0) < 1.0:
                options["alpha"] = 1.0
        except (TypeError, ValueError):
            options["alpha"] = 1.0

    def save(self) -> None:
        target = self.path
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            self._atomic_write(target)
        except OSError:
            try:
                FALLBACK_DIR.mkdir(parents=True, exist_ok=True)
                self._atomic_write(FALLBACK_DIR / CONFIG_NAME)
                self.path = FALLBACK_DIR / CONFIG_NAME
            except OSError:
                pass

    def _atomic_write(self, target: Path) -> None:
        payload = json.dumps(self.data, ensure_ascii=False, indent=2)
        directory = str(target.parent)
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=directory,
                                         delete=False, suffix=".tmp") as handle:
            handle.write(payload)
            temp_name = handle.name
        os.replace(temp_name, target)

    # -- опции -------------------------------------------------------------
    @property
    def options(self) -> dict:
        return self.data["options"]

    def option(self, key: str, default=None):
        return self.options.get(key, DEFAULT_OPTIONS.get(key, default))

    def set_option(self, key: str, value) -> None:
        self.options[key] = value

    @property
    def refresh_minutes(self) -> int:
        try:
            return max(1, int(self.data.get("refresh_minutes", 10)))
        except (TypeError, ValueError):
            return 10

    # -- город -------------------------------------------------------------
    @property
    def city(self) -> City | None:
        raw = self.data.get("city")
        if isinstance(raw, dict) and raw.get("name"):
            return City.from_dict(raw)
        return None

    @city.setter
    def city(self, value: City) -> None:
        self.data["city"] = value.to_dict()

    # -- геометрия окна ----------------------------------------------------
    @property
    def geometry(self) -> str:
        return str(self.data.get("geometry") or DEFAULT_GEOMETRY)

    @geometry.setter
    def geometry(self, value: str) -> None:
        self.data["geometry"] = value

    # -- второй город ------------------------------------------------------
    @property
    def alt_city(self) -> City | None:
        raw = self.data.get("city_alt")
        if not isinstance(raw, dict):
            return None
        try:
            return City.from_dict(raw)
        except Exception:                       # noqa: BLE001 — старые настройки
            return None

    def set_alt_city(self, value: City | None) -> None:
        if value is None:
            self.data.pop("city_alt", None)
        else:
            self.data["city_alt"] = value.to_dict()
        self.save()

    # -- кэш прогноза ------------------------------------------------------
    def store_cache(self, raw: dict) -> None:
        self.data["cache"] = {
            "fetched_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "raw": raw,
        }

    def load_cache(self):
        cache = self.data.get("cache")
        if not isinstance(cache, dict) or not isinstance(cache.get("raw"), dict):
            return None
        return cache["raw"], cache.get("fetched_at")
