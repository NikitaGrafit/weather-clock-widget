# -*- coding: utf-8 -*-
"""Общая основа окон виджета: без рамки, со скруглением, в цветах темы.

Системные окна с заголовком выбиваются из стиля виджета, поэтому все
диалоги (город, цвет фона, справка) строятся на этом классе: панель
рисуется на Canvas, углы вырезаются по цвету-ключу, окно перетаскивается
мышью за заголовок, закрывается крестиком или Esc.
"""

from __future__ import annotations

import tkinter as tk
from typing import Callable

from . import icons, theme

RADIUS = 14
PAD = 20
TITLE_HEIGHT = 42


class ModernDialog:
    """Окно в стиле виджета. Содержимое кладётся в `self.body`."""

    def __init__(self, parent: tk.Misc, title: str, palette: dict | None = None,
                 topmost: bool = True):
        self.palette = dict(palette or theme.palette("night"))
        self.title = title
        self.parent = parent
        self.closed = False
        self._drag = None
        self._on_close: Callable[[], None] | None = None

        bg = self.palette.get("bg_top", "#0d1729")
        self.panel = self.palette.get("bg_bottom", "#141c33")
        self.text_color = self.palette.get("text", "#eaf2ff")
        self.muted = self.palette.get("muted", "#9db0d2")
        self.accent = self.palette.get("accent", "#5fb0ff")
        self.divider = self.palette.get("divider", "#283a5c")

        self.key = theme.pick_key(self.palette)
        self.window = tk.Toplevel(parent)
        self.window.withdraw()
        self.window.overrideredirect(True)
        try:
            self.window.configure(bg=self.key)
            self.window.attributes("-transparentcolor", self.key)
            if topmost:
                self.window.attributes("-topmost", True)
        except tk.TclError:
            pass

        self.canvas = tk.Canvas(self.window, highlightthickness=0, bd=0, bg=self.key)
        self.canvas.pack(fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=self.panel)
        self.canvas.bind("<Button-1>", self._start_drag)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", lambda event: setattr(self, "_drag", None))
        self.window.bind("<Escape>", lambda event: self.close())
        # системное закрытие (например, завершение работы Windows) тоже закрывает окно
        self.window.protocol("WM_DELETE_WINDOW", self.close)

    # ------------------------------------------------------------------ размеры
    def fit(self, width: int | None = None) -> None:
        """Подогнать окно под содержимое (вызывается после сборки body)."""
        self.body.update_idletasks()
        body_w = width or self.body.winfo_reqwidth()
        body_h = self.body.winfo_reqheight()
        self.width = int(body_w + PAD * 2)
        self.height = int(body_h + TITLE_HEIGHT + PAD)
        self.canvas.configure(width=self.width, height=self.height)
        self._draw(body_w, body_h)

    def _draw(self, body_w: int, body_h: int) -> None:
        canvas = self.canvas
        canvas.delete("all")
        canvas.create_polygon(
            icons.rounded_points(0.5, 0.5, self.width - 0.5, self.height - 0.5, RADIUS),
            fill=self.panel, outline=self.divider, width=1, smooth=True, tags="panel")
        title_font = ("Segoe UI", 11, "bold")
        canvas.create_text(PAD, TITLE_HEIGHT / 2.0 + 2, text=self.title, anchor="w",
                           font=title_font, fill=self.text_color, tags="title")
        # крестик закрытия
        cx, cy = self.width - PAD - 4, TITLE_HEIGHT / 2.0 + 1
        self._close_rect = (cx - 11, cy - 11, cx + 11, cy + 11)
        canvas.create_text(cx, cy, text="\u2715", font=("Segoe UI", 11),
                           fill=self.muted, tags="close")
        canvas.tag_bind("close", "<Button-1>", lambda event: self.close())
        canvas.tag_bind("close", "<Enter>",
                        lambda event: canvas.itemconfigure("close", fill=self.accent))
        canvas.tag_bind("close", "<Leave>",
                        lambda event: canvas.itemconfigure("close", fill=self.muted))
        canvas.create_line(PAD, TITLE_HEIGHT - 6, self.width - PAD, TITLE_HEIGHT - 6,
                           fill=self.divider, tags="title")
        self._body_window = canvas.create_window(PAD, TITLE_HEIGHT, window=self.body,
                                                 anchor="nw", width=body_w, height=body_h)

    # ------------------------------------------------------------------ показ
    def show(self, modal: bool = True) -> None:
        width = getattr(self, "width", 400)
        height = getattr(self, "height", 300)
        try:
            screen_w = self.window.winfo_screenwidth()
            screen_h = self.window.winfo_screenheight()
        except tk.TclError:
            screen_w, screen_h = 1920, 1080
        x = int((screen_w - width) / 2)
        y = int((screen_h - height) / 3)
        self.window.geometry(f"{width}x{height}+{x}+{y}")
        self.window.deiconify()
        self.window.lift()
        try:
            self.window.focus_force()
            if modal:
                self.window.grab_set()
        except tk.TclError:
            pass

    def wait(self) -> None:
        self.parent.wait_window(self.window)

    def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        try:
            self.window.grab_release()
        except tk.TclError:
            pass
        try:
            self.window.destroy()
        except tk.TclError:
            pass
        if self._on_close is not None:
            self._on_close()

    # ------------------------------------------------------------------ перетаскивание
    def _start_drag(self, event) -> None:
        # за крестик не тащим
        left, top, right, bottom = self._close_rect
        if left <= event.x <= right and top <= event.y <= bottom:
            return
        self._drag = (event.x_root - self.window.winfo_x(),
                      event.y_root - self.window.winfo_y())

    def _on_drag(self, event) -> None:
        if not self._drag:
            return
        dx, dy = self._drag
        self.window.geometry(f"+{event.x_root - dx}+{event.y_root - dy}")


def dialog_palette(base: dict | None = None) -> dict:
    """Палитра для диалогов: та же, что у виджета."""
    palette = dict(base or theme.palette("night"))
    palette.setdefault("bg_top", "#0d1729")
    palette.setdefault("bg_bottom", "#141c33")
    return palette
