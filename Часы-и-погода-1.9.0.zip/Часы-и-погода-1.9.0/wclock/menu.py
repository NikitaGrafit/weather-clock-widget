# -*- coding: utf-8 -*-
"""Современное меню виджета: своя отрисовка вместо системного tk.Menu.

Панель со скруглёнными углами и полупрозрачностью, подсветка пункта под
курсором, галочки и радиокнопки, всплывающие подменю, появление с плавным
проявлением. Всё рисуется на Canvas, поэтому меню выглядит как часть виджета,
а не как системное окно.
"""

from __future__ import annotations

import tkinter as tk
from dataclasses import dataclass, field
from typing import Callable

from . import icons, theme

TRANSPARENT_CANDIDATES = ("#ff00ff", "#00ff7f", "#010203", "#f0f")

PANEL_RADIUS = 12
HOVER_RADIUS = 8
SIDE_PAD = 10
ITEM_PAD = 9
INDICATOR_WIDTH = 18
SUBMENU_DELAY_MS = 110
FADE_STEPS = 5
FADE_INTERVAL_MS = 14


@dataclass
class MenuItem:
    """Пункт меню: обычный, галочка, радиокнопка, разделитель или подменю."""

    label: str = ""
    kind: str = "command"          # command | check | radio | separator | cascade
    command: Callable[[], None] | None = None
    is_active: Callable[[], bool] | None = None
    shortcut: str = ""
    submenu: "ModernMenu | None" = None
    enabled: bool = True
    hint: str = ""
    on_hover: Callable[[], None] | None = None
    height: int = 0
    width: int = 0
    children: list = field(default_factory=list)


class ModernMenu:
    """Одно окно меню (уровень). Подменю — другие экземпляры ModernMenu."""

    def __init__(self, master: tk.Misc, fonts: dict, pal: dict, topmost: bool = True,
                 on_close: Callable[[], None] | None = None, root_menu: bool = True,
                 on_show: Callable[[], None] | None = None):
        self.master = master
        self.fonts = fonts
        self.pal = pal
        self.topmost = topmost
        self.on_close = on_close
        self.on_show = on_show
        self.is_root = root_menu
        self.items: list[MenuItem] = []
        self.width = 0
        self.height = 0
        self.hover = -1
        self._open_index = -1
        self._pending = None
        self._closing = False

        self.window = tk.Toplevel(master)
        self.window.withdraw()
        self.window.overrideredirect(True)
        self.key = self._pick_key(pal)
        try:
            self.window.configure(bg=self.key)
            self.window.attributes("-transparentcolor", self.key)
            if topmost:
                self.window.attributes("-topmost", True)
            self.window.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        self.canvas = tk.Canvas(self.window, highlightthickness=0, bd=0, bg=self.key,
                                takefocus=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Motion>", self._on_motion)
        self.canvas.bind("<Button-1>", self._on_click)
        self.canvas.bind("<Leave>", self._on_leave)

    # ------------------------------------------------------------------ сборка
    def add(self, item: MenuItem) -> MenuItem:
        self.items.append(item)
        return item

    def add_command(self, label: str, command=None, shortcut: str = "",
                    enabled: bool = True) -> MenuItem:
        return self.add(MenuItem(label=label, kind="command", command=command,
                                 shortcut=shortcut, enabled=enabled))

    def add_check(self, label: str, command=None, is_active=None) -> MenuItem:
        return self.add(MenuItem(label=label, kind="check", command=command,
                                 is_active=is_active))

    def add_radio(self, label: str, command=None, is_active=None,
                  on_hover=None) -> MenuItem:
        return self.add(MenuItem(label=label, kind="radio", command=command,
                                 is_active=is_active, on_hover=on_hover))

    def add_separator(self) -> MenuItem:
        return self.add(MenuItem(kind="separator"))

    def add_cascade(self, label: str, submenu: "ModernMenu") -> MenuItem:
        return self.add(MenuItem(label=label, kind="cascade", submenu=submenu))

    def clear(self) -> None:
        self.items.clear()
        self._open_index = -1

    # ------------------------------------------------------------------ раскладка
    def _pick_key(self, pal: dict) -> str:
        """Цвет-ключ: любой, которого нет среди рисуемых цветов."""
        used = {value.lower() for value in pal.values() if isinstance(value, str)}
        for candidate in TRANSPARENT_CANDIDATES:
            if candidate.lower() not in used:
                return candidate
        return "#ff00ff"

    def measure(self) -> None:
        """Посчитать размеры пунктов и всего окна."""
        label_font = self.fonts["label"]
        small_font = self.fonts["small"]
        item_h = max(26, int(label_font.metrics("linespace") * 1.95))
        separator_h = max(7, item_h // 4)
        width = 0
        for item in self.items:
            if item.kind == "separator":
                item.height, item.width = separator_h, 0
                continue
            item.height = item_h
            text_width = label_font.measure(item.label)
            extra = INDICATOR_WIDTH
            if item.shortcut:
                extra += small_font.measure(item.shortcut) + 18
            if item.kind == "cascade":
                extra += 16
            item.width = text_width + extra
            width = max(width, item.width)
        pad = SIDE_PAD * 2
        self.width = max(150, width + pad)
        self.height = sum(item.height for item in self.items) + SIDE_PAD
        self.canvas.configure(width=self.width, height=self.height)

    # ------------------------------------------------------------------ отрисовка
    def draw(self) -> None:
        canvas = self.canvas
        canvas.delete("all")
        icons.draw_background(canvas, self.width, self.height, self.pal, PANEL_RADIUS,
                              tag="panel", top=self.pal["panel"], bottom=self.pal["panel"])
        canvas.create_polygon(
            icons.rounded_points(0.5, 0.5, self.width - 0.5, self.height - 0.5,
                                 PANEL_RADIUS),
            fill="", outline=self.pal["border"], width=1, smooth=True, tags="panel")
        label_font = self.fonts["label"]
        small_font = self.fonts["small"]
        y = SIDE_PAD / 2.0
        for index, item in enumerate(self.items):
            if item.kind == "separator":
                yy = y + item.height / 2.0
                canvas.create_line(SIDE_PAD, yy, self.width - SIDE_PAD, yy,
                                   fill=self.pal["divider"], tags="item")
                y += item.height
                continue
            active = (index == self.hover)
            if active and item.enabled:
                canvas.create_polygon(
                    icons.rounded_points(4, y + 2, self.width - 4, y + item.height - 2,
                                         HOVER_RADIUS),
                    fill=self.pal["hover"], outline=self.pal["hover"], smooth=True,
                    tags="item")
            fill = self.pal["text"] if item.enabled else self.pal["muted"]
            if active and item.enabled:
                fill = self.pal["accent"]
            cy = y + item.height / 2.0
            # индикатор галочки или радиокнопки
            if item.kind in ("check", "radio"):
                checked = bool(item.is_active and item.is_active())
                cx = SIDE_PAD + INDICATOR_WIDTH / 2.0 - 2
                color = self.pal["accent"] if checked else self.pal["muted"]
                if item.kind == "radio":
                    radius = 5
                    canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius,
                                       outline=color, width=1, tags="item")
                    if checked:
                        inner = 2.4
                        canvas.create_oval(cx - inner, cy - inner, cx + inner, cy + inner,
                                           fill=color, outline=color, tags="item")
                else:
                    canvas.create_polygon(
                        cx - 5, cy, cx - 1.5, cy + 4, cx + 5, cy - 4.5,
                        fill="", outline=color, width=2, smooth=True, tags="item")
            canvas.create_text(SIDE_PAD + INDICATOR_WIDTH, cy, text=item.label,
                               anchor="w", font=label_font, fill=fill, tags="item")
            if item.shortcut:
                canvas.create_text(self.width - SIDE_PAD - (16 if item.kind == "cascade" else 0),
                                   cy, text=item.shortcut, anchor="e", font=small_font,
                                   fill=self.pal["muted"], tags="item")
            if item.kind == "cascade":
                canvas.create_text(self.width - SIDE_PAD - 2, cy, text="\u203a",
                                   anchor="e", font=label_font, fill=self.pal["muted"],
                                   tags="item")
            y += item.height

    # ------------------------------------------------------------------ показ
    def popup(self, x: int, y: int, parent: "ModernMenu | None" = None) -> None:
        self.measure()
        self.draw()
        x, y = self._fit_on_screen(x, y)
        self.window.geometry(f"{self.width}x{self.height}+{x}+{y}")
        self.window.deiconify()
        self.window.lift()
        # меню — topmost-окно: после показа порядок окон у виджета мог поменяться
        if self.on_show is not None:
            self.on_show()
        if self.is_root:
            self._fade_in()
        else:
            # подменю показываем сразу: ждать проявления при переходе не нужно
            try:
                self.window.attributes("-alpha", 0.99)
            except tk.TclError:
                pass
        if self.is_root:
            self._fade_in()
            try:
                self.window.focus_force()
                self.window.bind("<Escape>", lambda event: self.close_all())
                self.window.bind("<FocusOut>", self._on_focus_out)
                self.window.bind_all("<Button-1>", self._on_global_click, add="+")
            except tk.TclError:
                pass

    def _fit_on_screen(self, x: int, y: int) -> tuple[int, int]:
        try:
            screen_w = self.window.winfo_screenwidth()
            screen_h = self.window.winfo_screenheight()
        except tk.TclError:
            return x, y
        if x + self.width > screen_w - 4:
            x = max(4, screen_w - self.width - 4)
        if y + self.height > screen_h - 4:
            y = max(4, screen_h - self.height - 4)
        return int(x), int(y)

    def _fade_in(self) -> None:
        def step(index: int) -> None:
            if self._closing or not self.window.winfo_exists():
                return
            try:
                self.window.attributes("-alpha", 0.99 * index / FADE_STEPS)
            except tk.TclError:
                return
            if index < FADE_STEPS:
                self.window.after(FADE_INTERVAL_MS, lambda: step(index + 1))

        step(1)

    # ------------------------------------------------------------------ события
    def _item_at(self, x: float, y: float) -> int:
        top = SIDE_PAD / 2.0
        for index, item in enumerate(self.items):
            if item.kind == "separator":
                top += item.height
                continue
            if top <= y <= top + item.height and 4 <= x <= self.width - 4:
                return index
            top += item.height
        return -1

    def _on_motion(self, event) -> None:
        index = self._item_at(event.x, event.y)
        if index != self.hover:
            self.hover = index
            self.draw()
            item = self.items[index] if index >= 0 else None
            if item is not None and item.on_hover is not None:
                item.on_hover()
            self._handle_submenu(index)

    def _on_leave(self, event=None) -> None:
        # курсор ушёл с панели: гасим подсветку, подменю оставляем открытым
        if self.hover != -1:
            self.hover = -1
            self.draw()

    def _handle_submenu(self, index: int) -> None:
        if self._pending is not None:
            try:
                self.window.after_cancel(self._pending)
            except (tk.TclError, ValueError):
                pass
            self._pending = None
        item = self.items[index] if index >= 0 else None
        if item is None or item.kind != "cascade" or item.submenu is None:
            if self._open_index >= 0:
                self._close_children()
            self._open_index = -1
            return
        if index == self._open_index:
            return
        self._close_children()
        self._open_index = index

        def open_it() -> None:
            self._pending = None
            if self._open_index != index or not self.window.winfo_exists():
                return
            y = SIDE_PAD / 2.0 + sum(entry.height for entry in self.items[:index])
            item.submenu.popup(self.window.winfo_x() + self.width - 8,
                               self.window.winfo_y() + int(y) - 4, parent=self)

        self._pending = self.window.after(SUBMENU_DELAY_MS, open_it)

    def _close_children(self) -> None:
        for item in self.items:
            if item.submenu is not None:
                item.submenu.close_all(notify=False)

    def _on_click(self, event) -> None:
        index = self._item_at(event.x, event.y)
        if index < 0:
            return
        item = self.items[index]
        if item.kind == "cascade":
            self._handle_submenu(index)
            return
        if not item.enabled:
            return
        if item.command is not None:
            item.command()
        self.close_all()

    def _on_global_click(self, event) -> None:
        """Клик вне окна меню — закрыть (меню в своём окне без grab)."""
        if self._closing:
            return
        try:
            widget = event.widget
            top = widget.winfo_toplevel()
        except (AttributeError, tk.TclError):
            return
        if top is self.window:
            return
        self.close_all()

    def _on_focus_out(self, event=None) -> None:
        if self._closing:
            return
        self.close_all()

    # ------------------------------------------------------------------ закрытие
    def close_all(self, notify: bool = True) -> None:
        if self._closing:
            return
        self._closing = True
        if self._pending is not None:
            try:
                self.window.after_cancel(self._pending)
            except (tk.TclError, ValueError):
                pass
            self._pending = None
        self._close_children()
        if self.is_root:
            try:
                self.window.unbind_all("<Button-1>")
            except tk.TclError:
                pass
        try:
            self.window.withdraw()
            self.window.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        self.hover = -1
        self._open_index = -1
        self._closing = False
        if notify and self.on_close is not None:
            self.on_close()

    def destroy(self) -> None:
        self._close_children()
        for item in self.items:
            if item.submenu is not None:
                item.submenu.destroy()
        try:
            self.window.destroy()
        except tk.TclError:
            pass


def build_palette(base: dict, light: bool = False) -> dict:
    """Цвета меню: берём палитру виджета и добавляем фон панели и подсветку."""
    panel = theme.mix(base["bg_top"], "#ffffff" if not light else "#ffffff", 0.10)
    if light:
        panel = theme.mix(base["bg_top"], "#ffffff", 0.0)
    highlight = theme.mix(panel, base["accent"], 0.22)
    return {
        "panel": panel,
        "hover": highlight,
        "text": base["text"],
        "muted": base["muted"],
        "accent": base["accent"],
        "divider": base["divider"],
        "border": base["border"],
    }
