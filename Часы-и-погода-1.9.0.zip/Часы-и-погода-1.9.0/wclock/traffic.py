# -*- coding: utf-8 -*-
"""Пробки в городе: баллы (0–10) от сервиса Яндекса.

Запрос идёт по координатам города и не требует ключа API: сервис сам
определяет город и отдаёт баллы, цвет и подпись (в том числе по-английски).
Если сервис недоступен, в тестовом режиме показываются демонстрационные
баллы, чтобы было видно, как блок выглядит.
"""

from __future__ import annotations

import random
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ElementTree
from dataclasses import dataclass
from datetime import datetime, timedelta

from . import texts

ENDPOINT = "https://export.yandex.ru/bar/reginfo.xml"
USER_AGENT = "WeatherClockWidget/1.1 (+desktop widget)"
TIMEOUT = 6.0
DEMO_LIFETIME = timedelta(minutes=10)

# Границы цветов как у Яндекса: 0–3 свободно, 4–6 затруднения, 7–10 пробки
FREE_MAX = 3
HEAVY_MIN = 7

_demo_cache: dict = {}


@dataclass
class TrafficData:
    """Баллы пробок в городе."""

    level: int = 0
    icon: str = "green"
    hint: str = ""
    hint_en: str = ""
    time_text: str = ""
    trend: int = 0
    region: str = ""
    url: str = ""
    source: str = "Яндекс"
    demo: bool = False
    fetched_at: datetime | None = None

    def word(self) -> str:
        """Словесная оценка загруженности."""
        if self.level <= FREE_MAX:
            return texts.t("traffic.free")
        if self.level < HEAVY_MIN:
            return texts.t("traffic.busy")
        return texts.t("traffic.jam")

    def title(self) -> str:
        """Подпись блока: «Пробки: 6 из 10»."""
        return texts.t("traffic.title", level=self.level)

    def description(self) -> str:
        """Пояснение сервиса на текущем языке (если есть)."""
        if texts.is_english() and self.hint_en:
            return self.hint_en
        return self.hint or self.word()

    def color(self) -> str:
        """Цвет индикатора по баллам."""
        if self.level <= FREE_MAX:
            return "#4ecb71"
        if self.level < HEAVY_MIN:
            return "#ffc857"
        return "#ff6b6b"

    def trend_text(self) -> str:
        if self.trend > 0:
            return texts.t("traffic.growing")
        if self.trend < 0:
            return texts.t("traffic.falling")
        return ""


def score_from_coords(lat: float, lon: float, timeout: float = TIMEOUT) -> TrafficData | None:
    """Запросить баллы пробок у сервиса по координатам города."""
    query = urllib.parse.urlencode({"lat": f"{lat:.4f}", "lon": f"{lon:.4f}"})
    request = urllib.request.Request(f"{ENDPOINT}?{query}",
                                     headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = response.read()
    except (urllib.error.URLError, TimeoutError, OSError):
        return None
    return parse(payload)


def parse(payload: bytes | str) -> TrafficData | None:
    """Разобрать ответ сервиса (XML) в TrafficData."""
    try:
        root = ElementTree.fromstring(payload)
    except ElementTree.ParseError:
        return None
    region_node = root.find("traffic/region")
    if region_node is None:
        region_node = root.find("region")
    if region_node is None:
        return None

    def text_of(name: str) -> str:
        node = region_node.find(name)
        return (node.text or "").strip() if node is not None else ""

    hints = {}
    for node in region_node.findall("hint"):
        language = node.get("lang") or "ru"
        hints[language] = (node.text or "").strip()

    try:
        level = int(float(text_of("level") or 0))
    except ValueError:
        level = 0
    try:
        trend = int(float(text_of("tend") or 0))
    except ValueError:
        trend = 0

    title_node = root.find("region/title")
    region_title = (title_node.text or "").strip() if title_node is not None else ""

    return TrafficData(
        level=max(0, min(10, level)),
        icon=text_of("icon") or "green",
        hint=hints.get("ru", ""),
        hint_en=hints.get("en", ""),
        time_text=text_of("time"),
        trend=max(-1, min(1, trend)),
        region=region_title,
        url=text_of("url"),
        fetched_at=datetime.now(),
    )


def demo_score(seed: str, moment: datetime | None = None) -> TrafficData:
    """Демонстрационные баллы: чтобы блок было видно и без связи с сервисом."""
    now = moment or datetime.now()
    key = f"{seed}|{now:%Y-%m-%d %H}"
    cached = _demo_cache.get(key)
    if cached is not None and now - cached.fetched_at < DEMO_LIFETIME:
        return cached
    generator = random.Random(f"{seed}|{now:%Y-%m-%d %H}")
    hour = now.hour
    # «час пик» утром и вечером даёт больше баллов — так демо выглядит правдоподобно
    rush = 3 if hour in (8, 9, 18, 19) else (2 if hour in (7, 10, 17, 20) else 0)
    level = max(0, min(10, generator.choices(
        [generator.randint(0, 3), generator.randint(3, 6), generator.randint(5, 9)],
        weights=[5, 3, 1 + rush])[0]))
    data = TrafficData(level=level, icon="demo", hint="", hint_en="",
                       time_text=f"{now:%H:%M}", trend=generator.choice([-1, 0, 0, 1]),
                       region=seed, source=texts.t("traffic.demo_source"),
                       demo=True, fetched_at=now)
    _demo_cache[key] = data
    return data


def fetch(city, demo: bool = True, timeout: float = TIMEOUT) -> TrafficData | None:
    """Пробки для города: настоящие данные, иначе (в тестовом режиме) демо."""
    if city is not None and getattr(city, "lat", None) and getattr(city, "lon", None):
        data = score_from_coords(city.lat, city.lon, timeout)
        if data is not None:
            return data
    if not demo:
        return None
    seed = getattr(city, "name", "") or "город"
    return demo_score(seed)
