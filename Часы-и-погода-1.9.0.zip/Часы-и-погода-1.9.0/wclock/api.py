# -*- coding: utf-8 -*-
"""Связь с метеослужбой Open-Meteo (без API-ключа) и геокодинг городов."""

from __future__ import annotations

import json
import queue
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone

from . import sun, texts

API_URL = "https://api.open-meteo.com/v1/forecast"
GEO_URL = "https://geocoding-api.open-meteo.com/v1/search"
IP_URL = "http://ip-api.com/json/"
IP_URL_FALLBACK = "https://ipapi.co/json/"
MET_URL = "https://api.met.no/weatherapi/locationforecast/2.0/complete"

USER_AGENT = "WeatherClockWidget/1.1 (Windows desktop widget)"
DEFAULT_TIMEOUT = 12          # на одну попытку
MET_TIMEOUT = 12
RETRY_PAUSE = 0.8             # пауза между попытками
PREFER_WAIT = 1.5             # сколько ждём приоритетный источник перед резервным
SOURCE_NAME = "Open-Meteo"
SOURCE_MET = "MET Norway"
SOURCES = (SOURCE_NAME, SOURCE_MET)

CURRENT_FIELDS = ",".join([
    "temperature_2m", "relative_humidity_2m", "apparent_temperature", "is_day",
    "precipitation", "weather_code", "cloud_cover", "surface_pressure",
    "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m", "uv_index",
])
HOURLY_FIELDS = ("temperature_2m,precipitation_probability,precipitation,"
                 "weather_code,is_day,surface_pressure")
DAILY_FIELDS = ("weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,"
                "daylight_duration,precipitation_probability_max")


class WeatherError(Exception):
    """Ошибка получения данных от метеослужбы."""


# --------------------------------------------------------------------------- модели данных

@dataclass
class City:
    name: str
    country: str = ""
    admin1: str = ""
    lat: float = 0.0
    lon: float = 0.0
    timezone: str = ""
    population: int = 0

    def label(self) -> str:
        parts = [texts.place(self.name)]
        if self.admin1 and self.admin1.lower() not in self.name.lower():
            parts.append(texts.place(self.admin1))
        if self.country:
            parts.append(texts.place(self.country))
        return ", ".join(parts)

    def short(self) -> str:
        name = texts.place(self.name)
        return f"{name}, {texts.place(self.country)}" if self.country else name

    def to_dict(self) -> dict:
        return {
            "name": self.name, "country": self.country, "admin1": self.admin1,
            "lat": self.lat, "lon": self.lon, "timezone": self.timezone,
            "population": self.population,
        }

    @staticmethod
    def from_dict(raw: dict) -> "City":
        return City(
            name=raw.get("name", ""), country=raw.get("country", ""),
            admin1=raw.get("admin1", ""), lat=float(raw.get("lat", 0.0) or 0.0),
            lon=float(raw.get("lon", 0.0) or 0.0), timezone=raw.get("timezone", ""),
            population=int(raw.get("population", 0) or 0),
        )


@dataclass
class Current:
    time: datetime | None = None
    temperature: float | None = None
    apparent: float | None = None
    humidity: float | None = None
    precipitation: float = 0.0
    code: int = 0
    is_day: bool = True
    cloud_cover: float | None = None
    wind_speed: float | None = None
    wind_direction: float | None = None
    wind_gusts: float | None = None
    pressure: float | None = None
    uv_index: float | None = None


@dataclass
class HourPoint:
    time: datetime
    temperature: float | None = None
    code: int = 0
    is_day: bool = True
    precipitation: float = 0.0
    probability: int = 0
    pressure: float | None = None


@dataclass
class DayPoint:
    day: datetime
    code: int = 0
    t_max: float | None = None
    t_min: float | None = None
    sunrise: datetime | None = None
    sunset: datetime | None = None
    daylight_seconds: float = 0.0
    precip_probability_max: int = 0


@dataclass
class WeatherData:
    raw: dict = field(default_factory=dict)
    fetched_at: datetime | None = None
    latitude: float = 0.0
    longitude: float = 0.0
    elevation: float = 0.0
    timezone_name: str = ""
    utc_offset_seconds: int = 0
    source: str = SOURCE_NAME
    current: Current = field(default_factory=Current)
    hours: list[HourPoint] = field(default_factory=list)
    days: list[DayPoint] = field(default_factory=list)

    # -- удобные свойства -------------------------------------------------
    @property
    def tz(self) -> timezone:
        return timezone(timedelta(seconds=self.utc_offset_seconds))

    def now_local(self) -> datetime:
        """Текущее время в часовом поясе выбранного города."""
        return datetime.now(timezone.utc).astimezone(self.tz)

    def today(self) -> DayPoint | None:
        local_today = self.now_local().date()
        for day in self.days:
            if day.day.date() == local_today:
                return day
        return self.days[0] if self.days else None

    def age_minutes(self) -> float:
        if not self.fetched_at:
            return 1e9
        return (datetime.now().astimezone() - self.fetched_at).total_seconds() / 60.0


# --------------------------------------------------------------------------- сеть

def _get_json(url: str, timeout: float = DEFAULT_TIMEOUT, attempts: int = 2) -> dict:
    """GET + разбор JSON с повтором при сетевой ошибке."""
    last_error: Exception | None = None
    for attempt in range(max(1, attempts)):
        request = urllib.request.Request(url, headers={
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
        })
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                payload = response.read().decode("utf-8", "replace")
            return json.loads(payload)
        except urllib.error.HTTPError as exc:
            last_error = WeatherError(f"служба вернула ошибку {exc.code}")
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            reason = getattr(exc, "reason", exc)
            last_error = WeatherError(f"{reason}")
        except json.JSONDecodeError:
            last_error = WeatherError("некорректный ответ службы")
        if attempt + 1 < attempts:
            time.sleep(RETRY_PAUSE)
    raise last_error or WeatherError("не удалось получить данные")


def fetch_raw(city: City, timeout: float = DEFAULT_TIMEOUT) -> dict:
    """Запрос прогноза у Open-Meteo (текущая погода + почасовой + суточный)."""
    params = {
        "latitude": f"{city.lat:.4f}",
        "longitude": f"{city.lon:.4f}",
        "current": CURRENT_FIELDS,
        "hourly": HOURLY_FIELDS,
        "daily": DAILY_FIELDS,
        "timezone": "auto",
        "forecast_days": 3,
        "wind_speed_unit": "ms",
        "timeformat": "iso8601",
    }
    url = API_URL + "?" + urllib.parse.urlencode(params)
    raw = _get_json(url, timeout=timeout)
    if "current" not in raw and "hourly" not in raw:
        raise WeatherError("метеослужба не вернула данные прогноза")
    raw.setdefault("source", SOURCE_NAME)
    return raw


# --------------------------------------------------------------------------- MET Norway (резерв)
# Второй источник нужен там, где Open-Meteo недоступен (например, без VPN).
# Формат ответа приводится к виду Open-Meteo, чтобы разбор был общим.

MET_SYMBOL_TO_WMO = {
    "clearsky": 0, "fair": 1, "partlycloudy": 2, "cloudy": 3, "fog": 45,
    "lightrain": 61, "rain": 63, "heavyrain": 65,
    "lightrainshowers": 80, "rainshowers": 81, "heavyrainshowers": 82,
    "lightsleet": 66, "sleet": 67, "heavysleet": 67,
    "lightsleetshowers": 66, "sleetshowers": 67, "heavysleetshowers": 67,
    "lightsnow": 71, "snow": 73, "heavysnow": 75,
    "lightsnowshowers": 85, "snowshowers": 85, "heavysnowshowers": 86,
    "rainandthunder": 95, "lightrainandthunder": 95, "heavyrainandthunder": 95,
    "sleetandthunder": 95, "snowandthunder": 95,
    "lightrainshowersandthunder": 95, "rainshowersandthunder": 95,
    "heavyrainshowersandthunder": 95,
    "lightsleetshowersandthunder": 95, "sleetshowersandthunder": 95,
    "heavysleetshowersandthunder": 95,
    "lightsnowshowersandthunder": 95, "snowshowersandthunder": 95,
    "heavysnowshowersandthunder": 95,
    "partlycloudyandthunder": 95, "fairandthunder": 95, "clearskyandthunder": 95,
}


def met_symbol_to_wmo(symbol: str) -> int:
    """Символ MET Norway («heavyrainandthunder») → код погоды WMO."""
    name = (symbol or "").lower()
    for suffix in ("_polartwilight", "_day", "_night"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break
    return MET_SYMBOL_TO_WMO.get(name, 3)


def met_symbol_is_day(symbol: str) -> bool | None:
    """День/ночь по суффиксу символа (None — если суффикса нет)."""
    name = (symbol or "").lower()
    if name.endswith("_night"):
        return False
    if name.endswith("_day") or name.endswith("_polartwilight"):
        return True
    return None


def city_timezone(city: City):
    """Часовой пояс города: имя из геокодера, иначе системный пояс."""
    name = (city.timezone or "").strip()
    if name:
        try:
            from zoneinfo import ZoneInfo

            zone = ZoneInfo(name)
            offset = datetime.now(zone).utcoffset() or timedelta(0)
            return timezone(offset, name), name
        except Exception:
            pass
    local = datetime.now().astimezone()
    label = local.tzname() or "local"
    return timezone(local.utcoffset() or timedelta(0), label), label


def parse_met_payload(payload: dict, city: City) -> dict:
    """Ответ MET Norway → словарь в формате Open-Meteo."""
    series = ((payload.get("properties") or {}).get("timeseries")) or []
    if not series:
        raise WeatherError("MET Norway не вернул прогноз")
    tzinfo, tz_name = city_timezone(city)
    offset = int((tzinfo.utcoffset(None) or timedelta(0)).total_seconds())

    sun_cache: dict = {}

    def sun_for(day_local: date):
        if day_local not in sun_cache:
            sun_cache[day_local] = sun.sun_times(day_local, city.lat, city.lon, tzinfo)
        return sun_cache[day_local]

    points: list[dict] = []
    for entry in series:
        moment = _parse_dt(entry.get("time"), timezone.utc)
        if moment is None:
            continue
        data = entry.get("data") or {}
        instant = (data.get("instant") or {}).get("details") or {}
        temperature = _num(instant.get("air_temperature"))
        if temperature is None:
            continue
        if "next_1_hours" in data:
            block, span = data.get("next_1_hours") or {}, 1.0
        elif "next_6_hours" in data:
            block, span = data.get("next_6_hours") or {}, 6.0
        elif "next_12_hours" in data:
            block, span = data.get("next_12_hours") or {}, 12.0
        else:
            block, span = {}, 1.0
        symbol = str((block.get("summary") or {}).get("symbol_code") or "")
        local = moment.astimezone(tzinfo)
        sunrise, sunset = sun_for(local.date())
        symbol_day = met_symbol_is_day(symbol)
        if symbol_day is not None:
            is_day = symbol_day
        elif sunrise and sunset:
            is_day = sunrise <= local <= sunset
        else:
            is_day = 7 <= local.hour < 21
        points.append({
            "local": local,
            "temperature": temperature,
            "code": met_symbol_to_wmo(symbol),
            "precipitation": _num((block.get("details") or {}).get("precipitation_amount"), 0.0) or 0.0,
            "span": span,
            "is_day": is_day,
            "humidity": _num(instant.get("relative_humidity")),
            "apparent": _num(instant.get("apparent_air_temperature")),
            "pressure": _num(instant.get("air_pressure_at_sea_level")),
            "cloud": _num(instant.get("cloud_area_fraction")),
            "wind": _num(instant.get("wind_speed")),
            "wind_dir": _num(instant.get("wind_from_direction")),
        })
    if not points:
        raise WeatherError("MET Norway вернул пустой прогноз")

    hourly_time, hourly_temp, hourly_code, hourly_precip, hourly_is_day = [], [], [], [], []
    days: dict = {}
    for point in points:
        local = point["local"]
        hourly_time.append(local.strftime("%Y-%m-%dT%H:%M"))
        hourly_temp.append(round(point["temperature"], 1))
        hourly_code.append(point["code"])
        hourly_precip.append(round(point["precipitation"], 2))
        hourly_is_day.append(1 if point["is_day"] else 0)
        record = days.setdefault(local.date(), {"temps": [], "noon_code": 3, "noon_delta": 99})
        record["temps"].append(point["temperature"])
        delta = abs(local.hour - 12)
        if delta < record["noon_delta"]:
            record["noon_delta"] = delta
            record["noon_code"] = point["code"]

    daily = {"time": [], "weather_code": [], "temperature_2m_max": [],
             "temperature_2m_min": [], "sunrise": [], "sunset": [],
             "daylight_duration": [], "precipitation_probability_max": []}
    for day_local in sorted(days):
        record = days[day_local]
        sunrise, sunset = sun_for(day_local)
        daily["time"].append(day_local.strftime("%Y-%m-%d"))
        daily["weather_code"].append(record["noon_code"])
        daily["temperature_2m_max"].append(round(max(record["temps"]), 1))
        daily["temperature_2m_min"].append(round(min(record["temps"]), 1))
        daily["sunrise"].append(sunrise.strftime("%Y-%m-%dT%H:%M") if sunrise else "")
        daily["sunset"].append(sunset.strftime("%Y-%m-%dT%H:%M") if sunset else "")
        daily["daylight_duration"].append(
            (sunset - sunrise).total_seconds() if sunrise and sunset else 0.0)
        daily["precipitation_probability_max"].append(0)

    now_local = datetime.now(tzinfo)
    current_point = points[0]
    for point in points:
        if point["local"] <= now_local:
            current_point = point
        else:
            break

    return {
        "latitude": city.lat, "longitude": city.lon, "elevation": 0.0,
        "utc_offset_seconds": offset, "timezone": tz_name, "source": SOURCE_MET,
        "current": {
            "time": current_point["local"].strftime("%Y-%m-%dT%H:%M"),
            "temperature_2m": round(current_point["temperature"], 1),
            "relative_humidity_2m": current_point["humidity"],
            "apparent_temperature": current_point["apparent"],
            "is_day": 1 if current_point["is_day"] else 0,
            "precipitation": current_point["precipitation"],
            "weather_code": current_point["code"],
            "cloud_cover": current_point["cloud"],
            "surface_pressure": current_point["pressure"],
            "wind_speed_10m": current_point["wind"],
            "wind_direction_10m": current_point["wind_dir"],
        },
        "hourly": {
            "time": hourly_time, "temperature_2m": hourly_temp,
            "weather_code": hourly_code, "is_day": hourly_is_day,
            "precipitation": hourly_precip,
            "precipitation_probability": [0] * len(hourly_time),
        },
        "daily": daily,
    }


def fetch_met_raw(city: City, timeout: float = MET_TIMEOUT) -> dict:
    """Прогноз от MET Norway (api.met.no), приведённый к формату Open-Meteo."""
    params = {"lat": f"{city.lat:.4f}", "lon": f"{city.lon:.4f}"}
    url = MET_URL + "?" + urllib.parse.urlencode(params)
    return parse_met_payload(_get_json(url, timeout=timeout), city)


def fetch_weather(city: City, prefer_wait: float = PREFER_WAIT):
    """Опросить оба источника параллельно. Open-Meteo приоритетнее.

    Возвращает (raw, имя источника). Резервный MET Norway отвечает даже там,
    где Open-Meteo недоступен, поэтому виджет работает и без VPN.
    """
    results: queue.Queue = queue.Queue()

    def worker(name: str, fetcher) -> None:
        try:
            results.put((name, fetcher(city), None))
        except Exception as exc:
            results.put((name, None, f"{type(exc).__name__}: {exc}"))

    for name, fetcher in ((SOURCE_NAME, fetch_raw), (SOURCE_MET, fetch_met_raw)):
        threading.Thread(target=worker, args=(name, fetcher), daemon=True).start()

    errors: list[str] = []
    pending = 2
    fallback = None
    deadline = time.monotonic() + max(0.0, prefer_wait)
    while pending > 0:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            name, raw, error = results.get(timeout=remaining)
        except queue.Empty:
            break
        pending -= 1
        if raw is not None:
            if name == SOURCE_NAME:
                return raw, name
            fallback = (raw, name)
        elif error:
            errors.append(f"{name}: {error}")
    if fallback is not None:
        return fallback
    while pending > 0:
        try:
            name, raw, error = results.get(timeout=DEFAULT_TIMEOUT + 3)
        except queue.Empty:
            break
        pending -= 1
        if raw is not None:
            return raw, name
        if error:
            errors.append(f"{name}: {error}")
    detail = "; ".join(errors) or "истекло время ожидания"
    raise WeatherError(f"нет связи с метеослужбами ({detail})")


def search_cities(query: str, count: int = 12, language: str = "ru",
                  timeout: float = 15) -> list[City]:
    """Поиск города по названию через геокодер метеослужбы."""
    query = (query or "").strip()
    if not query:
        return []
    params = {
        "name": query,
        "count": max(1, min(50, count)),
        "language": language,
        "format": "json",
    }
    url = GEO_URL + "?" + urllib.parse.urlencode(params)
    raw = _get_json(url, timeout=timeout)
    results = raw.get("results") or []
    cities: list[City] = []
    for item in results:
        feature = str(item.get("feature_code", ""))
        if feature and not feature.startswith("PPL"):
            continue
        cities.append(City(
            name=str(item.get("name", "")).strip(),
            country=str(item.get("country", "")).strip(),
            admin1=str(item.get("admin1", "")).strip(),
            lat=float(item.get("latitude", 0.0)),
            lon=float(item.get("longitude", 0.0)),
            timezone=str(item.get("timezone", "")),
            population=int(item.get("population", 0) or 0),
        ))
    query_lower = query.lower()
    cities.sort(key=lambda c: (c.name.lower() != query_lower, -c.population))
    return cities


def locate_by_ip(timeout: float = 8) -> City:
    """Приблизительное определение города по IP-адресу."""
    problems = []
    try:
        params = urllib.parse.urlencode({
            "fields": "status,city,regionName,country,lat,lon,timezone", "lang": "ru",
        })
        data = _get_json(IP_URL + "?" + params, timeout=timeout)
        if data.get("status") == "success" and data.get("city"):
            return City(
                name=str(data["city"]), country=str(data.get("country", "")),
                admin1=str(data.get("regionName", "")), lat=float(data["lat"]),
                lon=float(data["lon"]), timezone=str(data.get("timezone", "")),
            )
        problems.append(str(data.get("message", "не удалось определить")))
    except WeatherError as exc:
        problems.append(str(exc))
    try:
        data = _get_json(IP_URL_FALLBACK, timeout=timeout)
        if data.get("city") and data.get("latitude") is not None:
            return City(
                name=str(data["city"]), country=str(data.get("country_name", "")),
                admin1=str(data.get("region", "")), lat=float(data["latitude"]),
                lon=float(data["longitude"]), timezone=str(data.get("timezone", "")),
            )
        problems.append("второй сервис не вернул город")
    except WeatherError as exc:
        problems.append(str(exc))
    raise WeatherError("Не удалось определить город автоматически: " + "; ".join(problems))


# --------------------------------------------------------------------------- разбор ответа

def _parse_dt(value, tz: timezone) -> datetime | None:
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):            # формат MET Norway: 2026-10-02T19:00:00Z
        text = text[:-1] + "+00:00"
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).replace(tzinfo=tz)
        except ValueError:
            continue
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=tz)
    return parsed


def _num(value, default=None):
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _at(block: dict, key: str, index: int):
    values = block.get(key)
    if not isinstance(values, list) or index >= len(values):
        return None
    return values[index]


def parse_weather(raw: dict, fetched_at: datetime | None = None) -> WeatherData:
    """Преобразует ответ API в структуры WeatherData (время — в поясе города)."""
    offset = int(_num(raw.get("utc_offset_seconds"), 0) or 0)
    tz = timezone(timedelta(seconds=offset))
    data = WeatherData(
        raw=raw,
        fetched_at=fetched_at or datetime.now().astimezone(),
        latitude=_num(raw.get("latitude"), 0.0) or 0.0,
        longitude=_num(raw.get("longitude"), 0.0) or 0.0,
        elevation=_num(raw.get("elevation"), 0.0) or 0.0,
        timezone_name=str(raw.get("timezone", "") or ""),
        utc_offset_seconds=offset,
        source=str(raw.get("source") or SOURCE_NAME),
    )

    hourly = raw.get("hourly") or {}
    times = hourly.get("time") or []
    for index, stamp in enumerate(times):
        moment = _parse_dt(stamp, tz)
        if moment is None:
            continue
        data.hours.append(HourPoint(
            time=moment,
            temperature=_num(_at(hourly, "temperature_2m", index)),
            code=int(_num(_at(hourly, "weather_code", index), 0) or 0),
            is_day=bool(_num(_at(hourly, "is_day", index), 1)),
            precipitation=_num(_at(hourly, "precipitation", index), 0.0) or 0.0,
            probability=int(_num(_at(hourly, "precipitation_probability", index), 0) or 0),
            pressure=_num(_at(hourly, "surface_pressure", index)),
        ))

    daily = raw.get("daily") or {}
    day_stamps = daily.get("time") or []
    for index, stamp in enumerate(day_stamps):
        moment = _parse_dt(stamp, tz)
        if moment is None:
            continue
        data.days.append(DayPoint(
            day=moment,
            code=int(_num(_at(daily, "weather_code", index), 0) or 0),
            t_max=_num(_at(daily, "temperature_2m_max", index)),
            t_min=_num(_at(daily, "temperature_2m_min", index)),
            sunrise=_parse_dt(_at(daily, "sunrise", index), tz),
            sunset=_parse_dt(_at(daily, "sunset", index), tz),
            daylight_seconds=_num(_at(daily, "daylight_duration", index), 0.0) or 0.0,
            precip_probability_max=int(_num(_at(daily, "precipitation_probability_max", index), 0) or 0),
        ))

    current_block = raw.get("current") or {}
    current = Current(
        time=_parse_dt(current_block.get("time"), tz),
        temperature=_num(current_block.get("temperature_2m")),
        apparent=_num(current_block.get("apparent_temperature")),
        humidity=_num(current_block.get("relative_humidity_2m")),
        precipitation=_num(current_block.get("precipitation"), 0.0) or 0.0,
        code=int(_num(current_block.get("weather_code"), 0) or 0),
        is_day=bool(_num(current_block.get("is_day"), 1)),
        cloud_cover=_num(current_block.get("cloud_cover")),
        wind_speed=_num(current_block.get("wind_speed_10m")),
        wind_direction=_num(current_block.get("wind_direction_10m")),
        wind_gusts=_num(current_block.get("wind_gusts_10m")),
        pressure=_num(current_block.get("surface_pressure")),
        uv_index=_num(current_block.get("uv_index")),
    )
    # страховка, если блок current пуст — берём ближайший час
    if current.temperature is None and data.hours:
        now = data.now_local()
        nearest = min(data.hours, key=lambda h: abs((h.time - now).total_seconds()))
        current.temperature = nearest.temperature
        current.code = nearest.code
        current.is_day = nearest.is_day
        current.precipitation = nearest.precipitation
        current.time = nearest.time
    data.current = current
    return data


def load_cached_weather(raw: dict, fetched_at_iso: str | None) -> WeatherData:
    stamp = None
    if fetched_at_iso:
        try:
            stamp = datetime.fromisoformat(fetched_at_iso)
            if stamp.tzinfo is None:
                stamp = stamp.astimezone()
        except ValueError:
            stamp = None
    return parse_weather(raw, fetched_at=stamp)


# --------------------------------------------------------------------------- заготовки городов

def _city(name, country, admin1, lat, lon):
    return City(name=name, country=country, admin1=admin1, lat=lat, lon=lon)


POPULAR_CITIES: list[City] = [
    _city("Москва", "Россия", "", 55.7558, 37.6173),
    _city("Санкт-Петербург", "Россия", "", 59.9386, 30.3141),
    _city("Новосибирск", "Россия", "Новосибирская область", 55.0084, 82.9357),
    _city("Екатеринбург", "Россия", "Свердловская область", 56.8389, 60.6057),
    _city("Казань", "Россия", "Татарстан", 55.7963, 49.1088),
    _city("Нижний Новгород", "Россия", "Нижегородская область", 56.3269, 44.0059),
    _city("Челябинск", "Россия", "Челябинская область", 55.1644, 61.4368),
    _city("Самара", "Россия", "Самарская область", 53.2001, 50.15),
    _city("Омск", "Россия", "Омская область", 54.9885, 73.3242),
    _city("Ростов-на-Дону", "Россия", "Ростовская область", 47.2225, 39.7187),
    _city("Уфа", "Россия", "Башкортостан", 54.7388, 55.9721),
    _city("Красноярск", "Россия", "Красноярский край", 56.0097, 92.7917),
    _city("Воронеж", "Россия", "Воронежская область", 51.6720, 39.1843),
    _city("Пермь", "Россия", "Пермский край", 58.0104, 56.2344),
    _city("Волгоград", "Россия", "Волгоградская область", 48.7080, 44.5133),
    _city("Краснодар", "Россия", "Краснодарский край", 45.0355, 38.9753),
    _city("Саратов", "Россия", "Саратовская область", 51.5336, 46.0343),
    _city("Тюмень", "Россия", "Тюменская область", 57.1522, 65.5272),
    _city("Иркутск", "Россия", "Иркутская область", 52.2864, 104.2807),
    _city("Хабаровск", "Россия", "Хабаровский край", 48.4827, 135.0838),
    _city("Владивосток", "Россия", "Приморский край", 43.1155, 131.8855),
    _city("Мурманск", "Россия", "Мурманская область", 68.9585, 33.0827),
    _city("Сочи", "Россия", "Краснодарский край", 43.6028, 39.7342),
    _city("Калининград", "Россия", "Калининградская область", 54.7104, 20.4522),
    _city("Симферополь", "Россия", "Крым", 44.9521, 34.1024),
    _city("Минск", "Беларусь", "", 53.9023, 27.5619),
    _city("Алматы", "Казахстан", "", 43.2389, 76.8897),
    _city("Астана", "Казахстан", "", 51.1605, 71.4704),
    _city("Киев", "Украина", "", 50.4501, 30.5234),
    _city("Ташкент", "Узбекистан", "", 41.2995, 69.2401),
    _city("Тбилиси", "Грузия", "", 41.7151, 44.8271),
    _city("Ереван", "Армения", "", 40.1792, 44.4991),
    _city("Баку", "Азербайджан", "", 40.4093, 49.8671),
    _city("Бишкек", "Кыргызстан", "", 42.8746, 74.5698),
]
