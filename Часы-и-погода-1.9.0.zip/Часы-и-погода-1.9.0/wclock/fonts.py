# -*- coding: utf-8 -*-
"""Шрифты для цифровых часов.

Список подобран из читаемых для времени семейств (моноширинные, «техно» и
строгие гротески). Дополнительно можно положить свои TTF/OTF в папку `fonts`
рядом с виджетом — они подключатся к процессу и появятся в меню.
"""

from __future__ import annotations

import ctypes
import shutil
import sys
from pathlib import Path

# 20 семейств, подходящих для отображения времени, разбитые на три группы
# по толщине штриха: тонкие, средние, широкие (плотные)
CLOCK_FONT_GROUPS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Тонкие", (
        "Cascadia Mono Light",
        "Bahnschrift Light",
        "Bahnschrift Condensed",
        "Segoe UI Light",
    )),
    ("Средние", (
        "Cascadia Mono",
        "Consolas",
        "Lucida Console",
        "Courier New",
        "Bahnschrift",
        "Segoe UI Variable Display",
        "Segoe UI",
        "OCR-A BT",
        "OCR-B 10 BT",
        "Franklin Gothic Medium",
    )),
    ("Широкие", (
        "Cascadia Mono SemiBold",
        "Cascadia Code SemiBold",
        "Bahnschrift SemiBold",
        "Segoe UI Variable Display Semib",
        "Segoe UI Semibold",
        "Verdana",
    )),
)

# Плоский список в порядке групп (используется для проверок и подстановок)
CLOCK_FONTS: tuple[str, ...] = tuple(
    name for _title, names in CLOCK_FONT_GROUPS for name in names
)

# Запасные варианты, если чего-то из списка в системе нет
FALLBACK_FONTS: tuple[str, ...] = (
    "Tahoma", "Calibri", "Arial", "Cascadia Code",
)

FONT_FILE_SUFFIXES = (".ttf", ".otf", ".ttc")
FR_PRIVATE = 0x10


def fonts_folder() -> Path:
    """Папка с дополнительными шрифтами рядом с виджетом."""
    return Path(__file__).resolve().parent.parent / "fonts"


def load_font_files(folder: Path | str | None = None) -> list[str]:
    """Подключить шрифты из папки к текущему процессу.

    Используется приватная регистрация шрифтов Windows: система не меняется,
    шрифт виден только этому запущенному виджету. Возвращает имена файлов.
    """
    directory = Path(folder) if folder else fonts_folder()
    if not directory.is_dir() or sys.platform != "win32":
        return []
    loaded: list[str] = []
    for path in sorted(directory.iterdir()):
        if path.suffix.lower() not in FONT_FILE_SUFFIXES:
            continue
        if register_font_file(path):
            loaded.append(path.name)
    return loaded


def register_font_file(path: Path | str) -> bool:
    """Подключить один файл шрифта (приватно, для текущего процесса)."""
    if sys.platform != "win32":
        return False
    try:
        return bool(ctypes.windll.gdi32.AddFontResourceExW(str(path), FR_PRIVATE, 0))
    except Exception:
        return False


def family_map(root) -> dict[str, str]:
    """Семейства шрифтов: ключ в нижнем регистре → имя как в системе."""
    import tkinter.font as tkfont

    try:
        return {name.lower(): name for name in tkfont.families(root)}
    except Exception:
        return {}


def installed_families(root) -> set[str]:
    """Семейства шрифтов, доступные Tk (в нижнем регистре)."""
    return set(family_map(root))


def available(root) -> list[str]:
    """Сколько из подобранных шрифтов реально есть в системе."""
    present = installed_families(root)
    result = [name for name in CLOCK_FONTS if name.lower() in present]
    if len(result) < 5:       # страховка для необычной системы
        for name in FALLBACK_FONTS:
            if name.lower() in present and name not in result:
                result.append(name)
    return result


def categories(available_names) -> list[tuple[str, list[str]]]:
    """Разложить доступные шрифты по группам: тонкие, средние, широкие."""
    present = set(available_names)
    grouped: list[tuple[str, list[str]]] = []
    for title, names in CLOCK_FONT_GROUPS:
        group = [name for name in names if name in present]
        if group:
            grouped.append((title, group))
    return grouped


def custom_families(available_names) -> list[str]:
    """Шрифты, которых нет в подборке: свои, загруженные пользователем."""
    curated = set(CLOCK_FONTS) | set(FALLBACK_FONTS)
    return [name for name in available_names if name not in curated]


def custom_font_files(folder: Path | str | None = None) -> list[Path]:
    """Файлы своих шрифтов в папке виджета."""
    directory = Path(folder) if folder else fonts_folder()
    if not directory.is_dir():
        return []
    return sorted(path for path in directory.iterdir()
                  if path.suffix.lower() in FONT_FILE_SUFFIXES)


def import_font_file(source: Path | str, root=None,
                     folder: Path | str | None = None) -> str | None:
    """Скопировать свой шрифт в папку виджета и подключить его.

    Возвращает название семейства (если удалось определить) — чтобы сразу
    предложить новый шрифт в меню.
    """
    source = Path(source)
    if source.suffix.lower() not in FONT_FILE_SUFFIXES or not source.is_file():
        return None
    directory = Path(folder) if folder else fonts_folder()
    directory.mkdir(parents=True, exist_ok=True)

    target = directory / source.name
    index = 1
    while target.exists() and _different(target, source):
        target = directory / f"{source.stem} ({index}){source.suffix}"
        index += 1
    if not target.exists():
        try:
            shutil.copy2(source, target)
        except OSError:
            return None

    before = set(family_map(root)) if root is not None else set()
    if not register_font_file(target):
        return None
    if root is None:
        return None
    after = family_map(root)
    fresh = [after[key] for key in sorted(after) if key not in before]
    return fresh[0] if fresh else None


def _different(first: Path, second: Path) -> bool:
    """Отличается ли уже скопированный файл от исходного."""
    try:
        return first.stat().st_size != second.stat().st_size
    except OSError:
        return True


def resolve(preferred: str | None, root, fallback: str) -> str:
    """Проверить, что выбранный шрифт есть в системе, иначе вернуть запасной."""
    if preferred and preferred.lower() in installed_families(root):
        return preferred
    return fallback
