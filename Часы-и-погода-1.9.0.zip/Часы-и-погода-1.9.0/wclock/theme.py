# -*- coding: utf-8 -*-
"""Цветовые схемы виджета: четыре варианта по времени дня."""

from __future__ import annotations

import colorsys

# Общая «тёмная стеклянная» основа, отличаются оттенки фона и акцента.
PALETTES = {
    "night": {
        "bg_top": "#080d1c",
        "bg_bottom": "#141c33",
        "text": "#e9eeff",
        "muted": "#8d9dc2",
        "accent": "#7fa8ff",
        "warn": "#ff9f6e",
        "divider": "#26314f",
        "border": "#2b3757",
    },
    "dawn": {
        "bg_top": "#171331",
        "bg_bottom": "#3d2544",
        "text": "#f6efff",
        "muted": "#bda9cf",
        "accent": "#ffa76b",
        "warn": "#ffd06b",
        "divider": "#4a3357",
        "border": "#4d3560",
    },
    "day": {
        "bg_top": "#0d1729",
        "bg_bottom": "#1c2c48",
        "text": "#eaf2ff",
        "muted": "#9db0d2",
        "accent": "#5fb0ff",
        "warn": "#ffb37a",
        "divider": "#283a5c",
        "border": "#2c3f63",
    },
    "dusk": {
        "bg_top": "#1a1124",
        "bg_bottom": "#3e2135",
        "text": "#fdeef0",
        "muted": "#c6a5b1",
        "accent": "#ff8f61",
        "warn": "#ffc46b",
        "divider": "#4d2f41",
        "border": "#503346",
    },
}

# Цвета иконок (одинаковы во всех схемах — иконки читаются на тёмном фоне)
ICONS = {
    "sun": "#ffd166",
    "sun_warm": "#ffa94d",
    "moon": "#e3ebff",
    "cloud": "#c8d5ef",
    "cloud_dark": "#92a3c6",
    "cloud_deep": "#7183a8",
    "rain": "#69c1ff",
    "snow": "#eaf3ff",
    "lightning": "#ffd93d",
    "fog": "#b6c4e0",
}

# Насыщенная палитра для объёмного стиля иконок: теплее солнце и луна,
# контрастнее облака, ярче осадки
ICONS_VIVID = {
    "sun": "#ffc93c",
    "sun_warm": "#ff8a3c",
    "moon": "#ffe6a3",
    "cloud": "#f2f7ff",
    "cloud_dark": "#9fb6e6",
    "cloud_deep": "#6379ad",
    "rain": "#2f9bff",
    "snow": "#ffffff",
    "lightning": "#ffd21f",
    "fog": "#d7e5f8",
}

ICON_STYLES = ("mono", "vivid")


def icon_palette(style: str = "mono") -> dict:
    """Палитра иконок: монохромная (текущая) или объёмная."""
    return dict(ICONS_VIVID if style == "vivid" else ICONS)

# Цвет дня недели в строке даты: рабочие дни — голубой, выходные — красный
WEEKDAY_COLORS = {
    "work": "#6fc3ff",
    "weekend": "#ff6b6b",
}

# Тёмный запасной цвет для «прозрачного» фона (см. transparent_key)
FALLBACK_KEY = "#010203"

# Цвета-кандидаты для «вырезания» фона окон без рамки
KEY_CANDIDATES = ("#ff00ff", "#00ff7f", "#010203", "#f0f")


def weekday_color(moment, light: bool = False) -> str:
    table = ink_weekday_colors() if light else WEEKDAY_COLORS
    return table["weekend"] if moment.weekday() >= 5 else table["work"]


def palette(key: str) -> dict:
    return dict(PALETTES.get(key, PALETTES["day"]))


def _clamp_byte(value: float) -> int:
    return max(0, min(255, int(round(value))))


def hex_to_rgb(color: str) -> tuple[int, int, int]:
    color = color.lstrip("#")
    return tuple(int(color[i:i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def rgb_to_hex(rgb) -> str:
    return "#%02x%02x%02x" % tuple(_clamp_byte(c) for c in rgb)


def lerp(color_a: str, color_b: str, t: float) -> str:
    """Линейная интерполяция двух цветов (t = 0..1)."""
    t = max(0.0, min(1.0, t))
    a, b = hex_to_rgb(color_a), hex_to_rgb(color_b)
    return rgb_to_hex([a[i] + (b[i] - a[i]) * t for i in range(3)])


def mix(color: str, other: str, amount: float) -> str:
    return lerp(color, other, amount)


def gradient_at(pal: dict, t: float) -> str:
    """Цвет фонового градиента на относительной высоте t (0 — верх, 1 — низ)."""
    return lerp(pal["bg_top"], pal["bg_bottom"], t)


def valid_color(value) -> str | None:
    """Приводит «#RRGGBB» к нижнему регистру; None, если это не цвет."""
    if not isinstance(value, str):
        return None
    text = value.strip()
    if len(text) == 7 and text.startswith("#"):
        try:
            hex_to_rgb(text)
            return text.lower()
        except ValueError:
            return None
    return None


def plate_colors(pal: dict, top_override=None, bottom_override=None) -> tuple[str, str]:
    """Цвета подложки: пользовательские (#RRGGBB) либо из темы времени дня."""
    top = valid_color(top_override) or pal["bg_top"]
    bottom = valid_color(bottom_override) or pal["bg_bottom"]
    return top, bottom


def pick_key(colors) -> str:
    """Цвет-ключ для «вырезания» фона: любой, которого нет среди рисуемых.

    Нужен окнам без рамки: скруглённые углы делаются тем, что пиксели вне
    панели залиты ключевым цветом и становятся прозрачными.
    """
    used = set()
    if isinstance(colors, dict):
        colors = colors.values()
    for value in colors or ():
        color = valid_color(value)
        if color:
            used.add(color)
    for candidate in KEY_CANDIDATES:
        if candidate not in used:
            return candidate
    return FALLBACK_KEY


def transparent_key(top_color, dark_text: bool = False) -> str:
    """Цвет «прозрачного» фона окна с содержимым.

    Tk вырезает фон окна по точному цвету, а края букв сглаживаются
    (антиалиасинг) в этот же цвет. Поэтому ключом должен быть не magenta,
    а цвет подложки: тогда кромка текста выглядит как мягкая тень,
    а не как розовая обводка.

    dark_text — на светлой подложке текст тёмный, поэтому светлый ключ
    безопасен (он не совпадёт с буквами), и кромка сглаживается в фон.
    """
    color = valid_color(top_color)
    if color is None:
        return FALLBACK_KEY
    try:
        rgb = hex_to_rgb(color)
    except ValueError:
        return FALLBACK_KEY
    average = sum(rgb) / 3.0
    if dark_text:
        return FALLBACK_KEY if average < 40 else color
    return FALLBACK_KEY if average > 170 else color


# ------------------------------------------------------------------ контраст

def _linear(value: float) -> float:
    return value / 12.92 if value <= 0.03928 else ((value + 0.055) / 1.055) ** 2.4


def luminance(color: str) -> float:
    """Воспринимаемая яркость цвета: 0 — чёрный, 1 — белый."""
    red, green, blue = hex_to_rgb(color)
    return (0.2126 * _linear(red / 255.0)
            + 0.7152 * _linear(green / 255.0)
            + 0.0722 * _linear(blue / 255.0))


def contrast_ratio(first: str, second: str) -> float:
    """Коэффициент контраста по WCAG (1 — неразличимо, 21 — максимум)."""
    one, two = luminance(first), luminance(second)
    lighter, darker = max(one, two), min(one, two)
    return (lighter + 0.05) / (darker + 0.05)


def needs_dark_ink(top: str, bottom: str, text: str, minimum: float = 3.0) -> bool:
    """Плохо ли читается текст темы на такой подложке.

    Если подложку сделали светлее, контраст падает — тогда содержимое
    переключается на тёмные «чернила».
    """
    return contrast_ratio(mix(top, bottom, 0.5), text) < minimum


def flip_lightness(color: str, low: float = 0.07, high: float = 0.42) -> str:
    """Инвертировать светлоту цвета, сохранив оттенок.

    Светлое становится тёмным и наоборот: так из «дневной» палитры
    получается её тёмный вариант для светлой подложки.
    """
    red, green, blue = hex_to_rgb(color)
    hue, light, saturation = colorsys.rgb_to_hls(red / 255.0, green / 255.0, blue / 255.0)
    light = min(max(1.0 - light, low), high)
    red, green, blue = colorsys.hls_to_rgb(hue, light, min(1.0, saturation * 1.05))
    return rgb_to_hex((int(round(red * 255)), int(round(green * 255)),
                       int(round(blue * 255))))


def ink_palette(pal: dict) -> dict:
    """Палитра содержимого для светлой подложки: тёмные чернила."""
    result = dict(pal)
    for key in ("text", "muted", "accent", "warn", "divider", "border"):
        if key in result:
            result[key] = flip_lightness(result[key])
    result["_light"] = True
    return result


def ink_icons(style: str = "mono") -> dict:
    """Цвета иконок для светлой подложки."""
    return {name: flip_lightness(color) for name, color in icon_palette(style).items()}


def ink_weekday_colors() -> dict:
    return {name: flip_lightness(color) for name, color in WEEKDAY_COLORS.items()}
