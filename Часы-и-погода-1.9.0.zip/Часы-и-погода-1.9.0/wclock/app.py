# -*- coding: utf-8 -*-
"""Виджет рабочего стола: часы, дата, погода, световой день и осадки."""

from __future__ import annotations

import ctypes
import os
import queue
import threading
import time
import traceback
import tkinter as tk
import tkinter.font as tkfont
from ctypes import wintypes
from datetime import datetime, timedelta

from . import analysis, api, fonts, icons, texts, theme
from . import autostart
from . import locale_ru as ru
from . import menu as menu_ui
from . import moon as moon_mod
from . import traffic as traffic_mod
from . import update as update_mod
from . import version as version_mod
from .aboutdialog import ask_about
from .citydialog import ask_city
from .colordialog import ask_plate_colors
from .detailsdialog import ask_details, ask_update
from .config import APP_DIR, Config
from . import config as config_module
from .plate import PlateWindow, top_level_hwnd as plate_top_level_hwnd

TRANSPARENT_COLOR = "#ff00ff"
ERROR_LOG = "widget-error.log"
ERROR_LOG_LIMIT = 200_000       # байт: больше не растим
# Пункт «По умолчанию» в меню шрифтов: у пунктов Tk нельзя использовать пустое
# значение — иначе в настройки попадёт подпись пункта, а не «шрифт по умолчанию»
DEFAULT_FONT_VALUE = "__default__"
SHADOW_COLOR = "#0a0f18"      # тень под текстом, когда подложка почти прозрачная
NIGHT_DIM_FACTOR = 0.72       # насколько приглушать виджет ночью (ночной режим)
HIDE_TICK_MS = 20_000         # как часто проверять, не пора ли вернуть виджет
HOTKEY_POLL_MS = 130          # как часто проверять нажатие горячей клавиши
FULLSCREEN_TICK_MS = 1_500    # как часто проверять полноэкранные игры и фильмы
HOTKEY_ID = 0x0C1A            # произвольный номер горячей клавиши
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_NOREPEAT = 0x4000
WM_HOTKEY = 0x0312
PM_REMOVE = 0x0001
USER32 = ctypes.windll.user32 if hasattr(ctypes, "windll") else None
# окна оболочки Windows: их «полноэкранность» игрой не считается
SHELL_WINDOW_CLASSES = ("Progman", "WorkerW", "Shell_TrayWnd", "TrayWnd",
                        "Windows.UI.Core.CoreWindow", "SysShadow")
SIGNATURE = "IDEA by Nikita Konogin"

# Появление при запуске: сначала проявляется подложка, почти сразу за ней
# начинают всплывать блоки информации — по одному, сверху вниз.
# Блоки уже нарисованы, поэтому «всплытие» — это только показ тега (дёшево),
# а не пересборка раскладки (она стоит ~90 мс и рвала бы анимацию).
INTRO_MS = 1000               # вся анимация
INTRO_FRAME_MS = 12           # кадры идут максимально часто
INTRO_PLATE_MS = 420          # столько появляется подложка
INTRO_SCALE_FROM = 0.96       # мягкий рост подложки
INTRO_BLOCKS_START_MS = 220   # когда начинают всплывать блоки
INTRO_BLOCK_STEP_MS = 62      # шаг между блоками
INTRO_ALPHA_START_MS = 150    # когда содержимое начинает проявляться
INTRO_ALPHA_MS = 950          # когда содержимое набирает полную плотность

# Порядок появления блоков сверху вниз (совпадает с тегами отрисовки)
BLOCK_TAGS = ("header", "clock", "date", "divider", "weather", "daylight",
              "precip", "tomorrow", "traffic", "hourly", "footer")
TEXT_FONT_STACK = ["Segoe UI Variable Text", "Segoe UI", "Tahoma", "Verdana", "Arial"]
MONO_FONT_STACK = ["Cascadia Mono SemiBold", "Cascadia Mono", "Consolas", "Courier New"]
MIN_WIDTH, MIN_HEIGHT = 250, 320
DEFAULT_SIZE = (420, 640)
EDGE_ZONE = 7


def log_error(where: str, error: BaseException | str, tb=None) -> None:
    """Записать сбой в файл рядом с виджетом: с pythonw иначе ничего не видно."""
    try:
        path = APP_DIR / ERROR_LOG
        if path.exists() and path.stat().st_size > ERROR_LOG_LIMIT:
            path.unlink()
        with open(path, "a", encoding="utf-8") as handle:
            handle.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] {where}\n")
            if tb is not None:
                traceback.print_exception(type(error), error, tb, file=handle)
            else:
                handle.write(f"{type(error).__name__}: {error}\n")
    except OSError:
        pass


def resilient_redraw(method):
    """Перерисовать виджет, а при сбое — записать его в лог и повторить попытку.

    Иначе исключение посреди отрисовки оставляло пустой холст: на экране
    оставалась только подложка, и понять причину было нечем.
    """

    def wrapper(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except Exception as error:               # noqa: BLE001 — нужен любой сбой
            log_error("отрисовка виджета", error, error.__traceback__)
            if getattr(self, "_redraw_failed", False):
                return None
            self._redraw_failed = True

            def retry() -> None:
                self._redraw_failed = False
                try:
                    method(self, force=True)
                except Exception as again:       # noqa: BLE001
                    log_error("повторная отрисовка", again, again.__traceback__)

            try:
                self.root.after(150, retry)
            except tk.TclError:
                pass
            return None

    return wrapper


def _enable_dpi_awareness() -> None:
    """Чёткий текст на мониторах с масштабированием."""
    try:
        import ctypes
    except Exception:
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)  # type: ignore[attr-defined]
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()  # type: ignore[attr-defined]
        except Exception:
            pass


# Размеры шрифтов: доля от высоты окна, минимальный размер в px,
# вид (моноширинный/обычный) и насыщенность. Одни и те же коэффициенты
# используются при раскладке и при прогреве шрифтов для анимации появления.
FONT_FACTORS = {
    "clock": (0.190, 18, "clock", "bold"),
    "date": (0.050, 9, "text", "normal"),
    "temp": (0.078, 13, "text", "bold"),
    "desc": (0.038, 9, "text", "normal"),
    "small": (0.029, 8, "text", "normal"),
    "label": (0.029, 8, "text", "bold"),
    "tiny": (0.022, 7, "text", "normal"),
}


def font_pixels(height: int, scale: float) -> dict:
    """Размеры шрифтов в пикселях для окна заданной высоты."""
    return {name: max(floor, int(height * factor * scale))
            for name, (factor, floor, _kind, _weight) in FONT_FACTORS.items()}


class WeatherWidget:
    """Окно-виджет целиком нарисовано на Canvas и масштабируется под размер окна."""

    def __init__(self, root: tk.Tk, config: Config, screenshot_path: str | None = None,
                 exit_after: bool = False):
        self.root = root
        self.config = config
        self.screenshot_path = screenshot_path
        self.exit_after = exit_after

        self.city = config.city
        self.city_alt = config.alt_city      # второй город (дача, работа)
        self._hidden_by_user = False         # спрятан по просьбе или клавишей
        self.pressure_trend = ""             # тренд давления: rising/falling/steady
        self._hide_until: datetime | None = None
        self._auto_hidden = False            # спрятан из-за игры или фильма
        self._hotkey_ready = False
        self.data: api.WeatherData | None = None
        self.source_name = api.SOURCE_NAME
        self.outlook = analysis.Outlook()
        self.daylight = analysis.Daylight()
        self.status_error: str | None = None
        self.status_note = (texts.t("status.loading") if self.city
                            else texts.t("status.detecting_city"))
        self.loading = False
        self.precip_text = texts.t("precip.waiting")
        self.footer_text = self.status_note
        self.footer_warn = False
        self._hourly_points: list = []
        self._btn_rects: dict[str, tuple] = {}

        self.zoom = float(config.option("zoom", 1.0) or 1.0)
        self._show_seconds = bool(config.option("seconds", True))
        self._show_weekday = bool(config.option("weekday", True))
        self._show_hourly = bool(config.option("hourly", True))
        self._hour12 = bool(config.option("hour12", False))
        self._show_traffic = bool(config.option("traffic", True))
        saved_style = config.option("icon_style") or "mono"
        self._icon_style = saved_style if saved_style in theme.ICON_STYLES else "mono"
        self.traffic = None                    # баллы пробок (traffic.TrafficData)
        self._frameless = bool(config.option("frameless", True))
        self.radius = 16.0 if (self._frameless and config.option("rounded", True)) else 0.0

        self._font_cache: dict = {}
        # свои шрифты из папки fonts подключаем до выбора семейств
        was_installed = set(fonts.family_map(self.root))
        self._loaded_font_files = fonts.load_font_files()
        now_installed = fonts.family_map(self.root)
        self._own_fonts = sorted(now_installed[key] for key in now_installed
                                 if key not in was_installed)
        self._families = self._available_families()
        self._text_family = self._pick_family(TEXT_FONT_STACK)
        self._mono_family = self._pick_family(MONO_FONT_STACK)
        self._clock_fonts = fonts.available(self.root)
        self._clock_family = fonts.resolve(
            config.option("clock_font"), self.root, self._mono_family)
        self._language = texts.set_language(config.option("language"))
        # в старых настройках в clock_font могла попасть подпись пункта меню
        saved_font = config.option("clock_font")
        if saved_font in ("", None) or saved_font in ("По умолчанию (моноширинный)",
                                                      "Default (monospace)"):
            config.set_option("clock_font", None)
        self._clock_font_value = self._clock_family
        self._font_preview_committed = False
        self._clock_px = 0
        self._clock_avail = 0.0
        self._clock_current = ""       # текущий текст часов (для предпросмотра)
        self._clock_suffix_text = ""   # AM/PM, если выбран 12-часовой формат
        self._clock_suffix_item = None
        self._clock_left = 0.0
        self._clock_center_y = 0.0

        self._queue: queue.Queue = queue.Queue()
        self._update_busy = False
        self.update_available = None         # найденная новая версия
        self._loading_flag = False
        self._refresh_job = None
        self._redraw_job = None
        self._geometry_job = None
        self._clock_items: list = []
        self._last_minute = -1
        self._last_date = None
        self._last_size = (0, 0)
        self._drag = None
        self._hover_cursor = ""
        self._captured = False
        self.plate: PlateWindow | None = None
        self._clock_shadow_items: list = []
        self._last_geometry = None
        self._shadow_offset_needed = False
        self._light_plate = False
        self._shadow_color = SHADOW_COLOR
        self._key_color = None
        self._intro_active = False
        self._intro_done = False
        self._intro_factor = 0.0      # подложка не видна до старта появления
        self._intro_layout_scale = None
        self._intro_hourly = False
        self._intro_redraw_pending = False
        self._intro_blocks: list = []
        self._intro_revealed = 0
        self._last_plan_scale = 1.0
        self._last_plan_hourly = False
        self.pal = theme.palette("day")
        self._size = DEFAULT_SIZE

        self._build_ui()
        # до старта появления окно полностью прозрачно: на экране не должно быть
        # ни одной части интерфейса (окно отображается позже, при update_idletasks)
        try:
            self.root.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        self._restore_geometry()
        self._load_cache()
        self._schedule(60, self._start)

    # ------------------------------------------------------------------ запуск

    def _available_families(self) -> set[str]:
        try:
            return {name.lower() for name in tkfont.families(self.root)}
        except tk.TclError:
            return set()

    def _pick_family(self, stack: list[str]) -> str:
        for name in stack:
            if name.lower() in self._families:
                return name
        return stack[-1]

    def _font(self, kind: str, px: int, weight: str = "normal") -> tkfont.Font:
        px = max(7, int(px))
        if kind == "clock":
            family = self._clock_family or self._mono_family
        elif kind == "mono":
            family = self._mono_family
        else:
            family = self._text_family
        key = (family, px, weight)
        font = self._font_cache.get(key)
        if font is None:
            if len(self._font_cache) > 600:
                self._font_cache.clear()
            font = tkfont.Font(root=self.root, family=family, size=-px, weight=weight)
            self._font_cache[key] = font
        return font

    def _build_ui(self) -> None:
        self.root.title(texts.t("window.title"))
        self.root.report_callback_exception = self._report_exception
        self.root.minsize(MIN_WIDTH, MIN_HEIGHT)
        self.canvas = tk.Canvas(self.root, highlightthickness=0, bd=0,
                                bg=TRANSPARENT_COLOR, takefocus=1)
        self.canvas.pack(fill="both", expand=True)
        self._apply_window_options()
        self._build_menu()
        self._bind_events()
        self.root.protocol("WM_DELETE_WINDOW", self.quit)

    @staticmethod
    def _spread_space(plan: dict, free: float, height: int) -> tuple[float, float]:
        """Куда девать свободное место по высоте.

        Возвращает (отступ сверху/снизу, добавка к промежуткам между блоками).
        Часть запаса уходит в поля, основная — в промежутки между блоками,
        поэтому при вытянутом окне элементы раздвигаются, а не липнут к центру.
        """
        blocks = plan["blocks"]
        if free <= 1 or len(blocks) < 2:
            return max(0.0, free / 2.0), 0.0
        pad = float(plan["pad"])
        gaps = len(blocks) - 1
        indent = min(free * 0.25, pad * 0.8)          # немного в поля
        between = (free - 2 * indent) / gaps
        # промежутки могут расти заметно (элементы раздвигаются), но не бесконечно
        limit = max(12.0, height * 0.06)
        if between > limit:
            between = limit
            indent = max(0.0, (free - between * gaps) / 2.0)
        return indent, between

    @staticmethod
    def _corner_radius(height: int) -> float:
        """Скругление углов — пропорционально размеру виджета."""
        return max(12.0, min(28.0, round(height * 0.032, 1)))

    def _apply_window_options(self) -> None:
        options = self.config.options
        try:
            self.root.attributes("-topmost", bool(options.get("topmost", True)))
        except tk.TclError:
            pass
        try:
            self.root.attributes("-alpha", float(options.get("alpha", 1.0)))
        except tk.TclError:
            pass
        self._frameless = bool(options.get("frameless", True))
        self.radius = (self._corner_radius(DEFAULT_SIZE[1])
                       if (self._frameless and options.get("rounded", True)) else 0.0)
        try:
            self.root.overrideredirect(self._frameless)
        except tk.TclError:
            pass
        try:
            self.root.attributes("-transparentcolor", TRANSPARENT_COLOR)
        except tk.TclError:
            pass
        if not self._frameless:
            self._hide_plate()
        elif self.plate is not None:
            try:
                self.plate.window.attributes("-topmost",
                                             bool(options.get("topmost", True)))
            except tk.TclError:
                pass

    # ------------------------------------------------------------------ меню

    def _build_menu(self) -> None:
        self.var_topmost = tk.BooleanVar(value=bool(self.config.option("topmost", True)))
        self.var_seconds = tk.BooleanVar(value=self._show_seconds)
        self.var_weekday = tk.BooleanVar(value=self._show_weekday)
        self.var_hourly = tk.BooleanVar(value=self._show_hourly)
        self.var_frameless = tk.BooleanVar(value=self._frameless)
        self.var_autostart = tk.BooleanVar(value=autostart.is_enabled())
        self.var_alpha = tk.DoubleVar(value=float(self.config.option("alpha", 1.0) or 1.0))
        self.var_plate_alpha = tk.DoubleVar(value=self._plate_alpha())
        self.var_clock_font = tk.StringVar(
            value=self.config.option("clock_font") or DEFAULT_FONT_VALUE)
        self.var_language = tk.StringVar(value=self._language)
        self.var_hour12 = tk.BooleanVar(value=self._hour12)
        self.var_traffic = tk.BooleanVar(value=self._show_traffic)
        self.var_icons = tk.StringVar(value=self._icon_style)
        self.var_outline = tk.BooleanVar(
            value=bool(self.config.option("text_outline", False)))
        self.var_tomorrow = tk.BooleanVar(
            value=bool(self.config.option("tomorrow", True)))
        self.var_countdown = tk.BooleanVar(
            value=bool(self.config.option("sun_countdown", False)))
        self.var_night = tk.BooleanVar(
            value=bool(self.config.option("night_dim", False)))
        self.var_games = tk.BooleanVar(
            value=bool(self.config.option("hide_fullscreen", True)))
        self.var_week = tk.BooleanVar(
            value=bool(self.config.option("week_number", True)))
        self.var_moon = tk.BooleanVar(
            value=bool(self.config.option("moon_phase", True)))
        self.var_hourly_count = tk.IntVar(
            value=int(self.config.option("hourly_count", 8) or 8))

        self.menu = self._make_menu()

    # ------------------------------------------------------------ своё меню
    def _menu_style(self) -> tuple[dict, dict]:
        """Цвета и шрифты меню — те же, что у виджета."""
        try:
            scale = max(1.0, self.root.winfo_fpixels("1i") / 96.0)
        except tk.TclError:
            scale = 1.0
        palette = menu_ui.build_palette(self.pal, self._light_plate)
        fonts = {
            "label": self._font("text", int(round(13 * scale))),
            "small": self._font("text", int(round(11 * scale))),
        }
        return palette, fonts

    def _make_menu(self) -> menu_ui.ModernMenu:
        """Собрать меню заново (вызывается при смене языка и шрифтов)."""
        palette, fonts = self._menu_style()
        topmost = bool(self.config.option("topmost", True))
        old = getattr(self, "menu", None)
        if old is not None:
            old.destroy()
        root_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       on_close=self._on_main_menu_closed,
                                       on_show=self.keep_plate_below)

        def toggle(var: tk.BooleanVar, command) -> Callable[[], None]:
            def run() -> None:
                var.set(not bool(var.get()))
                command()
            return run

        def choose(var, value, command) -> Callable[[], None]:
            def run() -> None:
                var.set(value)
                command()
            return run

        root_menu.add_command(texts.t("menu.refresh"),
                              lambda: self._request_weather(force=True), shortcut="F5")
        root_menu.add_command(texts.t("menu.city"), self.open_city_dialog,
                              shortcut="Ctrl+G")
        if self.city_alt is not None:
            root_menu.add_command(texts.t("menu.city_switch"), self.switch_city,
                                  shortcut="Ctrl+Tab")
        else:
            root_menu.add_command(texts.t("menu.city_alt_set"), self.set_alt_city)
        root_menu.add_separator()

        # ---------------------------------------------------------- «Вид»
        view_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       root_menu=False, on_show=self.keep_plate_below)

        presets_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                          root_menu=False, on_show=self.keep_plate_below)
        for preset in config_module.PRESET_ORDER:
            # готовый набор не привязан к отдельной переменной, поэтому
            # вызываем его напрямую (через choose() было бы var.set у None)
            presets_menu.add_radio(
                texts.t(f"menu.preset_{preset}"),
                (lambda preset=preset: self._apply_preset(preset)),
                (lambda preset=preset: self._current_preset() == preset))
        view_menu.add_cascade(texts.t("menu.presets"), presets_menu)
        view_menu.add_separator()
        view_menu.add_check(texts.t("menu.seconds"),
                            toggle(self.var_seconds,
                                   lambda: self._on_toggle_flag("seconds", self.var_seconds)),
                            lambda: bool(self.config.option("seconds", True)))
        view_menu.add_check(texts.t("menu.weekday"),
                            toggle(self.var_weekday,
                                   lambda: self._on_toggle_flag("weekday", self.var_weekday)),
                            lambda: bool(self.config.option("weekday", True)))
        view_menu.add_separator()

        # шрифт времени: категории и свои шрифты
        font_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       root_menu=False)
        self._build_font_menu(font_menu)
        view_menu.add_cascade(texts.t("menu.clock_font"), font_menu)

        # формат времени: 24 часа или 12 с AM/PM
        hour_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       root_menu=False)
        for label, value in ((texts.t("menu.hour24"), False),
                             (texts.t("menu.hour12"), True)):
            hour_menu.add_radio(
                label, choose(self.var_hour12, value,
                              lambda value=value: self._on_hour_format(value)),
                lambda value=value: self._hour12 == value)
        view_menu.add_cascade(texts.t("menu.hour_format"), hour_menu)

        # стиль иконок погоды
        icon_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       root_menu=False,
                                       on_show=self.keep_plate_below)
        for label, value in ((texts.t("menu.icons_vivid"), "vivid"),
                             (texts.t("menu.icons_mono"), "mono")):
            icon_menu.add_radio(
                label, choose(self.var_icons, value,
                              lambda value=value: self._on_icon_style(value)),
                lambda value=value: self._icon_style == value)
        view_menu.add_cascade(texts.t("menu.icons"), icon_menu)

        # размер виджета
        zoom_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       root_menu=False)
        zoom_menu.add_command(texts.t("menu.bigger"),
                              lambda: self._set_zoom(self.zoom + 0.12), shortcut="Ctrl +")
        zoom_menu.add_command(texts.t("menu.smaller"),
                              lambda: self._set_zoom(self.zoom - 0.12), shortcut="Ctrl −")
        zoom_menu.add_command(texts.t("menu.normal_size"),
                              lambda: self._set_zoom(1.0), shortcut="Ctrl+0")
        view_menu.add_cascade(texts.t("menu.size"), zoom_menu)
        view_menu.add_separator()
        view_menu.add_check(texts.t("menu.text_outline"),
                            toggle(self.var_outline, self._on_toggle_outline),
                            lambda: bool(self.config.option("text_outline", False)))
        root_menu.add_cascade(texts.t("menu.view"), view_menu)

        # ---------------------------------------------------------- «Данные»
        data_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       root_menu=False, on_show=self.keep_plate_below)
        data_menu.add_check(texts.t("menu.hourly"),
                            toggle(self.var_hourly,
                                   lambda: self._on_toggle_flag("hourly", self.var_hourly)),
                            lambda: bool(self.config.option("hourly", True)))
        data_menu.add_check(texts.t("menu.tomorrow"),
                            toggle(self.var_tomorrow,
                                   lambda: self._on_toggle_flag("tomorrow", self.var_tomorrow)),
                            lambda: bool(self.config.option("tomorrow", True)))
        # длина почасового ряда
        hours_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                        root_menu=False, on_show=self.keep_plate_below)
        for count in config_module.HOURLY_CHOICES:
            hours_menu.add_radio(
                texts.t("menu.hours", value=count),
                choose(self.var_hourly_count, count,
                       lambda count=count: self._on_hourly_count(count)),
                lambda count=count: int(self.config.option("hourly_count", 8) or 8) == count)
        data_menu.add_cascade(texts.t("menu.hourly_count"), hours_menu)
        data_menu.add_check(texts.t("menu.sun_countdown"),
                            toggle(self.var_countdown,
                                   lambda: self._on_toggle_flag("sun_countdown",
                                                                self.var_countdown)),
                            lambda: bool(self.config.option("sun_countdown", False)))
        data_menu.add_check(texts.t("menu.traffic"),
                            toggle(self.var_traffic, self._on_toggle_traffic),
                            lambda: self._show_traffic)
        data_menu.add_separator()
        data_menu.add_check(texts.t("menu.week"),
                            toggle(self.var_week,
                                   lambda: self._on_toggle_flag("week_number", self.var_week)),
                            lambda: bool(self.config.option("week_number", True)))
        data_menu.add_check(texts.t("menu.moon"),
                            toggle(self.var_moon,
                                   lambda: self._on_toggle_flag("moon_phase", self.var_moon)),
                            lambda: bool(self.config.option("moon_phase", True)))
        data_menu.add_check(texts.t("menu.night_dim"),
                            toggle(self.var_night,
                                   lambda: self._on_toggle_flag("night_dim", self.var_night)),
                            lambda: bool(self.config.option("night_dim", False)))
        data_menu.add_check(texts.t("menu.games"),
                            toggle(self.var_games,
                                   lambda: self._on_toggle_flag("hide_fullscreen",
                                                                self.var_games)),
                            lambda: bool(self.config.option("hide_fullscreen", True)))
        data_menu.add_command(texts.t("menu.details"), self.open_details)
        data_menu.add_command(texts.t("menu.copy"), self.copy_weather)
        root_menu.add_cascade(texts.t("menu.data"), data_menu)

        # ------------------------------------------------- «Скрыть на время»
        hide_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                       root_menu=False, on_show=self.keep_plate_below)
        hide_menu.add_command(texts.t("menu.hide_10"), lambda: self._hide_for(10))
        hide_menu.add_command(texts.t("menu.hide_60"), lambda: self._hide_for(60))
        hide_menu.add_command(texts.t("menu.hide_morning"),
                              lambda: self._hide_for(None))
        hide_menu.add_separator()
        hide_menu.add_command(texts.t("menu.hide_show"), self._toggle_visible,
                              shortcut="Ctrl+Alt+W")
        root_menu.add_cascade(texts.t("menu.hide"), hide_menu)

        # ---------------------------------------------------------- «Окно»
        window_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                         root_menu=False, on_show=self.keep_plate_below)
        window_menu.add_check(texts.t("menu.topmost"),
                              toggle(self.var_topmost, self._on_toggle_topmost),
                              lambda: bool(self.config.option("topmost")))
        window_menu.add_check(texts.t("menu.frameless"),
                              toggle(self.var_frameless, self._on_toggle_frameless),
                              lambda: bool(self.config.option("frameless", True)))
        window_menu.add_check(texts.t("menu.autostart"),
                              toggle(self.var_autostart, self._on_toggle_autostart),
                              lambda: autostart.is_enabled())
        window_menu.add_separator()

        # прозрачность содержимого
        alpha_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                        root_menu=False,
                                        on_show=self.keep_plate_below)
        for label, value in ((texts.t("menu.opaque"), 1.0), ("96 %", 0.96), ("90 %", 0.90),
                             ("80 %", 0.80), ("70 %", 0.70)):
            alpha_menu.add_radio(
                label, choose(self.var_alpha, value, self._on_alpha),
                lambda value=value: abs(float(self.config.option("alpha", 1.0) or 1.0)
                                        - value) < 1e-6)
        window_menu.add_cascade(texts.t("menu.alpha"), alpha_menu)

        # прозрачность подложки
        plate_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                        root_menu=False,
                                        on_show=self.keep_plate_below)
        for label, value in ((texts.t("menu.plate_solid"), 1.0), ("90 %", 0.90),
                             ("80 %", 0.80), ("70 %", 0.70), ("60 %", 0.60),
                             ("50 %", 0.50), ("40 %", 0.40), ("30 %", 0.30),
                             ("20 %", 0.20), ("10 %", 0.10),
                             (texts.t("menu.plate_off"), 0.0)):
            plate_menu.add_radio(
                label, choose(self.var_plate_alpha, value, self._on_plate_alpha),
                lambda value=value: abs(self._plate_alpha() - value) < 1e-6)
        window_menu.add_cascade(texts.t("menu.plate_alpha"), plate_menu)
        window_menu.add_command(texts.t("menu.plate_color"), self.open_color_dialog)
        window_menu.add_separator()

        # язык интерфейса
        language_menu = menu_ui.ModernMenu(self.root, fonts, palette, topmost=topmost,
                                           root_menu=False)
        for code, title in (("ru", "Русский"), ("en", "English")):
            language_menu.add_radio(
                title, choose(self.var_language, code, lambda: self._on_language(code)),
                lambda code=code: self._language == code)
        window_menu.add_cascade("Язык / Language", language_menu)
        window_menu.add_separator()
        window_menu.add_command(texts.t("menu.updates"),
                                lambda: self.check_updates(manual=True))
        root_menu.add_cascade(texts.t("menu.window"), window_menu)

        root_menu.add_separator()
        root_menu.add_command(texts.t("menu.about"), self.open_about_dialog)
        root_menu.add_command(texts.t("menu.quit"), self.quit, shortcut="Ctrl+Q")
        return root_menu

    @staticmethod
    def _same_setting(current, wanted) -> bool:
        """Сравнить настройку с образцом: числа сравниваем как числа, не как флаги."""
        if isinstance(wanted, bool):
            return bool(current) == wanted
        try:
            return float(current) == float(wanted)
        except (TypeError, ValueError):
            return current == wanted

    def _current_preset(self) -> str:
        """Какой готовый набор сейчас подходит под настройки (или пусто)."""
        for preset in config_module.PRESET_ORDER:
            values = config_module.PRESETS[preset]
            if all(self._same_setting(self.config.option(key), value)
                   for key, value in values.items()):
                return preset
        return ""

    def _apply_preset(self, preset: str) -> None:
        """Включить готовый набор вида: часы, блоки, пробки, отсчёт."""
        values = config_module.PRESETS.get(preset)
        if not values:
            return
        for key, value in values.items():
            # значения сохраняем как есть: bool() превратил бы 12 часов в True
            self.config.set_option(key, value)
        self.var_seconds.set(bool(values.get("seconds")))
        self.var_weekday.set(bool(values.get("weekday")))
        self.var_hourly.set(bool(values.get("hourly")))
        self.var_traffic.set(bool(values.get("traffic")))
        self.var_tomorrow.set(bool(values.get("tomorrow")))
        self.var_countdown.set(bool(values.get("sun_countdown")))
        self.var_week.set(bool(values.get("week_number")))
        self.var_moon.set(bool(values.get("moon_phase")))
        self.var_hourly_count.set(int(values.get("hourly_count", 8)))
        # кэш признаков, по которым строится раскладка, тоже обновляем
        self._show_seconds = bool(values.get("seconds"))
        self._show_weekday = bool(values.get("weekday"))
        self._show_hourly = bool(values.get("hourly"))
        self._show_traffic = bool(values.get("traffic"))
        self._save_config()
        self._refresh_derived()
        self._redraw(force=True)
        self._rebuild_menu()
        if self._show_traffic and self.city is not None:
            self._load_traffic(self.city)

    def open_about_dialog(self) -> None:
        """Окно «Информация о виджете»: версия, назначение, авторы."""
        self.keep_plate_below()
        ask_about(self.root, self.pal)
        self.keep_plate_below()

    def _build_font_menu(self, parent: menu_ui.ModernMenu) -> None:
        """Наполнить подменю «Шрифт времени» (категории, свои шрифты)."""
        confirmed = self.config.option("clock_font") or None

        def pick(name: str | None):
            def run() -> None:
                self.var_clock_font.set(name or DEFAULT_FONT_VALUE)
                self._on_clock_font()
            return run

        def is_current(name: str | None):
            return lambda: confirmed == name

        parent.add_radio(texts.t("menu.font_default"), pick(None), is_current(None),
                         on_hover=lambda: self._preview_clock_font(None))
        parent.add_separator()
        group_titles = {"Тонкие": "menu.font_thin", "Средние": "menu.font_medium",
                        "Широкие": "menu.font_wide"}
        for title, names in fonts.categories(self._clock_fonts):
            group_menu = menu_ui.ModernMenu(self.root, parent.fonts, parent.pal,
                                            topmost=parent.topmost, root_menu=False,
                                            on_show=parent.on_show)
            for name in names:
                group_menu.add_radio(name, pick(name), is_current(name),
                                     on_hover=lambda name=name: self._preview_clock_font(name))
            parent.add_cascade(texts.t(group_titles.get(title, title)), group_menu)

        own_menu = menu_ui.ModernMenu(self.root, parent.fonts, parent.pal,
                                      topmost=parent.topmost, root_menu=False,
                                            on_show=parent.on_show)
        own_menu.add_command(texts.t("menu.font_load"), self._on_load_custom_fonts)
        own_menu.add_command(texts.t("menu.font_open"), self._on_open_fonts_folder)
        if self._own_fonts:
            own_menu.add_separator()
            for name in self._own_fonts:
                own_menu.add_radio(name, pick(name), is_current(name),
                                   on_hover=lambda name=name: self._preview_clock_font(name))
        else:
            own_menu.add_separator()
            own_menu.add_command(texts.t("menu.font_none"), None, enabled=False)
        parent.add_cascade(texts.t("menu.font_mine"), own_menu)

    def _on_language(self, code: str | None = None) -> None:
        """Переключить язык интерфейса (значок RU | EN или пункт меню)."""
        chosen = texts.set_language(code if code is not None else self.var_language.get())
        if chosen == self._language and code is None:
            # всё равно перерисуем: могли выбрать тот же язык
            self._redraw()
            return
        self._language = chosen
        self.var_language.set(chosen)
        self.config.set_option("language", chosen)
        self._save_config()
        # подписи виджета рисуются заново, а меню нужно собрать заново
        self.status_note = ""
        self._rebuild_menu()
        self._refresh_texts()
        self._redraw()

    def _rebuild_menu(self) -> None:
        """Собрать меню заново (после смены языка или списка шрифтов)."""
        self.menu = self._make_menu()

    def _refresh_texts(self) -> None:
        """Пересобрать тексты виджета на новом языке."""
        if self.data is not None:
            self.precip_text = analysis.outlook_text(self.outlook)
            stamp = ru.format_hhmm(self.data.fetched_at) if self.data.fetched_at else "—"
            self.footer_text = texts.t("footer.updated", stamp=stamp,
                                       source=self.source_name)
        else:
            self.precip_text = texts.t("precip.waiting")
            self.footer_text = self.status_error or self.status_note

    def keep_plate_below(self) -> None:
        """Вернуть подложку под содержимое.

        Показ или закрытие меню (ещё одного topmost-окна) перестраивает порядок
        верхних окон, и подложка может всплыть над текстом — тогда на экране
        остаётся одна панель. Поэтому порядок окон восстанавливаем явно: и перед
        показом меню, и после его закрытия.
        """
        if not self._plate_visible():
            return
        try:
            self._sync_plate(self.root.winfo_x(), self.root.winfo_y(),
                             self.root.winfo_width(), self.root.winfo_height())
        except tk.TclError:
            pass

    def _popup_menu(self, x_root: int, y_root: int) -> None:
        self._font_preview_committed = False
        self.var_topmost.set(bool(self.config.option("topmost")))
        self.var_frameless.set(self._frameless)
        self.var_seconds.set(self._show_seconds)
        self.var_weekday.set(self._show_weekday)
        self.var_hourly.set(self._show_hourly)
        self.var_alpha.set(float(self.config.option("alpha", 1.0) or 1.0))
        self.var_plate_alpha.set(self._plate_alpha())
        self.var_autostart.set(autostart.is_enabled())
        self.var_language.set(self._language)
        self.var_hour12.set(self._hour12)
        self.keep_plate_below()
        try:
            self.menu.popup(x_root, y_root)
        except tk.TclError:
            pass
        # меню — тоже topmost-окно, после его показа порядок окон проверяем снова
        self.root.after(30, self.keep_plate_below)

    def _on_toggle_topmost(self) -> None:
        value = bool(self.var_topmost.get())
        self.config.set_option("topmost", value)
        for window in (self.root, self.plate.window if self.plate else None):
            if window is None:
                continue
            try:
                window.attributes("-topmost", value)
            except tk.TclError:
                pass
        self._save_config()

    def _on_toggle_frameless(self) -> None:
        geometry = self.root.geometry()
        self.config.set_option("frameless", bool(self.var_frameless.get()))
        self._apply_window_options()
        self.root.update_idletasks()
        self.root.geometry(geometry)
        self._save_config()
        self._schedule_redraw(10)

    def _on_toggle_autostart(self) -> None:
        """Включить/выключить запуск виджета при входе в систему."""
        want = bool(self.var_autostart.get())
        try:
            if want:
                path = autostart.enable()
                note = texts.t("note.autostart_on", path=path)
            else:
                autostart.disable()
                note = texts.t("note.autostart_off")
        except OSError as exc:
            self.var_autostart.set(not want)
            message = texts.t("note.autostart_failed", error=exc)
            print(message)
            try:
                from tkinter import messagebox

                messagebox.showerror(texts.t("title.autostart"), message)
            except tk.TclError:
                pass
            return
        self.status_note = note
        print(note)

    def _on_icon_style(self, style: str) -> None:
        """Переключить стиль иконок погоды: объёмный или монохромный."""
        self._icon_style = style if style in theme.ICON_STYLES else "mono"
        self.config.set_option("icon_style", self._icon_style)
        self._save_config()
        self._redraw()

    def _on_hourly_count(self, count: int) -> None:
        """Сколько часов показывать в почасовом ряду."""
        self.config.set_option("hourly_count", int(count))
        self.var_hourly_count.set(int(count))
        self._save_config()
        self._refresh_derived()
        self._redraw(force=True)

    def _on_toggle_outline(self) -> None:
        """Включить или выключить тёмную обводку текста."""
        self.config.set_option("text_outline", bool(self.var_outline.get()))
        self._save_config()
        self._redraw()

    def _on_toggle_traffic(self) -> None:
        """Включить или выключить блок пробок."""
        self._show_traffic = bool(self.var_traffic.get())
        self.config.set_option("traffic", self._show_traffic)
        self._save_config()
        if self._show_traffic and self.traffic is None:
            self.traffic = traffic_mod.demo_score(self.city.name if self.city else "город")
        self._redraw()
        if self._show_traffic:
            threading.Thread(target=self._load_traffic, args=(self.city,),
                             daemon=True).start()

    def _on_hour_format(self, hour12: bool) -> None:
        """Переключить 24-часовой и 12-часовой формат времени."""
        self._hour12 = bool(hour12)
        self.config.set_option("hour12", self._hour12)
        self._font_cache.clear()
        self._save_config()
        self._redraw()

    def _on_toggle_flag(self, key: str, var: tk.BooleanVar) -> None:
        value = bool(var.get())
        self.config.set_option(key, value)
        if key == "seconds":
            self._show_seconds = value
        elif key == "weekday":
            self._show_weekday = value
        elif key == "hourly":
            self._show_hourly = value
        elif key == "hour12":
            self._hour12 = value
        self._save_config()
        self._redraw()

    def _on_alpha(self) -> None:
        value = float(self.var_alpha.get())
        self.config.set_option("alpha", value)
        try:
            self.root.attributes("-alpha", value)
        except tk.TclError:
            pass
        self._save_config()

    def _on_plate_alpha(self) -> None:
        value = max(0.0, min(1.0, float(self.var_plate_alpha.get())))
        self.config.set_option("plate_alpha", value)
        self._save_config()
        self._redraw()

    def open_color_dialog(self) -> None:
        """Настройка цвета подложки в RGB."""
        top_color, bottom_color = theme.plate_colors(
            self.pal, self.config.option("plate_top"), self.config.option("plate_bottom"))
        chosen = ask_plate_colors(self.root, self.config.option("plate_top"),
                                  self.config.option("plate_bottom"),
                                  top_color, bottom_color, palette=self.pal)
        if chosen is None:
            return
        top, bottom = chosen
        self.config.set_option("plate_top", top)
        self.config.set_option("plate_bottom", bottom)
        self._save_config()
        self._redraw()

    def _on_load_custom_fonts(self) -> None:
        """Загрузить свои шрифты: файлы копируются в папку рядом с виджетом."""
        from tkinter import filedialog, messagebox

        was_topmost = bool(self.config.option("topmost"))
        try:
            if was_topmost:
                self.root.attributes("-topmost", False)
            chosen = filedialog.askopenfilenames(
                parent=self.root, title=texts.t("fonts.choose"),
                filetypes=[(texts.t("fonts.filter"), "*.ttf *.otf *.ttc"),
                           (texts.t("files.all"), "*.*")])
        except tk.TclError:
            chosen = ()
        finally:
            if was_topmost:
                try:
                    self.root.attributes("-topmost", True)
                except tk.TclError:
                    pass
            self.root.lift()
        if not chosen:
            return

        added: list[str] = []
        for path in chosen:
            family = fonts.import_font_file(path, self.root)
            if family and family not in self._own_fonts:
                added.append(family)
        self._font_cache.clear()
        if added:
            # новый шрифт сразу показываем в часах, остаётся только любоваться
            self._own_fonts = sorted(set(self._own_fonts) | set(added))
            self._rebuild_menu()
            self.var_clock_font.set(added[0])
            self._on_clock_font()
            note = texts.t("fonts.loaded", count=len(chosen), family=added[0])
        else:
            self._rebuild_menu()
            self._redraw()
            note = texts.t("fonts.added", count=len(chosen))
            if not self._own_fonts:
                note += texts.t("fonts.restart_hint")
        print(note)
        try:
            messagebox.showinfo(texts.t("fonts.title"), note)
        except tk.TclError:
            pass

    def _on_open_fonts_folder(self) -> None:
        """Открыть папку со своими шрифтами в проводнике."""
        folder = fonts.fonts_folder()
        try:
            folder.mkdir(parents=True, exist_ok=True)
            os.startfile(str(folder))          # noqa: S606 — Windows-специфично
        except (OSError, AttributeError) as exc:
            print(texts.t("fonts.open_failed", error=exc))

    def _preview_clock_font(self, family: str | None) -> None:
        """Мгновенно показать шрифт в часах, не пересобирая всю раскладку."""
        if not self._clock_items:
            return
        if family in ("", DEFAULT_FONT_VALUE, texts.t("menu.font_default")):
            family = None
        resolved = fonts.resolve(family, self.root, self._mono_family)
        if resolved == self._clock_family and family == self._clock_font_value:
            return
        size = self._clock_px
        font = self._font_for_family(resolved, size, "bold")
        cell = max(font.measure(char) for char in "0123456789:")
        width = cell * len(self._clock_current)
        # если широкий шрифт не влезает по ширине — уменьшаем кегль
        while width > self._clock_avail and size > 10:
            size -= 2
            font = self._font_for_family(resolved, size, "bold")
            cell = max(font.measure(char) for char in "0123456789:")
            width = cell * len(self._clock_current)
        left = self._size[0] / 2.0 - width / 2.0
        centre_y = self._clock_center_y
        self._clock_left = left
        for index, item in enumerate(self._clock_items):
            x = left + cell * index + cell / 2.0
            old = self.canvas.coords(item)
            self.canvas.itemconfigure(item, font=font)
            self.canvas.coords(item, x, centre_y)
            shadows = (self._clock_shadow_items[index]
                       if index < len(self._clock_shadow_items) else [])
            for shadow in shadows:
                coords = self.canvas.coords(shadow)
                offset_x = coords[0] - old[0] if len(old) >= 2 and len(coords) >= 2 else 0.0
                offset_y = coords[1] - old[1] if len(old) >= 2 and len(coords) >= 2 else 0.0
                self.canvas.itemconfigure(shadow, font=font)
                self.canvas.coords(shadow, x + offset_x, centre_y + offset_y)
        # AM/PM переезжает вместе с цифрами и меняет кегль под новый шрифт
        if self._clock_suffix_item is not None and self._clock_suffix_text:
            ampm_font = self._font_for_family(resolved, max(9, int(size * 0.30)), "bold")
            ampm_gap = int(size * 0.22)
            width_total = width + ampm_gap + ampm_font.measure(self._clock_suffix_text)
            left = self._size[0] / 2.0 - width_total / 2.0
            self._clock_left = left
            for index, item in enumerate(self._clock_items):
                self.canvas.coords(item, left + cell * index + cell / 2.0, centre_y)
            baseline = centre_y + font.metrics("ascent") * 0.30
            self.canvas.itemconfigure(self._clock_suffix_item, font=ampm_font)
            self.canvas.coords(self._clock_suffix_item, left + width + ampm_gap, baseline)
        self._clock_family = resolved

    def _font_for_family(self, family: str, px: int, weight: str) -> tkfont.Font:
        """Шрифт заданного семейства (без учёта текущего выбора)."""
        key = (family, max(7, int(px)), weight)
        font = self._font_cache.get(key)
        if font is None:
            if len(self._font_cache) > 600:
                self._font_cache.clear()
            font = tkfont.Font(root=self.root, family=family, size=-max(7, int(px)),
                               weight=weight)
            self._font_cache[key] = font
        return font

    def _on_main_menu_closed(self) -> None:
        """Меню закрыли: вернуть порядок окон и прежний шрифт, если не подтвердили."""
        self.keep_plate_below()
        if self._font_preview_committed:
            self._font_preview_committed = False
            return
        if self._clock_family != self._clock_font_value:
            self._preview_clock_font(self._clock_font_value)

    def _on_clock_font(self) -> None:
        """Подтвердить выбранный шрифт времени."""
        chosen = self.var_clock_font.get()
        if chosen in ("", DEFAULT_FONT_VALUE, texts.t("menu.font_default")):
            chosen = None
        self._clock_family = fonts.resolve(chosen, self.root, self._mono_family)
        self._clock_font_value = self._clock_family
        self._font_preview_committed = True
        self.config.set_option("clock_font", chosen)
        self._font_cache.clear()
        self._save_config()
        self._redraw()

    def _set_zoom(self, value: float) -> None:
        """Масштаб содержимого.

        Содержимое всегда заполняет окно целиком, поэтому «крупнее/мельче» —
        это изменение размера окна: 100 % = 420x640 (с поправкой на масштаб
        экрана), 150 % — в полтора раза больше и так далее.
        """
        value = max(0.6, min(2.0, round(value, 3)))
        base_w, base_h = self._base_size()
        width = max(MIN_WIDTH, int(round(base_w * value)))
        height = max(MIN_HEIGHT, int(round(base_h * value)))
        x, y = self.root.winfo_x(), self.root.winfo_y()
        try:
            screen_w = self.root.winfo_screenwidth()
            screen_h = self.root.winfo_screenheight()
            x = max(0, min(x, max(0, screen_w - width)))
            y = max(0, min(y, max(0, screen_h - height)))
        except tk.TclError:
            pass
        self.zoom = value
        self.config.set_option("zoom", value)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        self._sync_plate(x, y, width, height)
        self._save_config()
        self._schedule_redraw(10)

    # ------------------------------------------------------------------ события

    def _bind_events(self) -> None:
        c = self.canvas
        c.bind("<Button-1>", self._on_press)
        c.bind("<B1-Motion>", self._on_motion)
        c.bind("<ButtonRelease-1>", self._on_release)
        c.bind("<Motion>", self._on_hover)
        c.bind("<Button-3>", lambda event: self._popup_menu(event.x_root, event.y_root))
        c.bind("<Double-Button-1>", lambda event: self._request_weather(force=True))
        c.bind("<MouseWheel>", self._on_wheel)
        c.bind("<Control-MouseWheel>", self._on_wheel)
        self.root.bind("<Configure>", self._on_configure)
        self.root.bind("<F5>", lambda event: self._request_weather(force=True))
        self.root.bind("<Control-g>", lambda event: self.open_city_dialog())
        self.root.bind("<Control-G>", lambda event: self.open_city_dialog())
        self.root.bind("<Control-q>", lambda event: self.quit())
        self.root.bind("<Control-plus>", lambda event: self._set_zoom(self.zoom + 0.12))
        self.root.bind("<Control-equal>", lambda event: self._set_zoom(self.zoom + 0.12))
        self.root.bind("<Control-minus>", lambda event: self._set_zoom(self.zoom - 0.12))
        self.root.bind("<Control-Key-0>", lambda event: self._set_zoom(1.0))

    def _on_wheel(self, event) -> None:
        if event.state & 0x0004:  # Ctrl зажат — размер виджета
            self._set_zoom(self.zoom + (0.06 if event.delta > 0 else -0.06))
        return "break"

    def _on_configure(self, event) -> None:
        if event.widget is not self.root:
            return
        geometry = (event.x, event.y, event.width, event.height)
        moved_or_resized = geometry != self._last_geometry
        self._last_geometry = geometry
        if self._intro_active:
            # во время появления размером и подложкой управляет анимация;
            # раскладку пересобираем сразу, без таймера — иначе кадры «плывут»
            self._last_size = (event.width, event.height)
            if moved_or_resized:
                self._redraw(force=True)
            return
        if moved_or_resized and self._plate_visible():
            # подложка едет и меняет размер вместе с окном
            top_color, bottom_color = theme.plate_colors(
                self.pal, self.config.option("plate_top"),
                self.config.option("plate_bottom"))
            self._update_plate(event.width, event.height, top_color, bottom_color)
        size = (event.width, event.height)
        if size == self._last_size:
            return
        self._last_size = size
        self._schedule_redraw()
        self._schedule_geometry_save()

    def _hit_zone(self, x: float, y: float) -> str | None:
        if not self._frameless:
            return None
        w, h = self.root.winfo_width(), self.root.winfo_height()
        left, right = x <= EDGE_ZONE, x >= w - EDGE_ZONE
        top, bottom = y <= EDGE_ZONE, y >= h - EDGE_ZONE
        if bottom and right:
            return "se"
        if bottom and left:
            return "sw"
        if top and right:
            return "ne"
        if top and left:
            return "nw"
        if left:
            return "w"
        if right:
            return "e"
        if top:
            return "n"
        if bottom:
            return "s"
        return None

    def _on_press(self, event) -> None:
        try:
            self.root.focus_force()
        except tk.TclError:
            pass
        # клик по подложке мог поднять её над текстом — сразу возвращаем на место
        if self._plate_visible():
            self._sync_plate(self.root.winfo_x(), self.root.winfo_y(),
                             self.root.winfo_width(), self.root.winfo_height())
        if not self._frameless:
            return
        zone = self._hit_zone(event.x, event.y)
        if zone:
            self._drag = {
                "mode": "resize", "zone": zone,
                "x": event.x_root, "y": event.y_root,
                "geometry": (self.root.winfo_x(), self.root.winfo_y(),
                             self.root.winfo_width(), self.root.winfo_height()),
            }
            return
        for name, rect in self._btn_rects.items():
            if rect[0] <= event.x <= rect[2] and rect[1] <= event.y <= rect[3]:
                if name == "settings":
                    self._popup_menu(self.root.winfo_rootx() + int(rect[0]),
                                     self.root.winfo_rooty() + int(rect[3]) + 4)
                elif name == "close":
                    self.quit()
                elif name == "about":
                    self.open_about_dialog()
                elif name == "details_weather":
                    self.open_details()
                elif name == "city_switch":
                    self.switch_city()
                elif name == "update":
                    self.open_update_card()
                elif name.startswith("lang_"):
                    self._on_language(name.split("_", 1)[1])
                return
        self._drag = {
            "mode": "move", "x": event.x_root, "y": event.y_root,
            "geometry": (self.root.winfo_x(), self.root.winfo_y(),
                         self.root.winfo_width(), self.root.winfo_height()),
        }

    def _on_motion(self, event) -> None:
        if not self._drag:
            return
        drag = self._drag
        x0, y0, w0, h0 = drag["geometry"]
        dx = event.x_root - drag["x"]
        dy = event.y_root - drag["y"]
        if drag["mode"] == "move":
            nx, ny = x0 + dx, y0 + dy
            self.root.geometry(f"+{nx}+{ny}")
            self._sync_plate(nx, ny, w0, h0)
            return
        zone = drag["zone"]
        x, y, w, h = x0, y0, w0, h0
        if "e" in zone:
            w = max(MIN_WIDTH, w0 + dx)
        if "s" in zone:
            h = max(MIN_HEIGHT, h0 + dy)
        if "w" in zone:
            w = max(MIN_WIDTH, w0 - dx)
            x = x0 + (w0 - w)
        if "n" in zone:
            h = max(MIN_HEIGHT, h0 - dy)
            y = y0 + (h0 - h)
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self._sync_plate(x, y, w, h)

    def _on_release(self, event) -> None:
        if self._drag:
            self._drag = None
            self._schedule_geometry_save(400)

    def _on_hover(self, event) -> None:
        if not self._frameless:
            return
        cursor = "fleur"
        zone = self._hit_zone(event.x, event.y)
        mapping = {"n": "size_ns", "s": "size_ns", "e": "size_we", "w": "size_we",
                   "ne": "size_ne_sw", "sw": "size_ne_sw",
                   "nw": "size_nw_se", "se": "size_nw_se"}
        if zone:
            cursor = mapping.get(zone, "arrow")
        else:
            for name, rect in self._btn_rects.items():
                if rect[0] <= event.x <= rect[2] and rect[1] <= event.y <= rect[3]:
                    cursor = "hand2"
                    break
        if cursor != self._hover_cursor:
            self._hover_cursor = cursor
            targets = [self.canvas]
            if self.plate is not None:
                targets.append(self.plate.canvas)
            for target in targets:
                try:
                    target.configure(cursor=cursor)
                except tk.TclError:
                    pass

    # ------------------------------------------------------------------ таймеры

    def _schedule(self, delay_ms: int, callback, *args):
        return self.root.after(delay_ms, callback, *args)

    def _schedule_redraw(self, delay_ms: int = 35) -> None:
        if self._redraw_job:
            self.root.after_cancel(self._redraw_job)
        self._redraw_job = self.root.after(delay_ms, self._redraw)

    def _schedule_geometry_save(self, delay_ms: int = 1200) -> None:
        if self._geometry_job:
            self.root.after_cancel(self._geometry_job)
        self._geometry_job = self.root.after(delay_ms, self._save_geometry)

    def _save_geometry(self) -> None:
        self._geometry_job = None
        try:
            self.config.geometry = self.root.geometry()
        except tk.TclError:
            return
        # масштаб в меню должен отражать фактический размер окна
        _, base_h = self._base_size()
        if base_h:
            self.zoom = max(0.6, min(2.0, round(self.root.winfo_height() / base_h, 2)))
            self.config.set_option("zoom", self.zoom)
        self._save_config()

    def _save_config(self) -> None:
        try:
            self.config.save()
        except Exception:
            pass

    def _report_exception(self, exc_type, value, tb) -> None:
        """Любая ошибка в обработчике Tk — в файл рядом с виджетом и в консоль."""
        log_error("обработчик Tk", value, tb)
        traceback.print_exception(exc_type, value, tb)

    def _base_size(self) -> tuple[int, int]:
        """Размер окна «обычного размера» (420x640 с поправкой на масштаб экрана)."""
        scale = 1.0
        try:
            scale = max(1.0, self.root.winfo_fpixels("1i") / 96.0)
        except tk.TclError:
            pass
        return int(round(DEFAULT_SIZE[0] * scale)), int(round(DEFAULT_SIZE[1] * scale))

    def _restore_geometry(self) -> None:
        base_w, base_h = self._base_size()
        geometry = self.config.geometry
        if geometry:
            try:
                self.root.geometry(geometry)
                self.root.update_idletasks()
                self.zoom = max(0.6, min(2.0, round(self.root.winfo_height() / base_h, 2)))
                return
            except tk.TclError:
                pass
        try:
            screen_w = self.root.winfo_screenwidth()
        except tk.TclError:
            screen_w = 1920
        width = int(round(base_w * self.zoom))
        height = int(round(base_h * self.zoom))
        self.root.geometry(f"{width}x{height}+{max(0, screen_w - width - 60)}+70")

    def _load_cache(self) -> None:
        cached = self.config.load_cache()
        if not cached or not self.city:
            return
        raw, fetched_at = cached
        try:
            self.data = api.load_cached_weather(raw, fetched_at)
            self.source_name = self.data.source
        except Exception:
            self.data = None

    # ------------------------------------------------------------------ запуск и данные

    def _start(self) -> None:
        self._refresh_derived()
        self._redraw()
        self._tick()
        self._poll_queue()
        # возврат из «скрыть на время», горячая клавиша и полноэкранные игры
        self._hide_tick()
        self._register_hotkey()
        self._poll_hotkey()
        self._check_fullscreen()
        self.check_updates()
        if self.screenshot_path:
            self.root.after(30000, self._capture)
        self._start_intro()
        if self.city:
            self._request_weather(force=True)
        else:
            self._detect_city()

    # ------------------------------------------------------------------ появление

    def _content_alpha(self) -> float:
        """Прозрачность содержимого из настроек (не ниже 10 %)."""
        try:
            alpha = max(0.0, min(1.0, float(self.config.option("alpha", 1.0))))
        except (TypeError, ValueError):
            alpha = 1.0
        if self.config.option("night_dim", False) and self._night_now():
            alpha *= NIGHT_DIM_FACTOR
        return alpha

    def _night_now(self) -> bool:
        """Сейчас ночь по времени города (для ночного приглушения)."""
        data = self.data
        if data is None:
            return False
        day = data.today()
        return ru.daypart(data.now_local(), day.sunrise if day else None,
                          day.sunset if day else None) == "night"

    def _start_intro(self) -> None:
        """Подложка появляется, затем блоки всплывают по одному сверху вниз."""
        if self._intro_done:
            return
        self._intro_done = True
        if self.screenshot_path:
            # в режиме снимка анимация не нужна — сразу показываем результат
            self._intro_factor = 1.0
            try:
                self.root.attributes("-alpha", self._content_alpha())
            except tk.TclError:
                pass
            self._redraw(force=True)
            self._sync_plate(self.root.winfo_x(), self.root.winfo_y(),
                             self.root.winfo_width(), self.root.winfo_height())
            return
        self._intro_active = True
        self._intro_factor = 0.0
        self._intro_layout_scale = self._last_plan_scale
        self._intro_hourly = self._last_plan_hourly
        target = (self.root.winfo_x(), self.root.winfo_y(),
                  self.root.winfo_width(), self.root.winfo_height())
        # блоки уже нарисованы — прячем и показываем по одному сверху вниз
        self._intro_blocks = [tag for tag in BLOCK_TAGS if self.canvas.find_withtag(tag)]
        self._intro_revealed = 0
        for tag in self._intro_blocks:
            self.canvas.itemconfigure(tag, state="hidden")
        start_time = time.perf_counter()

        def ease_out_quad(value: float) -> float:
            return 1.0 - (1.0 - value) ** 2

        def smoothstep(value: float) -> float:
            return value * value * (3.0 - 2.0 * value)

        def frame(index: int) -> None:
            if not self._intro_active:
                return
            # по реальному времени: появление укладывается ровно в секунду
            # и не растягивается, даже если отдельный кадр «опоздал»
            elapsed = (time.perf_counter() - start_time) * 1000.0
            # 1) подложка: проявляется и чуть подрастает
            material = min(1.0, elapsed / float(INTRO_PLATE_MS))
            self._intro_factor = ease_out_quad(material)
            size = INTRO_SCALE_FROM + (1.0 - INTRO_SCALE_FROM) * smoothstep(material)
            view_width = max(MIN_WIDTH, int(round(target[2] * size)))
            view_height = max(MIN_HEIGHT, int(round(target[3] * size)))
            self._sync_plate(target[0] + (target[2] - view_width) // 2,
                             target[1] + (target[3] - view_height) // 2,
                             view_width, view_height)
            # 2) блоки всплывают по одному сверху вниз
            if elapsed >= INTRO_BLOCKS_START_MS:
                count = 1 + int((elapsed - INTRO_BLOCKS_START_MS) / INTRO_BLOCK_STEP_MS)
                self._reveal_blocks(count)
            # 3) содержимое мягко набирает плотность: каждый блок появляется
            #    на своей прозрачности и потому не «выскакивает» резко
            span = max(1.0, INTRO_ALPHA_MS - INTRO_ALPHA_START_MS)
            share = (elapsed - INTRO_ALPHA_START_MS) / span
            content = ease_out_quad(min(1.0, max(0.0, share)))
            try:
                self.root.attributes("-alpha", self._content_alpha() * content)
            except tk.TclError:
                pass
            if elapsed < INTRO_MS:
                self.root.after(INTRO_FRAME_MS, lambda: frame(index + 1))
            else:
                self._finish_intro(target)

        frame(1)

    def _reveal_blocks(self, count: int) -> None:
        """Показать первые count блоков (остальные остаются скрытыми)."""
        blocks = getattr(self, "_intro_blocks", [])
        while self._intro_revealed < min(count, len(blocks)):
            self.canvas.itemconfigure(blocks[self._intro_revealed], state="normal")
            self._intro_revealed += 1

    def _reveal_all_blocks(self) -> None:
        self._reveal_blocks(len(getattr(self, "_intro_blocks", [])))

    def _finish_intro(self, target: tuple) -> None:
        self._intro_active = False
        self._intro_factor = 1.0
        self._reveal_all_blocks()
        try:
            self.root.attributes("-alpha", self._content_alpha())
        except tk.TclError:
            pass
        self.root.geometry(f"{target[2]}x{target[3]}+{target[0]}+{target[1]}")
        self._sync_plate(target[0], target[1], target[2], target[3])
        self._last_size = (target[2], target[3])
        self._schedule_redraw(10)
        self._schedule_geometry_save(800)

    def _detect_city(self) -> None:
        self.status_note = "определяю город по сети…"
        self._refresh_derived()
        self._redraw()
        threading.Thread(target=self._detect_worker, daemon=True).start()

    def _detect_worker(self) -> None:
        try:
            city = api.locate_by_ip()
            self._queue.put(("city", city, None))
        except Exception as exc:
            self._queue.put(("city", None, str(exc)))

    def _request_weather(self, force: bool = False) -> None:
        if not self.city or self._loading_flag:
            return
        if self._refresh_job:
            self.root.after_cancel(self._refresh_job)
            self._refresh_job = None
        self._loading_flag = True
        self.status_note = texts.t("status.refreshing")
        self._refresh_derived()
        self._redraw()
        threading.Thread(target=self._weather_worker, args=(self.city,), daemon=True).start()

    def _weather_worker(self, city: api.City) -> None:
        try:
            raw, source = api.fetch_weather(city)
            self._queue.put(("weather", (raw, source), None))
        except Exception as exc:
            self._queue.put(("weather", None, str(exc)))
        self._load_traffic(city)

    def _load_traffic(self, city: api.City) -> None:
        """Пробки грузим отдельно: сервис может ответить, даже если погода нет."""
        if not self._show_traffic:
            return
        try:
            data = traffic_mod.fetch(city, demo=True)
        except Exception as exc:                # noqa: BLE001 — блок не обязателен
            log_error("пробки", exc, exc.__traceback__)
            data = None
        self._queue.put(("traffic", data, None))

    def _poll_queue(self) -> None:
        while True:
            try:
                kind, payload, error = self._queue.get_nowait()
            except queue.Empty:
                break
            if kind == "city":
                self._apply_city(payload, error)
            elif kind == "weather":
                self._apply_weather(payload, error)
            elif kind == "traffic":
                self.traffic = payload
                self._redraw()
            elif kind == "update":
                self._apply_update_result(payload.get("found"),
                                          bool(payload.get("manual")))
        self.root.after(250, self._poll_queue)

    def _apply_city(self, city: api.City | None, error: str | None) -> None:
        if city is None:
            self.status_error = error or "не удалось определить город"
            self.status_note = "выберите город вручную (Ctrl+G)"
            self._refresh_derived()
            self._redraw()
            return
        self.city = city
        self.config.city = city
        self._save_config()
        self.status_note = "загружаю прогноз…"
        self._request_weather(force=True)

    def _apply_weather(self, payload, error: str | None) -> None:
        self._loading_flag = False
        raw = None
        if isinstance(payload, tuple):
            raw, self.source_name = payload
        elif isinstance(payload, dict):
            raw = payload
        if raw is not None:
            try:
                self.data = api.parse_weather(raw)
                self.source_name = self.data.source
                self.config.store_cache(raw)
                self._save_config()
                self.status_error = None
                self.status_note = ""
            except Exception as exc:  # повреждённый ответ
                self.status_error = f"не удалось разобрать данные: {exc}"
            delay = max(1, self.config.refresh_minutes) * 60 * 1000
        else:
            self.status_error = error or texts.t("status.offline")
            delay = 2 * 60 * 1000
        self._refresh_derived()
        self._redraw()
        if self._refresh_job:
            self.root.after_cancel(self._refresh_job)
        self._refresh_job = self.root.after(delay, lambda: self._request_weather(force=True))
        if self.screenshot_path and raw is not None:
            self.root.after(900, self._capture)

    def _refresh_derived(self) -> None:
        data = self.data
        if data is not None:
            self.outlook = analysis.analyze_precipitation(data)
            self.daylight = analysis.daylight_state(data)
            self._hourly_points = analysis.hourly_strip(
                data, int(self.config.option("hourly_count", 8) or 8))
            self.precip_text = analysis.outlook_text(self.outlook)
            self._compute_pressure_trend()
            stamp = data.fetched_at.strftime("%H:%M") if data.fetched_at else "—"
            age = data.age_minutes()
            if self._loading_flag and not self.status_error:
                self.footer_text = texts.t("footer.refreshing", stamp=stamp)
                self.footer_warn = False
            elif self.status_error:
                self.footer_text = texts.t("footer.offline", stamp=stamp)
                self.footer_warn = True
            elif age > 45:
                self.footer_text = texts.t("footer.stale", stamp=stamp)
                self.footer_warn = True
            else:
                self.footer_text = texts.t("footer.updated", stamp=stamp,
                                           source=self.source_name)
                self.footer_warn = False
        else:
            self.precip_text = texts.t("precip.waiting")
            self.footer_text = self.status_error or self.status_note
            self.footer_warn = bool(self.status_error)

    # ------------------------------------------------------------------ тик времени

    def _clock_text(self, now: datetime) -> str:
        return ru.format_clock(now, self._show_seconds, self._hour12)

    def _clock_suffix(self, now: datetime) -> str:
        return ru.clock_suffix(now, self._hour12)

    def _tick(self) -> None:
        now = datetime.now()
        if self._clock_items:
            text = self._clock_text(now)
            if len(text) == len(self._clock_items):
                try:
                    for index, char in enumerate(text):
                        self.canvas.itemconfigure(self._clock_items[index], text=char)
                        for shadow in self._clock_shadow_items[index]:
                            self.canvas.itemconfigure(shadow, text=char)
                    # на границе полудня меняется AM/PM
                    if self._clock_suffix_item is not None:
                        self.canvas.itemconfigure(self._clock_suffix_item,
                                                  text=self._clock_suffix(now))
                except (tk.TclError, IndexError):
                    pass
        if now.minute != self._last_minute or now.date() != self._last_date:
            self._last_minute = now.minute
            self._last_date = now.date()
            self._refresh_derived()
            self._redraw()
        self.root.after(200, self._tick)

    # ------------------------------------------------------------------ отрисовка

    @resilient_redraw
    def _redraw(self, force: bool = False) -> None:
        self._redraw_job = None
        if self._intro_active and not force:
            # во время появления не пересобираем раскладку «снаружи» (например,
            # когда пришли данные): это тяжёлый кадр, он рвёт анимацию.
            # Кадры самой анимации приходят с force=True.
            self._intro_redraw_pending = True
            return
        canvas = self.canvas
        width = max(40, self.root.winfo_width())
        height = max(40, self.root.winfo_height())
        self._size = (width, height)
        canvas.delete("all")
        self._clock_items = []
        self._clock_shadow_items = []
        self._clock_suffix_item = None
        self._btn_rects = {}

        now = datetime.now()
        city_now = self.data.now_local() if self.data else now
        day = self.data.today() if self.data else None
        key = ru.daypart(city_now, day.sunrise if day else None, day.sunset if day else None)
        base_pal = theme.palette(key)
        # скругление углов пересчитываем под текущий размер виджета
        self.radius = (self._corner_radius(height)
                       if (self._frameless and self.config.option("rounded", True)) else 0.0)

        top_color, bottom_color = theme.plate_colors(
            base_pal, self.config.option("plate_top"), self.config.option("plate_bottom"))
        # если подложку сделали светлее текста, содержимое переключаем на тёмные
        # «чернила»: иначе светлые буквы на светлом фоне просто не видно
        self._light_plate = theme.needs_dark_ink(top_color, bottom_color,
                                                 base_pal["text"])
        pal = theme.ink_palette(base_pal) if self._light_plate else base_pal
        icons.set_style(self._icon_style)
        icons.set_color_scheme(theme.ink_icons(self._icon_style) if self._light_plate else None)
        self.pal = pal
        self._shadow_color = "#f2f6ff" if self._light_plate else SHADOW_COLOR
        plate_alpha = self._plate_alpha()
        # фон окна вырезается по цвету подложки — иначе вокруг букв розовая кромка
        self._apply_transparent_key(
            self._transparent_key(top_color) if self._frameless else TRANSPARENT_COLOR)
        bg_pal = {"bg_top": top_color, "bg_bottom": bottom_color}
        if self._frameless:
            # подложка — отдельное полупрозрачное окно под содержимым;
            # при 0 % подложки нет вовсе, остаются только текст и иконки.
            # Во время появления подложкой управляет анимация (она её растит).
            if plate_alpha > 0.005 and not self._intro_active:
                self._update_plate(width, height, top_color, bottom_color)
            elif plate_alpha <= 0.005:
                self._hide_plate()
            # Обводку текста включаем только по желанию: по умолчанию текст
            # остаётся чистым, даже если фон убран полностью
            self._shadow_offset_needed = bool(self.config.option("text_outline", False))
        else:
            self._hide_plate()
            icons.draw_background(canvas, width, height, pal, self.radius,
                                  top=top_color, bottom=bottom_color)
            self._shadow_offset_needed = bool(self.config.option("text_outline", False))

        plan = self._build_plan(width, height, pal, now, city_now, day, bg_pal)
        self._last_plan_scale = plan.get("scale", 1.0)
        self._last_plan_hourly = any(block["name"] == "hourly" for block in plan["blocks"])
        total = sum(block["h"] for block in plan["blocks"])
        free = height - 2 * plan["pad"] - total
        # если раскладку ограничила ширина, по высоте остаётся запас: раздвигаем
        # блоки, чтобы виджет заполнял окно, а не «застревал» с пустотой снизу
        indent, between = self._spread_space(plan, free, height)
        y = plan["pad"] + indent
        last_index = len(plan["blocks"]) - 1
        for index, block in enumerate(plan["blocks"]):
            block["draw"](y, block["h"] - block["gap"])
            y += block["h"]
            if index < last_index:
                y += between
        if self._frameless:
            self._draw_grip(width, height, pal)
        if self._shadow_offset_needed:
            self._add_text_shadows()

    # ------------------------------------------------------------------ подложка

    def _plate_alpha(self) -> float:
        try:
            return max(0.0, min(1.0, float(self.config.option("plate_alpha", 0.92))))
        except (TypeError, ValueError):
            return 0.92

    def _plate_visible(self) -> bool:
        """Подложка-окно используется только в режиме без рамки и при alpha > 0."""
        return self._frameless and self._plate_alpha() > 0.005

    def _key_without_plate(self, base: str) -> str:
        """Цвет-ключ, когда фон убран: светлый, как текст, и не как у фигур.

        Тёмный ключ давал тёмную кромку вокруг букв прямо на обоях, поэтому
        берём оттенок, близкий к цвету текста. Но он не должен совпасть
        с цветом какой-нибудь фигуры (облака, солнца), иначе в ней появится
        дырка — поэтому проверяем расстояние до всех рисуемых цветов.
        """
        text_color = self.pal.get("text", "#eaf2ff")
        drawn = [value for value in self.pal.values() if isinstance(value, str)]
        drawn += list(theme.icon_palette(self._icon_style).values())
        drawn += [SIGNATURE and theme.ICONS.get("cloud", "")]
        for share in (0.58, 0.50, 0.66, 0.42, 0.74, 0.30):
            candidate = theme.mix(base, text_color, share)
            if self._color_is_free(candidate, drawn):
                return candidate
        return theme.mix(base, text_color, 0.58)

    @staticmethod
    def _color_is_free(candidate: str, drawn: list) -> bool:
        """Далеко ли цвет от всех уже используемых (чтобы ничего не «вырезать»)."""
        try:
            red, green, blue = theme.hex_to_rgb(candidate)
        except ValueError:
            return False
        for color in drawn:
            try:
                other_red, other_green, other_blue = theme.hex_to_rgb(color)
            except (ValueError, TypeError):
                continue
            distance = (abs(red - other_red) + abs(green - other_green)
                        + abs(blue - other_blue))
            if distance < 60:
                return False
        return True

    def _transparent_key(self, top_color: str) -> str:
        """Цвет «прозрачного» фона окна с содержимым (см. theme.transparent_key).

        Когда фон убран полностью, ключ берём близким к цвету текста: иначе
        сглаженные края букв смешиваются с тёмным ключом и вокруг текста
        остаётся тёмная кромка прямо на обоях.
        """
        if not self._light_plate and self._plate_alpha() <= 0.05:
            return self._key_without_plate(top_color)
        return theme.transparent_key(top_color, dark_text=bool(self._light_plate))

    def _apply_transparent_key(self, key: str) -> None:
        if key == self._key_color:
            return
        self._key_color = key
        try:
            self.canvas.configure(bg=key)
            self.root.attributes("-transparentcolor", key)
        except tk.TclError:
            pass

    def _update_plate(self, width: int, height: int, top: str, bottom: str,
                      alpha: float | None = None, x: int | None = None, y: int | None = None,
                      coarse: bool = False) -> None:
        """Показать/обновить подложку.

        alpha=None означает «взять настроенную прозрачность с учётом анимации
        появления»: до её старта множитель равен нулю, поэтому подложка не видна.
        """
        if self.plate is None:
            self.plate = PlateWindow(self.root)
            self._bind_plate_input()
        if alpha is None:
            alpha = self._plate_alpha() * self._intro_factor
        self.plate.update_plate(
            self.root.winfo_x() if x is None else x,
            self.root.winfo_y() if y is None else y,
            width, height, top, bottom, self.radius, alpha,
            bool(self.config.option("topmost")),
            below_hwnd=plate_top_level_hwnd(self.root), coarse=coarse)

    def _bind_plate_input(self) -> None:
        """Клики, прошедшие сквозь прозрачный фон виджета, обрабатываем сами.

        У главного окна пиксели фона прозрачны и для мыши, поэтому «пустые»
        места виджета ловит подложка; передаём события тем же обработчикам,
        что и у виджета — координаты совпадают, окна наложены пиксель в пиксель.
        """
        if self.plate is None:
            return
        canvas = self.plate.canvas
        canvas.bind("<Button-1>", self._on_press)
        canvas.bind("<B1-Motion>", self._on_motion)
        canvas.bind("<ButtonRelease-1>", self._on_release)
        canvas.bind("<Motion>", self._on_hover)
        canvas.bind("<Button-3>",
                    lambda event: self._popup_menu(event.x_root, event.y_root))
        canvas.bind("<Double-Button-1>", lambda event: self._request_weather(force=True))
        canvas.bind("<MouseWheel>", self._on_wheel)

    def _sync_plate(self, x: int, y: int, width: int, height: int) -> None:
        """Двинуть подложку вместе с окном в том же событии (без отставания)."""
        if not self._plate_visible():
            return
        top_color, bottom_color = theme.plate_colors(
            self.pal, self.config.option("plate_top"), self.config.option("plate_bottom"))
        self._update_plate(width, height, top_color, bottom_color,
                           x=x, y=y, coarse=self._intro_active)

    def _hide_plate(self) -> None:
        if self.plate is not None:
            self.plate.hide()

    def _add_text_shadows(self) -> None:
        """Тёмный контур вокруг надписей — чтобы текст читался без подложки.

        Часы намеренно не обводим: у цифр времени должен быть чистый шрифт,
        без тени и контура.
        """
        canvas = self.canvas
        self._clock_shadow_items = [[] for _ in self._clock_items]
        clock_items = set(self._clock_items)
        for item in canvas.find_all():
            if canvas.type(item) != "text" or item in clock_items:
                continue
            coords = canvas.coords(item)
            box = canvas.bbox(item)
            if len(coords) < 2 or not box:
                continue
            offset = max(1, min(3, int((box[3] - box[1]) * 0.035)))
            if (box[3] - box[1]) < 16:
                # мелкие подписи: хватает одной тени, иначе буквы «двоятся»
                shifts = ((offset, offset),)
            else:
                shifts = ((-offset, -offset), (-offset, offset),
                          (offset, -offset), (offset, offset))
            for dx, dy in shifts:
                shadow = canvas.create_text(
                    coords[0] + dx, coords[1] + dy,
                    text=canvas.itemcget(item, "text"),
                    font=canvas.itemcget(item, "font"),
                    anchor=canvas.itemcget(item, "anchor"),
                    fill=self._shadow_color,
                    tags=tuple(canvas.gettags(item)) + ("shadow",))
                canvas.tag_lower(shadow, item)

    def _draw_grip(self, w: int, h: int, pal: dict) -> None:
        """Насечки в правом нижнем углу: подсказка, что окно можно тянуть."""
        size = 13
        for index in range(3):
            offset = 4 + index * 4
            self.canvas.create_line(w - offset, h - 3, w - 3, h - offset,
                                    fill=pal["border"], width=2, capstyle="round",
                                    tags="grip")

    def _capture(self) -> None:
        if self._captured:
            return
        self._captured = True
        try:
            from PIL import ImageGrab
            self.root.update_idletasks()
            x, y = self.root.winfo_rootx(), self.root.winfo_rooty()
            w, h = self.root.winfo_width(), self.root.winfo_height()
            ImageGrab.grab(bbox=(x, y, x + w, y + h)).save(self.screenshot_path)
        except Exception as exc:  # pragma: no cover - только для отладки
            print("screenshot error:", exc)
        if self.exit_after:
            self.root.after(250, self.root.destroy)

    # ------------------------------------------------------------------ раскладка

    def _build_plan(self, w: int, h: int, pal: dict, now: datetime,
                    city_now: datetime, day, bg_pal: dict | None = None) -> dict:
        pad = int(max(6, min(26, round(min(w, h) * 0.052))))
        avail = w - 2 * pad
        background = bg_pal or pal
        # во время появления раскладка просто масштабируется вместе с окном:
        # тот же коэффициент, без дорогого подбора — кадры идут плавно
        if self._intro_active and self._intro_layout_scale:
            fixed = self._try_plan(w, h, pad, avail, pal, self._intro_layout_scale,
                                   now, city_now, day, self._intro_hourly,
                                   force=True, bg_pal=background)
            if fixed is not None:
                return fixed
        # границы поиска масштаба раскладки: содержимое всегда заполняет окно,
        # а «масштаб» из меню меняет размер самого окна (см. _set_zoom)
        low = 0.3
        high = 2.6

        def build(scale: float, with_hourly: bool):
            return self._try_plan(w, h, pad, avail, pal, scale, now, city_now, day,
                                  with_hourly, bg_pal=background)

        # Ищем максимальный масштаб, при котором содержимое помещается целиком:
        # так окно любого размера заполняется целиком, а не оставляет пустоту.
        variants = [True, False] if self._show_hourly else [False]
        for with_hourly in variants:
            best = build(low, with_hourly)
            if best is None:
                continue
            left, right = low, high
            for _ in range(14):
                middle = (left + right) / 2.0
                candidate = build(middle, with_hourly)
                if candidate is not None:
                    best = candidate
                    left = middle
                else:
                    right = middle
            return best
        # ничего не влезло — рисуем максимально компактно
        return self._try_plan(w, h, pad, avail, pal, 0.25, now, city_now,
                              day, False, force=True, bg_pal=background)

    def _try_plan(self, w: int, h: int, pad: int, avail: int, pal: dict, scale: float,
                  now: datetime, city_now: datetime, day, with_hourly: bool,
                  force: bool = False, bg_pal: dict | None = None) -> dict | None:
        canvas = self.canvas
        background = bg_pal or pal
        px = font_pixels(h, scale)
        fonts = {name: self._font(kind, px[name], weight)
                 for name, (_factor, _floor, kind, weight) in FONT_FACTORS.items()}
        gap = max(3, int(h * 0.014 * scale))
        labels = self._texts(city_now, day)

        clock_text = self._clock_text(now)
        clock_suffix = self._clock_suffix(now)
        # цифры рисуются по «клеткам» одинаковой ширины: тогда часы не дёргаются
        # влево-вправо, даже если выбран пропорциональный шрифт
        clock_cell = max(fonts["clock"].measure(char) for char in "0123456789:")
        clock_width = clock_cell * len(clock_text)
        # AM/PM — тем же шрифтом, но заметно мельче и с отступом справа
        ampm_font = self._font("clock", max(9, int(px["clock"] * 0.30)), "bold")
        ampm_width = ampm_font.measure(clock_suffix) if clock_suffix else 0.0
        ampm_gap = int(px["clock"] * 0.22) if clock_suffix else 0
        # запоминаем параметры часов для живого предпросмотра шрифта
        self._clock_px = px["clock"]
        self._clock_avail = float(avail)
        self._clock_current = clock_text
        self._clock_suffix_text = clock_suffix
        date_text, weekday_text = ru.format_date_parts(now, self._show_weekday)
        # номер недели — крошечная приписка в той же строке
        if self.config.option("week_number", True):
            week_text = " · " + texts.t("week", value=now.isocalendar()[1])
        else:
            week_text = ""
        moon_kind = moon_mod.name(now) if self.config.option("moon_phase", True) else ""
        self._moon_kind = moon_kind
        weekday_gap = max(5, int(px["date"] * 0.5))
        # ширины считаем по отдельности: дата, приписка недели, день недели, Луна
        date_width = float(fonts["date"].measure(date_text))
        week_width = float(fonts["date"].measure(week_text)) if week_text else 0.0
        moon_size = float(max(7, int(px["date"] * 0.85)))
        moon_gap = moon_size * 0.75 if moon_kind else 0.0
        moon_w = (moon_size + moon_gap) if moon_kind else 0.0
        weekday_width = float(fonts["date"].measure(weekday_text)) if weekday_text else 0.0
        if clock_width + ampm_gap + ampm_width > avail:
            return None
        date_row_width = (date_width + week_width + weekday_width + moon_w
                          + (weekday_gap if weekday_text else 0))
        if date_row_width > avail:
            return None

        blocks: list[dict] = []

        def add(name: str, height: float, draw, extra_gap: float | None = None) -> None:
            blocks.append({"name": name, "h": float(height) + (gap if extra_gap is None else extra_gap),
                           "gap": gap if extra_gap is None else extra_gap, "draw": draw})

        # --- шапка: город, переключатель языка, время дня, кнопки
        header_h = int(fonts["label"].metrics("linespace") * 1.55)
        btn_w = int(px["small"] * 1.7)
        buttons = [("settings", "\u2699"), ("close", "\u2715")] if self._frameless else []
        buttons_w = len(buttons) * (btn_w + max(2, int(gap * 0.4)))
        chip_icon = int(header_h * 0.88)
        chip_label = ru.daypart_label(key_for(day, city_now))
        chip_w = chip_icon + int(gap * 0.8) + fonts["label"].measure(chip_label)
        # значок языка: RU | EN, активный подсвечен
        lang_font = self._font("text", max(8, int(px["tiny"] * 1.15)), "bold")
        lang_gap = max(4, int(gap * 0.55))
        lang_w = (lang_font.measure("RU") + lang_font.measure("|")
                  + lang_font.measure("EN") + lang_gap * 2)
        tz_differs = city_now.utcoffset() != now.astimezone().utcoffset()
        city_label = labels["city"]
        if tz_differs and self.data:
            city_label += f" · {ru.format_hhmm(city_now)}"
        city_text = self._ellipsize(city_label, fonts["label"],
                                    max(20, avail - chip_w - buttons_w - lang_w - 3 * gap))

        def draw_header(y: float, hh: float) -> None:
            cy = y + hh / 2.0
            city_width = fonts["label"].measure(city_text)
            canvas.create_text(pad, cy, text=city_text, anchor="w", font=fonts["label"],
                               fill=pal["text"], tags="header")
            # клик по названию города переключает на второй город, если он задан
            if self.city_alt is not None:
                self._btn_rects["city_switch"] = (pad - 2, cy - hh / 2.0,
                                                  pad + city_width + 2, cy + hh / 2.0)
            x_right = w - pad
            for name, glyph in reversed(buttons):
                rect = (x_right - btn_w, cy - btn_w / 2.0, x_right, cy + btn_w / 2.0)
                self._btn_rects[name] = rect
                canvas.create_text((rect[0] + rect[2]) / 2.0, cy, text=glyph, anchor="center",
                                   font=self._font("text", int(px["small"] * 1.2)),
                                   fill=pal["muted"], tags="header")
                x_right -= btn_w + max(2, int(gap * 0.4))
            # переключатель языка
            x_right -= lang_gap
            for code, title in (("en", "EN"), ("ru", "RU")):
                active = (code == self._language)
                width = lang_font.measure(title)
                rect = (x_right - width, cy - hh / 2.0, x_right, cy + hh / 2.0)
                self._btn_rects[f"lang_{code}"] = rect
                canvas.create_text(x_right - width / 2.0, cy, text=title, anchor="center",
                                   font=lang_font,
                                   fill=pal["accent"] if active else pal["muted"],
                                   tags="header")
                x_right -= width + lang_gap
                if code == "en":
                    canvas.create_text(x_right, cy, text="|", anchor="e", font=lang_font,
                                       fill=pal["divider"], tags="header")
            x_right -= lang_gap * 0.5
            icon_x = x_right - chip_icon
            icons.draw_icon(canvas, icon_x, cy - chip_icon / 2.0, chip_icon,
                            ru.daypart_icon(key_for(day, city_now)),
                            bg=icons.bg_at(background, h, cy), tag="header")
            canvas.create_text(icon_x - gap * 0.8, cy, text=chip_label, anchor="e",
                               font=fonts["label"], fill=pal["accent"], tags="header")

        add("header", header_h, draw_header)

        # --- часы
        clock_h = int(fonts["clock"].metrics("linespace") * 0.95)

        def draw_clock(y: float, hh: float) -> None:
            # каждый символ — на своей клетке: ширина часов не зависит от того,
            # какие цифры сейчас на экране (важно для пропорциональных шрифтов)
            centre_y = y + hh / 2.0
            left = w / 2.0 - (clock_width + ampm_gap + ampm_width) / 2.0
            self._clock_center_y = centre_y
            self._clock_left = left
            items = []
            for index, char in enumerate(clock_text):
                items.append(canvas.create_text(
                    left + clock_cell * index + clock_cell / 2.0, centre_y,
                    text=char, anchor="center", font=fonts["clock"],
                    fill=pal["text"], tags="clock"))
            self._clock_items = items
            # AM/PM — прижато к базовой линии, чтобы не «висело» в воздухе
            self._clock_suffix_item = None
            if clock_suffix:
                baseline = centre_y + fonts["clock"].metrics("ascent") * 0.30
                self._clock_suffix_item = canvas.create_text(
                    left + clock_width + ampm_gap, baseline, text=clock_suffix,
                    anchor="w", font=ampm_font, fill=pal["muted"], tags="clock")

        add("clock", clock_h, draw_clock, extra_gap=max(2, int(gap * 0.35)))

        # --- дата
        date_h = int(fonts["date"].metrics("linespace") * 1.2)

        def draw_date(y: float, hh: float) -> None:
            cy = y + hh / 2.0
            left = w / 2.0 - date_row_width / 2.0
            x = left
            canvas.create_text(x, cy, text=date_text, anchor="w", font=fonts["date"],
                               fill=pal["muted"], tags="date")
            x += date_width
            if week_text:
                canvas.create_text(x, cy, text=week_text, anchor="w",
                                   font=fonts["date"], fill=pal["divider"], tags="date")
                x += week_width
            if weekday_text:
                x += weekday_gap
                canvas.create_text(x, cy, text=weekday_text, anchor="w",
                                   font=fonts["date"],
                                   fill=theme.weekday_color(now, light=bool(pal.get("_light"))),
                                   tags="date")
                x += weekday_width
            if moon_kind:
                # крошечная Луна сразу за строкой даты
                icons.draw_moon(canvas, x + moon_gap + moon_size / 2.0, cy, moon_size,
                                moon_kind,
                                pal["accent"] if moon_kind == "full" else pal["muted"],
                                icons.bg_at(background, h, cy), "date")

        add("date", date_h, draw_date)

        # --- разделитель
        def draw_divider(y: float, hh: float) -> None:
            canvas.create_line(pad * 1.4, y + 0.5, w - pad * 1.4, y + 0.5,
                               fill=pal["divider"], tags="divider")

        add("divider", 1, draw_divider)

        # --- блок погоды
        icon_size = int(max(30, min(avail * 0.38, h * 0.165 * scale)))
        text_x = pad + icon_size + int(gap * 1.4)
        text_w = max(60.0, w - pad - text_x)
        source_lines = [
            (labels["temp"], fonts["temp"], pal["text"], 1),
            (labels["desc"], fonts["desc"], pal["accent"], 1),
            (labels["feels"], fonts["small"], pal["muted"], 2),
            (labels["details"], fonts["small"], pal["muted"], 2),
        ]
        rendered = []
        text_h = 0
        for text, font, color, max_lines in source_lines:
            if not text:
                continue
            wrapped = self._wrap(text, font, text_w, max_lines)
            line_h = int(font.metrics("linespace") * 1.18)
            rendered.append((wrapped, font, color, line_h))
            text_h += line_h * len(wrapped)
        weather_h = max(icon_size, text_h)

        current_kind = ru.weather_kind(self.data.current.code, self.data.current.is_day) if self.data else "cloudy"

        def draw_weather(y: float, hh: float) -> None:
            icons.draw_icon(canvas, pad, y + (hh - icon_size) / 2.0, icon_size, current_kind,
                            bg=icons.bg_at(background, h, y + hh / 2.0), tag="weather")
            # по клику на погоду открывается карточка с подробностями
            self._btn_rects["details_weather"] = (pad, y, w - pad, y + hh)
            ty = y + (hh - text_h) / 2.0
            for wrapped, font, color, line_h in rendered:
                for line in wrapped:
                    canvas.create_text(text_x, ty, text=line, anchor="nw", font=font,
                                       fill=color, tags="weather")
                    ty += line_h

        add("weather", weather_h, draw_weather)

        # --- световой день
        dl_line_h = int(fonts["small"].metrics("linespace") * 1.3)
        bar_h = max(4, int(h * 0.010 * scale))
        dl_h = dl_line_h + bar_h + int(gap * 0.5)
        progress = max(0.0, min(1.0, self.daylight.progress))
        at_noon = bool(self.daylight.at_noon)
        # в зените шкала подсвечивается тёплым цветом
        bar_fill = pal["warn"] if at_noon else (pal["accent"] if self.daylight.is_between
                                                else pal["border"])
        # надпись «Солнце в зените» показываем, только если между подписями есть место
        noon_text = texts.t("daylight.noon") if at_noon else ""
        noon_gap = (w - 2 * pad) - fonts["small"].measure(labels["daylight"]) \
            - fonts["small"].measure(labels["sun_times"]) - fonts["small"].measure(noon_text)
        show_noon = bool(noon_text) and noon_gap > max(24.0, px["small"] * 3)

        def draw_daylight(y: float, hh: float) -> None:
            cy = y + dl_line_h / 2.0
            canvas.create_text(pad, cy, text=labels["daylight"], anchor="w",
                               font=fonts["small"], fill=pal["muted"], tags="daylight")
            canvas.create_text(w - pad, cy, text=labels["sun_times"], anchor="e",
                               font=fonts["small"], fill=pal["muted"], tags="daylight")
            if show_noon:
                canvas.create_text(w / 2.0, cy, text=noon_text, anchor="center",
                                   font=fonts["small"], fill=pal["warn"], tags="daylight")
            bar_y = y + dl_line_h + bar_h / 2.0
            canvas.create_line(pad, bar_y, w - pad, bar_y, fill=pal["divider"],
                               width=bar_h, capstyle="round", tags="daylight")
            if progress > 0.002:
                canvas.create_line(pad, bar_y, pad + (w - 2 * pad) * progress, bar_y,
                                   fill=bar_fill, width=bar_h, capstyle="round",
                                   tags="daylight")
            marker_x = pad + (w - 2 * pad) * progress
            radius = bar_h * 0.95 * (1.35 if at_noon else 1.0)
            if at_noon:
                # мягкое свечение вокруг маркера в час зенита
                canvas.create_oval(marker_x - radius * 2.0, bar_y - radius * 2.0,
                                   marker_x + radius * 2.0, bar_y + radius * 2.0,
                                   fill=theme.mix(icons.bg_at(background, h, bar_y),
                                                  pal["warn"], 0.25),
                                   outline="", tags="daylight")
            canvas.create_oval(marker_x - radius, bar_y - radius, marker_x + radius,
                               bar_y + radius, fill=pal["text"], outline=pal["bg_bottom"],
                               width=1, tags="daylight")

        add("daylight", dl_h, draw_daylight)

        # --- осадки
        pr_icon = int(max(18, px["small"] * 2.0))
        pr_x = pad + pr_icon + int(gap * 1.1)
        pr_w = max(60.0, w - pad - pr_x)
        pr_lines = self._wrap(labels["precip"], fonts["small"], pr_w, 2)
        pr_line_h = int(fonts["small"].metrics("linespace") * 1.22)
        pr_h = max(pr_icon, pr_line_h * len(pr_lines))
        pr_color = pal["warn"] if self.outlook.status != "none" else pal["muted"]
        pr_kind = self.outlook.icon if self.outlook.status != "none" else "cloudy"

        def draw_precip(y: float, hh: float) -> None:
            icons.draw_icon(canvas, pad, y + (hh - pr_icon) / 2.0, pr_icon, pr_kind,
                            bg=icons.bg_at(background, h, y + hh / 2.0), tag="precip")
            ty = y + (hh - pr_line_h * len(pr_lines)) / 2.0
            for line in pr_lines:
                canvas.create_text(pr_x, ty, text=line, anchor="nw", font=fonts["small"],
                                   fill=pr_color, tags="precip")
                ty += pr_line_h

        add("precip", pr_h, draw_precip)

        # --- прогноз на завтра одной строкой
        if self.config.option("tomorrow", True) and labels.get("tomorrow"):
            tm_line_h = int(fonts["small"].metrics("linespace") * 1.3)
            tm_text = labels["tomorrow"]

            def draw_tomorrow(y: float, hh: float) -> None:
                canvas.create_text(pad, y + tm_line_h / 2.0, text=tm_text, anchor="w",
                                   font=fonts["small"], fill=pal["muted"],
                                   tags="tomorrow")

            add("tomorrow", tm_line_h, draw_tomorrow)

        # --- пробки (тестовый режим): баллы, полоса загруженности и пояснение
        if self._show_traffic and self.traffic is not None:
            tr_line_h = int(fonts["small"].metrics("linespace") * 1.3)
            tr_bar_h = max(4, int(h * 0.010 * scale))
            tr_h = tr_line_h + tr_bar_h + int(gap * 0.5)
            traffic_data = self.traffic
            tr_level = max(0, min(10, traffic_data.level))
            tr_fill = traffic_data.color()

            def draw_traffic(y: float, hh: float, data=traffic_data,
                             level=tr_level, fill_color=tr_fill) -> None:
                cy = y + tr_line_h / 2.0
                canvas.create_text(pad, cy, text=data.title(), anchor="w",
                                   font=fonts["small"], fill=fill_color, tags="traffic")
                right = data.description()
                trend = data.trend_text()
                if trend:
                    right = f"{right} · {trend}" if right else trend
                canvas.create_text(w - pad, cy, text=right, anchor="e",
                                   font=fonts["small"], fill=pal["muted"], tags="traffic")
                bar_y = y + tr_line_h + tr_bar_h / 2.0
                canvas.create_line(pad, bar_y, w - pad, bar_y, fill=pal["divider"],
                                   width=tr_bar_h, capstyle="round", tags="traffic")
                share = max(0.02, min(1.0, level / 10.0))
                canvas.create_line(pad, bar_y, pad + (w - 2 * pad) * share, bar_y,
                                   fill=fill_color, width=tr_bar_h, capstyle="round",
                                   tags="traffic")

            add("traffic", tr_h, draw_traffic)

        # --- почасовой прогноз
        if with_hourly and self._hourly_points:
            col_min = max(46, int(px["small"] * 3.6))
            columns = max(2, min(len(self._hourly_points), int(avail // col_min)))
            points = self._hourly_points[:columns]
            col_w = avail / float(columns)
            hr_icon = int(max(14, min(col_w * 0.62, h * 0.060 * scale)))
            hr_time_h = int(fonts["tiny"].metrics("linespace") * 1.3)
            hr_temp_h = int(fonts["small"].metrics("linespace") * 1.3)
            hr_h = hr_time_h + hr_icon + hr_temp_h

            def draw_hourly(y: float, hh: float, points=points, col_w=col_w,
                            hr_icon=hr_icon, hr_time_h=hr_time_h, hr_temp_h=hr_temp_h) -> None:
                for index, point in enumerate(points):
                    cx = pad + col_w * (index + 0.5)
                    label = (texts.t("hour.now") if index == 0
                             else ru.format_hour_label(point.time, self._hour12))
                    canvas.create_text(cx, y + hr_time_h / 2.0, text=label, anchor="center",
                                       font=fonts["tiny"], fill=pal["muted"], tags="hourly")
                    icons.draw_icon(canvas, cx - hr_icon / 2.0, y + hr_time_h, hr_icon,
                                    ru.weather_kind(point.code, point.is_day),
                                    bg=icons.bg_at(background, h, y + hr_time_h + hr_icon / 2.0),
                                    tag="hourly")
                    canvas.create_text(cx, y + hr_time_h + hr_icon + hr_temp_h / 2.0,
                                       text=ru.format_temperature(point.temperature),
                                       anchor="center", font=fonts["small"], fill=pal["text"],
                                       tags="hourly")

            add("hourly", hr_h, draw_hourly)

        # --- нижняя строка и подпись автора
        footer_lines = self._wrap(labels["footer"], fonts["tiny"], avail, 2)
        footer_line_h = int(fonts["tiny"].metrics("linespace") * 1.2)
        footer_h = footer_line_h * (len(footer_lines) + 1)
        footer_color = pal["warn"] if self.footer_warn else pal["muted"]

        def draw_footer(y: float, hh: float) -> None:
            ty = y
            for line in footer_lines:
                canvas.create_text(w / 2.0, ty + footer_line_h / 2.0, text=line,
                                   anchor="center", font=fonts["tiny"], fill=footer_color,
                                   tags="footer")
                ty += footer_line_h
            # подпись автора и знак проекта (искра) сразу за ней;
            # по подписи можно щёлкнуть — открывается справка о виджете
            mark = max(7.0, fonts["tiny"].metrics("linespace") * 0.78)
            gap = max(4.0, mark * 0.45)
            text_width = fonts["tiny"].measure(SIGNATURE)
            left = w / 2.0 - (text_width + gap + mark) / 2.0
            line_cy = ty + footer_line_h / 2.0
            canvas.create_text(left + text_width / 2.0, line_cy, text=SIGNATURE,
                               anchor="center", font=fonts["tiny"], fill=pal["muted"],
                               tags="footer")
            # уведомление об обновлении — частью этой же строки, без новой строки
            if self.update_available is not None:
                notice = texts.t("update.available",
                                 version=self.update_available.version)
                notice_width = fonts["tiny"].measure(notice)
                canvas.create_text(left + text_width + gap + mark + footer_line_h,
                                   line_cy, text="· " + notice, anchor="w",
                                   font=fonts["tiny"], fill=pal["accent"],
                                   tags="footer")
                self._btn_rects["update"] = (
                    left + text_width + gap + mark, line_cy - footer_line_h / 2.0,
                    left + text_width + gap + mark + notice_width + footer_line_h,
                    line_cy + footer_line_h / 2.0)
            # ореол вокруг знака рисуем только когда фон есть: без фона он
            # выглядел бы тёмным пятном на обоях
            icons.draw_spark(canvas, left + text_width + gap + mark / 2.0, line_cy,
                             mark, pal["accent"], "footer",
                             glow=icons.bg_at(background, h, line_cy)
                             if self._plate_alpha() > 0.35 else None)
            pad_x = max(6.0, mark * 0.8)
            self._btn_rects["about"] = (left - pad_x, line_cy - footer_line_h / 2.0,
                                        left + text_width + gap + mark + pad_x,
                                        line_cy + footer_line_h / 2.0)

        add("footer", footer_h, draw_footer)

        total = sum(block["h"] for block in blocks)
        if not force and total > h - 2 * pad:
            return None
        return {"pad": pad, "blocks": blocks, "scale": scale}

    # ------------------------------------------------------------------ текст

    def _texts(self, city_now: datetime, day) -> dict:
        data = self.data
        texts_data = {"city": self.city.short() if self.city else texts.t("city.none")}
        if data is None:
            texts_data.update(
                temp="—", desc=texts.t("desc.loading"), feels="", details="",
                daylight=texts.t("daylight", value="—"), sun_times="—",
                precip=self.precip_text, footer=self.footer_text, tomorrow="",
            )
            return texts_data
        current = data.current
        texts_data["temp"] = ru.format_temperature(current.temperature) if current.temperature is not None else "—"
        texts_data["desc"] = ru.describe(current.code)
        parts = []
        if current.apparent is not None:
            parts.append(texts.t("feels", value=ru.format_temperature(current.apparent)))
        if day is not None and day.t_max is not None:
            parts.append(texts.t("temp.max", value=ru.format_temperature(day.t_max)))
        if day is not None and day.t_min is not None:
            parts.append(texts.t("temp.min", value=ru.format_temperature(day.t_min)))
        texts_data["feels"] = "  ·  ".join(parts)
        parts = []
        if current.wind_speed is not None:
            parts.append(texts.t("wind", value=ru.format_wind(current.wind_direction,
                                                              current.wind_speed)))
        if current.humidity is not None:
            parts.append(texts.t("humidity", value=f"{current.humidity:.0f}"))
        if current.pressure:
            parts.append(ru.format_pressure(current.pressure) + self._pressure_arrow())
        # УФ-индекс показываем только когда он заметный
        if current.uv_index is not None and current.uv_index >= 3:
            parts.append(texts.t("uv", value=f"{current.uv_index:.0f}"))
        texts_data["details"] = "  ·  ".join(parts)
        texts_data["daylight"] = texts.t("daylight",
                                         value=ru.format_daylight(self.daylight.seconds))
        if self.daylight.sunrise and self.daylight.sunset:
            texts_data["sun_times"] = (f"{ru.format_hhmm(self.daylight.sunrise)} — "
                                       f"{ru.format_hhmm(self.daylight.sunset)}")
        else:
            texts_data["sun_times"] = "—"
        texts_data["precip"] = self.precip_text
        texts_data["footer"] = self.footer_text
        texts_data["tomorrow"] = self._tomorrow_text()
        if self.config.option("sun_countdown", False):
            texts_data["sun_times"] = self._sun_countdown_text(city_now)
        return texts_data

    def _pressure_arrow(self) -> str:
        """Стрелка тренда давления по часовым данным за последние три часа."""
        trend = self.pressure_trend
        if trend == "rising":
            return " ↑"
        if trend == "falling":
            return " ↓"
        if trend == "steady":
            return " →"
        return ""

    def _compute_pressure_trend(self) -> None:
        """Сравнить давление сейчас и три часа назад (по часовым точкам)."""
        self.pressure_trend = ""
        data = self.data
        if data is None or data.current.pressure is None:
            return
        now = data.now_local()
        earlier = None
        for point in getattr(data, "hours", []) or []:
            if point.pressure is None or point.time > now:
                continue
            if (now - point.time).total_seconds() <= 4 * 3600:
                earlier = point
        if earlier is None or earlier.pressure is None:
            return
        delta = data.current.pressure - earlier.pressure
        if delta >= 0.7:
            self.pressure_trend = "rising"
        elif delta <= -0.7:
            self.pressure_trend = "falling"
        else:
            self.pressure_trend = "steady"

    def _tomorrow_text(self) -> str:
        """Строка «Завтра: +9°…+16°, дождь» — по прогнозу на следующий день."""
        data = self.data
        if data is None or len(getattr(data, "days", []) or []) < 2:
            return ""
        day = data.days[1]
        parts = []
        if day.t_min is not None and day.t_max is not None:
            parts.append(f"{ru.format_temperature(day.t_min)}…"
                         f"{ru.format_temperature(day.t_max)}")
        elif day.t_max is not None:
            parts.append(ru.format_temperature(day.t_max))
        description = ru.describe(day.code) if day.code is not None else ""
        if description:
            parts.append(description.lower())
        if not parts:
            return ""
        return texts.t("tomorrow", value=", ".join(parts))

    def _sun_countdown_text(self, city_now: datetime) -> str:
        """Отсчёт до заката (днём) или до восхода (ночью)."""
        state = self.daylight
        if state.sunset and state.is_between:
            left = ru.format_duration((state.sunset - city_now).total_seconds() / 3600.0)
            return texts.t("daylight.until_sunset", value=left)
        target = state.sunrise
        if target is None or city_now >= target:
            # после заката — считаем до завтрашнего восхода
            days = getattr(self.data, "days", []) or []
            target = days[1].sunrise if len(days) > 1 else None
        if target is None:
            return ""
        left = ru.format_duration(max(0.0, (target - city_now).total_seconds()) / 3600.0)
        return texts.t("daylight.until_sunrise", value=left)

    @staticmethod
    def _ellipsize(text: str, font: tkfont.Font, max_width: float) -> str:
        if max_width <= 10:
            return ""
        if font.measure(text) <= max_width:
            return text
        ellipsis = "…"
        trimmed = text
        while trimmed and font.measure(trimmed + ellipsis) > max_width:
            trimmed = trimmed[:-1]
        return (trimmed.rstrip() + ellipsis) if trimmed else ""

    @staticmethod
    def _wrap(text: str, font: tkfont.Font, max_width: float, max_lines: int = 2) -> list[str]:
        if not text:
            return []
        words = text.split(" ")
        lines: list[str] = []
        current = ""
        for word in words:
            trial = (current + " " + word).strip()
            if current and font.measure(trial) > max_width:
                lines.append(current)
                current = word
                if len(lines) == max_lines:
                    break
            else:
                current = trial
        if len(lines) < max_lines:
            if current:
                lines.append(current)
        elif current:
            tail = lines[-1]
            while tail and font.measure(tail + " …") > max_width:
                tail = tail[:-1]
            lines[-1] = tail.rstrip() + " …"
        return lines or [text]

    # ------------------------------------------------------------------ прочее

    def open_city_dialog(self) -> None:
        chosen = ask_city(self.root, self.city, frameless=self._frameless,
                          palette=self.pal)
        if not chosen:
            return
        self.city = chosen
        self.config.city = chosen
        self._save_config()
        self.status_note = "загружаю прогноз для города…"
        self._refresh_derived()
        self._redraw()
        self._request_weather(force=True)

    def _cancel_pending_timers(self) -> None:
        """Снять все запланированные отложенные вызовы.

        Иначе после закрытия окна Tk продолжает выполнять оставшиеся задания
        и сыплет ошибками вида «invalid command name ..._tick»: команда уже
        удалена вместе с окном, а таймер ещё жив.
        """
        try:
            handles = self.root.tk.call("after", "info")
        except tk.TclError:
            return
        if isinstance(handles, str):
            handles = (handles,)
        for handle in handles or ():
            try:
                self.root.after_cancel(handle)
            except tk.TclError:
                pass

    # ------------------------------------------------------- скрытие и показ
    def _hide_for(self, minutes: float | None) -> None:
        """Спрятать виджет на время (minutes=None — до утра)."""
        now = datetime.now().astimezone()
        self._hide_until = self._morning_moment() if minutes is None \
            else now + timedelta(minutes=minutes)
        self._hidden_by_user = True
        self._set_visible(False)

    def _morning_moment(self) -> datetime:
        """Когда «утро»: ближайший восход, а если его нет — через 8 часов."""
        now = datetime.now().astimezone()
        data = self.data
        if data is not None:
            moments = []
            day = data.today()
            if day is not None and day.sunrise:
                moments.append(day.sunrise)
            days = getattr(data, "days", []) or []
            if len(days) > 1 and days[1].sunrise:
                moments.append(days[1].sunrise)
            for moment in sorted(moments):
                if moment > now:
                    return moment
        return now + timedelta(hours=8)

    def _set_visible(self, visible: bool) -> None:
        """Показать или спрятать виджет вместе с подложкой."""
        if visible:
            try:
                self.root.deiconify()
                self.root.attributes("-topmost", bool(self.config.option("topmost", True)))
            except tk.TclError:
                pass
            self._redraw(force=True)
            self._sync_plate(self.root.winfo_x(), self.root.winfo_y(),
                             self.root.winfo_width(), self.root.winfo_height())
        else:
            if self.plate is not None:
                self.plate.hide()
            try:
                self.root.withdraw()
            except tk.TclError:
                pass

    def _toggle_visible(self) -> None:
        """Горячая клавиша: показать виджет или спрятать его совсем."""
        hidden = bool(self._hidden_by_user or self._auto_hidden)
        if hidden or not self.root.winfo_viewable():
            self._hidden_by_user = False
            self._auto_hidden = False
            self._hide_until = None
            self._set_visible(True)
        else:
            self._hidden_by_user = True
            self._hide_until = None      # вернём только по горячей клавише
            self._set_visible(False)

    def _hide_tick(self) -> None:
        """Раз в двадцать секунд проверяем, не пора ли вернуть виджет."""
        try:
            if (self._hidden_by_user and self._hide_until is not None
                    and datetime.now().astimezone() >= self._hide_until):
                self._hidden_by_user = False
                self._hide_until = None
                if not self._auto_hidden:
                    self._set_visible(True)
            self.root.after(HIDE_TICK_MS, self._hide_tick)
        except tk.TclError:
            pass

    # ------------------------------------------------------------- горячая клавиша
    def _register_hotkey(self) -> None:
        """Ctrl+Alt+W — показать или спрятать виджет."""
        if not self.config.option("hotkey", True):
            return
        try:
            hwnd = plate_top_level_hwnd(self.root)
            self._hotkey_ready = bool(USER32.RegisterHotKey(
                ctypes.c_void_p(hwnd), HOTKEY_ID,
                MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, ord("W")))
        except Exception:                       # noqa: BLE001 — Win32 бывает недоступен
            self._hotkey_ready = False

    def _unregister_hotkey(self) -> None:
        if not self._hotkey_ready:
            return
        try:
            USER32.UnregisterHotKey(ctypes.c_void_p(plate_top_level_hwnd(self.root)),
                                    HOTKEY_ID)
        except Exception:                       # noqa: BLE001
            pass
        self._hotkey_ready = False

    def _poll_hotkey(self) -> None:
        """Читаем очередь сообщений потока: не нажали ли горячую клавишу."""
        if self._hotkey_ready:
            message = wintypes.MSG()
            while USER32.PeekMessageW(ctypes.byref(message), None,
                                      WM_HOTKEY, WM_HOTKEY, PM_REMOVE):
                self._toggle_visible()
        try:
            self.root.after(HOTKEY_POLL_MS, self._poll_hotkey)
        except tk.TclError:
            pass

    # ------------------------------------------- игры и фильмы на весь экран
    def _check_fullscreen(self) -> None:
        """Спрятаться, когда на весь экран идёт игра или фильм, и вернуться потом."""
        try:
            if (self.config.option("hide_fullscreen", True)
                    and not self._hidden_by_user):
                fullscreen = self._fullscreen_foreground()
                if fullscreen and not self._auto_hidden:
                    self._auto_hidden = True
                    self._set_visible(False)
                elif not fullscreen and self._auto_hidden:
                    self._auto_hidden = False
                    self._set_visible(True)
            self.root.after(FULLSCREEN_TICK_MS, self._check_fullscreen)
        except tk.TclError:
            pass

    def _fullscreen_foreground(self) -> bool:
        """Занимает ли переднее окно весь экран (кроме своих и оболочки Windows)."""
        try:
            hwnd = USER32.GetForegroundWindow()
            if not hwnd:
                return False
            own = {plate_top_level_hwnd(self.root)}
            if self.plate is not None:
                own.add(plate_top_level_hwnd(self.plate.window))
            if hwnd in own or not USER32.IsWindowVisible(hwnd):
                return False
            name = ctypes.create_unicode_buffer(128)
            USER32.GetClassNameW(hwnd, name, 128)
            if name.value in SHELL_WINDOW_CLASSES:
                return False
            box = wintypes.RECT()
            USER32.GetWindowRect(hwnd, ctypes.byref(box))
            width = USER32.GetSystemMetrics(0)
            height = USER32.GetSystemMetrics(1)
            return (box.right - box.left >= width - 2
                    and box.bottom - box.top >= height - 2)
        except Exception:                       # noqa: BLE001
            return False

    # ------------------------------------------------- подробности и буфер обмена
    def _details_rows(self) -> list:
        """Пары «подпись — значение» для карточки подробностей."""
        data = self.data
        if data is None:
            return []
        current = data.current
        day = data.today()
        rows: list = []
        if current.temperature is not None:
            rows.append((texts.t("weather.now"), ru.format_temperature(current.temperature)))
        if current.apparent is not None:
            rows.append((texts.t("details.feels"), ru.format_temperature(current.apparent)))
        if day is not None and (day.t_max is not None or day.t_min is not None):
            rows.append((texts.t("details.range"),
                         f"{ru.format_temperature(day.t_max)} / "
                         f"{ru.format_temperature(day.t_min)}"))
        if current.humidity is not None:
            rows.append((texts.t("details.humidity"), f"{current.humidity:.0f} %"))
        if current.pressure:
            rows.append((texts.t("details.pressure"), ru.format_pressure(current.pressure)))
        if current.wind_speed is not None:
            rows.append((texts.t("details.wind"),
                         ru.format_wind(current.wind_direction, current.wind_speed)))
        if current.wind_gusts is not None:
            rows.append((texts.t("details.gusts"),
                         f"{current.wind_gusts:.0f} " + texts.t("unit.m_s")))
        if current.cloud_cover is not None:
            rows.append((texts.t("details.clouds"), f"{current.cloud_cover:.0f} %"))
        if current.uv_index is not None:
            rows.append((texts.t("details.uv"), f"{current.uv_index:.0f}"))
        if self.pressure_trend:
            rows.append((texts.t("details.trend"),
                         texts.t(f"trend.{self.pressure_trend}")
                         + self._pressure_arrow()))
        if self.config.option("moon_phase", True):
            now_moon = self.data.now_local()
            rows.append((texts.t("details.moon"),
                         f"{texts.t(moon_mod.text_key(now_moon))} · "
                         f"{moon_mod.illumination(now_moon) * 100:.0f} %"))
        if self.daylight.sunrise and self.daylight.sunset:
            rows.append((texts.t("details.sun"),
                         f"{ru.format_hhmm(self.daylight.sunrise)} — "
                         f"{ru.format_hhmm(self.daylight.sunset)}"))
        rows.append((texts.t("details.daylight"),
                     ru.format_daylight(self.daylight.seconds)))
        if self.precip_text:
            rows.append((texts.t("details.precip"), self.precip_text))
        tomorrow = self._tomorrow_text()
        if tomorrow:
            rows.append((texts.t("details.tomorrow"),
                         tomorrow.split(": ", 1)[-1]))
        if self._show_traffic and self.traffic is not None:
            rows.append((texts.t("details.traffic"),
                         f"{self.traffic.title()} — {self.traffic.description()}"))
        rows.append((texts.t("details.source"), self.footer_text))
        return rows

    def _weather_summary(self) -> str:
        """Текст погоды для буфера обмена — чтобы отправить близким."""
        city = self.city.label() if self.city else texts.t("city.none")
        head = f"{city}: "
        data = self.data
        if data is None:
            return head + texts.t("desc.loading")
        current = data.current
        parts = [ru.format_temperature(current.temperature), ru.describe(current.code)]
        if current.apparent is not None:
            parts.append(texts.t("feels", value=ru.format_temperature(current.apparent)))
        if current.wind_speed is not None:
            parts.append(texts.t("wind", value=ru.format_wind(current.wind_direction,
                                                             current.wind_speed)))
        if current.humidity is not None:
            parts.append(texts.t("humidity", value=f"{current.humidity:.0f}"))
        lines = [head + ", ".join(part for part in parts if part)]
        if self.precip_text:
            lines.append(self.precip_text)
        tomorrow = self._tomorrow_text()
        if tomorrow:
            lines.append(tomorrow)
        if self.footer_text:
            lines.append(self.footer_text)
        return "\n".join(lines)

    def open_details(self) -> None:
        """Карточка с подробностями: много данных, но виджет не растёт."""
        self.keep_plate_below()
        ask_details(self.root, self.pal, texts.t("details.title"),
                    self._details_rows(), self._weather_summary())
        self.keep_plate_below()

    def copy_weather(self) -> None:
        """Скопировать сводку погоды в буфер обмена."""
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(self._weather_summary())
            self.footer_text = texts.t("menu.copy_done")
            self._redraw()
        except tk.TclError:
            pass

    # ------------------------------------------------------------- второй город
    def set_alt_city(self) -> None:
        """Выбрать второй город (для дачи, работы, поездок)."""
        chosen = ask_city(self.root, self.city_alt, frameless=self._frameless,
                          palette=self.pal)
        if not chosen:
            return
        self.city_alt = chosen
        self.config.set_alt_city(chosen)
        self._rebuild_menu()

    def clear_alt_city(self) -> None:
        self.city_alt = None
        self.config.set_alt_city(None)
        self._rebuild_menu()

    def switch_city(self) -> None:
        """Поменять основной и второй город местами."""
        if self.city_alt is None:
            return
        current = self.city
        self.city, self.city_alt = self.city_alt, current
        self.config.city = self.city
        self.config.set_alt_city(self.city_alt)
        self._save_config()
        self._request_weather(force=True)
        if self._show_traffic and self.city is not None:
            self._load_traffic(self.city)
        self._rebuild_menu()

    # --------------------------------------------------------- обновления
    def check_updates(self, manual: bool = False) -> None:
        """Спросить про новую версию. Без сети и без файла — просто тишина."""
        if self._update_busy:
            return
        self._update_busy = True
        if manual:
            self.footer_text = texts.t("update.checking")
            self._redraw()
        thread = threading.Thread(target=self._update_worker, args=(manual,),
                                  daemon=True)
        thread.start()

    def _update_worker(self, manual: bool) -> None:
        feed = update_mod.feed_url(APP_DIR)
        found = update_mod.fetch_latest(feed, version_mod.VERSION) if feed else None
        self._queue.put(("update", {"found": found, "manual": manual}, None))

    def _apply_update_result(self, found, manual: bool) -> None:
        self._update_busy = False
        skipped = str(self.config.option("skip_update", "") or "")
        if found is not None and found.version == skipped:
            found = None
        self.update_available = found
        if found is None:
            if manual:
                self.footer_text = texts.t("update.offline" if not update_mod.feed_url(APP_DIR)
                                           else "update.up_to_date")
                self._redraw()
            return
        self._redraw()
        if manual:
            self.open_update_card()

    def open_update_card(self) -> None:
        """Карточка «доступно обновление»: ничего не ставит без согласия."""
        found = self.update_available
        if found is None:
            return
        self.keep_plate_below()
        choice = ask_update(self.root, self.pal, found.version, list(found.notes or []),
                            found.url, found.size_text())
        self.keep_plate_below()
        if choice == "download" and found.url:
            self._open_in_browser(found.url)
        elif choice == "skip":
            self.config.set_option("skip_update", found.version)
            self._save_config()
            self.update_available = None
            self._redraw()

    @staticmethod
    def _open_in_browser(url: str) -> None:
        try:
            os.startfile(url)               # noqa: S606 — обычная ссылка на архив
        except OSError:
            pass

    def quit(self) -> None:
        self._save_geometry()
        self._save_config()
        if self.plate is not None:
            self.plate.hide()
        self._unregister_hotkey()
        self._cancel_pending_timers()
        try:
            self.root.destroy()
        except tk.TclError:
            pass


def key_for(day, city_now: datetime) -> str:
    """Ключ времени дня (утро/день/вечер/ночь) для текущего момента."""
    return ru.daypart(city_now, day.sunrise if day else None, day.sunset if day else None)


def run(screenshot: str | None = None, exit_after: bool = False,
        config_path: str | None = None) -> None:
    _enable_dpi_awareness()
    root = tk.Tk()
    config = Config(config_path)
    WeatherWidget(root, config, screenshot_path=screenshot, exit_after=exit_after)
    root.mainloop()
