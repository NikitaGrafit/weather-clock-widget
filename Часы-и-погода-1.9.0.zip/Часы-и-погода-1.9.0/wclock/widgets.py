# -*- coding: utf-8 -*-
"""Небольшие элементы интерфейса в стиле виджета.

Системные кнопки Tk выглядят чужеродно рядом с тёмными окнами виджета,
поэтому кнопки рисуются на Canvas: скруглённая плашка, акцентная рамка,
подсветка под курсором и нажатие.
"""

from __future__ import annotations

import tkinter as tk
from typing import Callable

from . import icons


class FlatButton(tk.Canvas):
    """Плоская кнопка со скруглёнными углами в цветах виджета."""

    def __init__(self, master: tk.Misc, text: str, command: Callable[[], None] | None = None,
                 palette: dict | None = None, width: int | None = 120, height: int = 34,
                 radius: float = 9.0):
        palette = palette or {}
        self.fill = palette.get("panel", "#141c33")
        self.border = palette.get("border", "#2c3f63")
        self.accent = palette.get("accent", "#5fb0ff")
        self.on_accent = palette.get("bg_top", "#0d1729")
        self.text_color = palette.get("text", "#eaf2ff")
        self.font = palette.get("button_font") or ("Segoe UI", 10)
        self.command = command
        self.radius = radius
        self._state = "normal"
        self._text = text
        if width is None:                       # ширина по тексту подписи
            width = self._fit_width(master, text)
        super().__init__(master, width=width, height=height, highlightthickness=0,
                         bd=0, bg=palette.get("bg_top", "#0d1729"), takefocus=0)
        self.configure(cursor="hand2")
        self.bind("<Enter>", lambda event: self._set_state("hover"))
        self.bind("<Leave>", lambda event: self._set_state("normal"))
        self.bind("<Button-1>", lambda event: self._set_state("press"))
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Return>", lambda event: self._invoke())
        self.bind("<space>", lambda event: self._invoke())
        self._draw()

    # ------------------------------------------------------------------ вид
    def _fit_width(self, master: tk.Misc, text: str, padding: int = 34) -> int:
        """Ширина кнопки по её подписи: длинные названия не обрезаются."""
        try:
            import tkinter.font as tkfont

            measured = tkfont.Font(root=master.winfo_toplevel(), font=self.font)
            return int(measured.measure(text)) + padding
        except Exception:                       # noqa: BLE001 — шрифт бывает недоступен
            return max(120, len(text) * 8 + padding)

    def set_text(self, text: str) -> None:
        self._text = text
        self._draw()

    def configure_palette(self, palette: dict) -> None:
        self.fill = palette.get("panel", self.fill)
        self.border = palette.get("border", self.border)
        self.accent = palette.get("accent", self.accent)
        self.on_accent = palette.get("bg_top", self.on_accent)
        self.text_color = palette.get("text", self.text_color)
        self.configure(bg=palette.get("bg_top", self.cget("bg")))
        self._draw()

    def _set_state(self, state: str) -> None:
        if state == self._state:
            return
        self._state = state
        self._draw()

    def _draw(self) -> None:
        self.delete("all")
        width = int(self.cget("width"))
        height = int(self.cget("height"))
        if self._state == "hover":
            fill, outline, text = self.accent, self.accent, self.on_accent
        elif self._state == "press":
            fill, outline, text = self.border, self.accent, self.text_color
        else:
            fill, outline, text = self.fill, self.border, self.accent
        self.create_polygon(
            icons.rounded_points(0.5, 0.5, width - 0.5, height - 0.5, self.radius),
            fill=fill, outline=outline, width=1, smooth=True)
        self.create_text(width / 2.0, height / 2.0 + 0.5, text=self._text,
                         fill=text, font=self.font)

    # ------------------------------------------------------------------ нажатие
    def _on_release(self, event) -> None:
        inside = 0 <= event.x <= int(self.cget("width")) and \
            0 <= event.y <= int(self.cget("height"))
        self._set_state("hover" if inside else "normal")
        if inside:
            self._invoke()

    def _invoke(self) -> None:
        if self.command is not None:
            self.command()
