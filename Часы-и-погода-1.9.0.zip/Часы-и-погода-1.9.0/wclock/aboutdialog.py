# -*- coding: utf-8 -*-
"""Окно «Информация о виджете»: версия, назначение, авторы.

Строится на общей основе (`dialog.ModernDialog`): без системной рамки,
со скруглением и в цветах виджета — чтобы все окна выглядели одинаково.
"""

from __future__ import annotations

import tkinter as tk

from . import texts
from . import version as v
from .dialog import ModernDialog
from .widgets import FlatButton

WRAP = 430


def ask_about(parent: tk.Misc, palette: dict | None = None) -> None:
    """Показать окно с кратким описанием виджета."""
    dialog = ModernDialog(parent, texts.t("about.title"), palette)
    body = dialog.body

    tk.Label(body, text=v.NAME, bg=dialog.panel, fg=dialog.text_color,
             font=("Segoe UI", 16, "bold"), anchor="w").pack(fill="x")
    tk.Label(body, text=texts.t("about.version", version=v.VERSION, year=v.RELEASED),
             bg=dialog.panel, fg=dialog.accent, font=("Segoe UI", 11),
             anchor="w").pack(fill="x", pady=(2, 12))

    tk.Label(body, text=texts.t("about.description"), bg=dialog.panel,
             fg=dialog.text_color, font=("Segoe UI", 10), anchor="w", justify="left",
             wraplength=WRAP).pack(fill="x")
    tk.Label(body, text=texts.t("about.data"), bg=dialog.panel, fg=dialog.muted,
             font=("Segoe UI", 9), anchor="w", justify="left",
             wraplength=WRAP).pack(fill="x", pady=(10, 14))

    card = tk.Frame(body, bg=dialog.palette.get("bg_top", "#0d1729"))
    card.pack(fill="x")
    for key, value in (("about.idea", v.AUTHOR_IDEA), ("about.code", v.AUTHOR_CODE)):
        tk.Label(card, text=texts.t(key, name=value), bg=card["bg"], fg=dialog.text_color,
                 font=("Segoe UI", 10), anchor="w").pack(fill="x", padx=14, pady=(10, 0))
    tk.Label(card, text=texts.t("about.signature"), bg=card["bg"], fg=dialog.muted,
             font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=14, pady=(6, 12))

    tk.Label(body, text=texts.t("about.hint"), bg=dialog.panel, fg=dialog.muted,
             font=("Segoe UI", 9), anchor="w", justify="left",
             wraplength=WRAP).pack(fill="x", pady=(14, 14))

    buttons = tk.Frame(body, bg=dialog.panel)
    buttons.pack(fill="x")
    FlatButton(buttons, texts.t("about.close"), dialog.close,
               palette=_button_palette(dialog), width=132, height=36).pack(side="right")

    dialog.fit(WRAP + 10)
    dialog.show()
    dialog.wait()


def _button_palette(dialog: ModernDialog) -> dict:
    return {
        "panel": dialog.palette.get("bg_bottom", "#141c33"),
        "border": dialog.divider,
        "accent": dialog.accent,
        "bg_top": dialog.panel,
        "text": dialog.text_color,
        "button_font": ("Segoe UI", 10, "bold"),
    }
