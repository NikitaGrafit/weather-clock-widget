# -*- coding: utf-8 -*-
"""Подложка виджета — полупрозрачный слой под содержимым.

Tk не умеет полупрозрачность отдельных фигур, зато умеет прозрачность всего
окна (`-alpha`) и «вырезание» цвета (`-transparentcolor`). Поэтому подложка
живёт в собственном окне: её прозрачность регулируется от плотной до полного
исчезновения, а текст и иконки остаются в главном окне и не блёкнут.

Два важных следствия, из-за которых подложка ведёт себя как часть виджета:

* позиция, размер и z-порядок задаются одним вызовом `SetWindowPos` (через
  Tk-геометрию они конфликтуют, и подложка «отставала» при перетаскивании);
* у главного окна прозрачные пиксели фона прозрачны и для мыши, поэтому клики
  по «пустым» местам виджета принимает подложка и передаёт их виджету
  (см. app._bind_plate_input).
"""

from __future__ import annotations

import ctypes
import tkinter as tk

from . import icons

TRANSPARENT_COLOR = "#ff00ff"

GA_ROOT = 2
SWP_NOACTIVATE = 0x0010
SWP_NOOWNERZORDER = 0x0200

_user32 = ctypes.windll.user32 if hasattr(ctypes, "windll") else None


def top_level_hwnd(widget: tk.Misc) -> int:
    """HWND окна верхнего уровня для виджета Tk (winfo_id даёт клиентское окно)."""
    if _user32 is None:
        return 0
    try:
        hwnd = widget.winfo_id()
        return _user32.GetAncestor(hwnd, GA_ROOT) or hwnd
    except Exception:
        return 0


class PlateWindow:
    """Окно-подложка: градиент со скруглёнными углами и своей прозрачностью."""

    def __init__(self, master: tk.Misc):
        self.window = tk.Toplevel(master)
        self.window.overrideredirect(True)
        self.window.configure(bg=TRANSPARENT_COLOR)
        # без -disabled: подложка должна принимать клики по «пустым» местам
        for option, value in (("-transparentcolor", TRANSPARENT_COLOR),
                              ("-toolwindow", True)):
            try:
                self.window.attributes(option, value)
            except tk.TclError:
                pass
        self.canvas = tk.Canvas(self.window, highlightthickness=0, bd=0,
                                bg=TRANSPARENT_COLOR, takefocus=0)
        self.canvas.pack(fill="both", expand=True)
        # окно создаётся скрытым: покажем его только когда появится прозрачность
        self.window.withdraw()
        self.visible = False
        self._drawn = None
        self._topmost = None
        self._alpha = None
        self._want = None          # последнее запрошенное место подложки

    # ------------------------------------------------------------------ win32
    def _place(self, x: int, y: int, width: int, height: int, below_hwnd: int) -> bool:
        """Позиция, размер и место в z-порядке одним вызовом Win32.

        Через Tk-геометрию этого делать нельзя: запрос Tk и последующий
        SetWindowPos конфликтуют, и подложка «отставала» при перетаскивании.
        """
        if _user32 is None:
            return False
        try:
            hwnd = top_level_hwnd(self.window) or self.window.winfo_id()
            _user32.SetWindowPos(hwnd, below_hwnd, int(x), int(y), int(width), int(height),
                                 SWP_NOACTIVATE | SWP_NOOWNERZORDER)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------ показ
    def _paint(self, width: int, height: int, top: str, bottom: str, radius: float,
               coarse: bool = False) -> None:
        self.canvas.delete("all")
        # во время анимации градиент рисуется меньшим числом полос — это дешевле
        stripes = max(24, int(height / 9)) if coarse else None
        icons.draw_background(self.canvas, width, height, {}, radius,
                              top=top, bottom=bottom, stripes=stripes)

    def update_plate(self, x: int, y: int, width: int, height: int,
                     top: str, bottom: str, radius: float, alpha: float,
                     topmost: bool, below_hwnd: int = 0, coarse: bool = False) -> None:
        if width < 4 or height < 4:
            return
        key = (width, height, top, bottom, round(radius, 1), bool(coarse))
        repaint = key != self._drawn
        if topmost != self._topmost:
            try:
                self.window.attributes("-topmost", bool(topmost))
            except tk.TclError:
                pass
            self._topmost = bool(topmost)
        if self._alpha is None or abs(float(alpha) - self._alpha) > 1e-6:
            try:
                self.window.attributes("-alpha", float(alpha))
            except tk.TclError:
                pass
            self._alpha = float(alpha)
        if repaint:
            self._drawn = key
            # рисуем ДО показа: иначе на мгновение мелькает цвет-ключ фона
            self._paint(width, height, top, bottom, radius, coarse=coarse)
        if not self.visible and float(alpha) > 0.002:
            # Сначала задаём геометрию средствами Tk, и только потом показываем:
            # при показе Tk применяет своё (устаревшее) положение, и окно
            # оказывалось «куском» в углу экрана, пока виджет не сдвинут.
            try:
                self.window.geometry(f"{width}x{height}+{int(x)}+{int(y)}")
            except tk.TclError:
                pass
            self.window.deiconify()
            self.visible = True
            # Одного раза мало: показ окна идёт своим ходом, и Windows иногда
            # успевает применить своё положение уже после нашей установки.
            # Поэтому повторяем установку места ещё пару раз, когда окно
            # заведомо отображено.
            self._reassert()
        self._want = (x, y, width, height, below_hwnd)
        if not self._place(x, y, width, height, below_hwnd):
            self.window.geometry(f"{width}x{height}+{x}+{y}")

    def _reassert(self, attempts: int = 4) -> None:
        """Повторить установку места после показа окна."""
        for step in range(attempts):
            try:
                self.window.after(30 + step * 55, self._place_wanted)
            except tk.TclError:
                return

    def _place_wanted(self) -> None:
        """Поставить подложку по последнему запрошенному месту."""
        if not self.visible or not self._want:
            return
        x, y, width, height, below_hwnd = self._want
        try:
            self._place(x, y, width, height, below_hwnd)
        except tk.TclError:
            pass

    def hide(self) -> None:
        if self.visible:
            self.window.withdraw()
            self.visible = False
        self._drawn = None

    def destroy(self) -> None:
        try:
            self.window.destroy()
        except tk.TclError:
            pass

