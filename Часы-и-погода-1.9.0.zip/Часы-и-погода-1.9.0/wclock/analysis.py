# -*- coding: utf-8 -*-
"""Расчёты по прогнозу: осадки, световой день, положение солнца."""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass
from datetime import datetime, timedelta

from . import locale_ru as ru
from . import texts
from .api import DayPoint, WeatherData

WET_PROBABILITY = 45      # вероятность осадков, % — считаем «ожидаются»
WET_AMOUNT = 0.15         # мм/час — тоже считаем осадками
LOOKAHEAD_HOURS = 24      # на сколько часов вперёд смотрим


def _step_hours(hours, index: int, default: float = 1.0, cap: float = 6.0) -> float:
    """Сколько часов покрывает запись (у MET Norway дальние точки идут по 6 часов)."""
    if 0 <= index + 1 < len(hours):
        delta = (hours[index + 1].time - hours[index].time).total_seconds() / 3600.0
        if 0 < delta <= cap:
            return delta
    return default


@dataclass
class Outlook:
    status: str = "none"          # none | now | soon
    hours_until: int = 0
    duration_hours: float = 0.0
    kind: str = "none"            # rain | snow | sleet | thunder | none
    start: datetime | None = None
    end: datetime | None = None
    max_probability: int = 0
    reference: datetime | None = None   # «сейчас» в поясе города

    @property
    def icon(self) -> str:
        return ru.ICON_FOR_PRECIP.get(self.kind, "cloudy")


def _is_wet(point) -> bool:
    return point.probability >= WET_PROBABILITY or point.precipitation >= WET_AMOUNT


def hour_index(hours, now: datetime) -> int:
    """Индекс часа, в который попадает now (или 0/-1, если данных нет)."""
    if not hours:
        return -1
    stamps = [h.time for h in hours]
    index = bisect_right(stamps, now) - 1
    return max(0, min(index, len(hours) - 1))


def analyze_precipitation(data: WeatherData) -> Outlook:
    """Когда начнутся осадки, сколько продлятся и какие именно."""
    outlook = Outlook()
    hours = data.hours
    if not hours:
        return outlook

    now = data.now_local()
    outlook.reference = now
    start_index = hour_index(hours, now)
    if start_index < 0:
        return outlook

    window = range(start_index, min(start_index + LOOKAHEAD_HOURS + 1, len(hours)))
    outlook.max_probability = max((hours[i].probability for i in window), default=0)

    current_wet = (
        data.current.precipitation >= WET_AMOUNT
        or data.current.code in ru.PRECIP_CODES
        or _is_wet(hours[start_index])
    )

    first_wet = None
    if current_wet:
        first_wet = start_index
    else:
        for index in window:
            if index == start_index:
                continue
            if _is_wet(hours[index]):
                first_wet = index
                break

    if first_wet is None:
        outlook.status = "none"
        outlook.kind = "none"
        return outlook

    last_wet = first_wet
    for index in range(first_wet + 1, min(first_wet + LOOKAHEAD_HOURS + 2, len(hours))):
        if _is_wet(hours[index]):
            last_wet = index
        else:
            break

    # вид осадков — по кодам внутри промежутка
    codes = [hours[i].code for i in range(first_wet, last_wet + 1)]
    for code in codes:
        kind = ru.precipitation_kind(code)
        if kind != "none":
            if outlook.kind in ("none",):
                outlook.kind = kind
            elif outlook.kind != kind:
                # смешанные осадки
                if {outlook.kind, kind} == {"rain", "snow"}:
                    outlook.kind = "sleet"
                elif "thunder" in (outlook.kind, kind):
                    outlook.kind = "thunder"
    if outlook.kind == "none":
        outlook.kind = ru.precipitation_kind(data.current.code) or "rain"

    end_of_stretch = hours[last_wet].time + timedelta(
        hours=_step_hours(hours, last_wet))
    if current_wet:
        outlook.status = "now"
        outlook.hours_until = 0
        outlook.duration_hours = max(0.5, (end_of_stretch - now).total_seconds() / 3600.0)
        outlook.start = now
    else:
        start_at = hours[first_wet].time
        delta_hours = (start_at - now).total_seconds() / 3600.0
        outlook.status = "soon"
        outlook.hours_until = max(1, int(round(delta_hours)))
        outlook.duration_hours = max(0.5, (end_of_stretch - start_at).total_seconds() / 3600.0)
        outlook.start = start_at
    outlook.end = end_of_stretch
    return outlook


def outlook_text(outlook: Outlook) -> str:
    """Готовая фраза для виджета (на текущем языке)."""
    if outlook.status == "none":
        text = texts.t("precip.none")
        if outlook.max_probability >= 20:
            text += texts.t("precip.none.max", value=outlook.max_probability)
        return text

    noun = ru.precipitation_noun(outlook.kind)
    duration = ru.format_duration(outlook.duration_hours)

    if outlook.status == "now":
        if outlook.duration_hours <= 1.2:
            return texts.t("precip.now.soon_end", noun=noun)
        return texts.t("precip.now.left", noun=noun, duration=duration)

    start_text = ru.format_hhmm(outlook.start) if outlook.start else ""
    tomorrow = bool(outlook.start and outlook.reference
                    and outlook.start.date() > outlook.reference.date())
    if tomorrow:
        return texts.t("precip.tomorrow", noun=noun, start=start_text, duration=duration)
    if outlook.hours_until <= 1:
        return texts.t("precip.soon", noun=noun, start=start_text, duration=duration)
    return texts.t("precip.later", noun=noun, hours=outlook.hours_until,
                   word=ru.plural_hours(outlook.hours_until),
                   start=start_text, duration=duration)


@dataclass
class Daylight:
    sunrise: datetime | None = None
    sunset: datetime | None = None
    seconds: float = 0.0
    progress: float = 0.0     # 0..1 — где сейчас солнце между восходом и закатом
    is_between: bool = False  # сейчас светло
    noon: datetime | None = None      # середина светового дня
    at_noon: bool = False             # солнце в зените (±30 минут)


# Сколько длится «зенит» вокруг середины дня
NOON_WINDOW_MINUTES = 30


def daylight_state(data: WeatherData, day: DayPoint | None = None) -> Daylight:
    state = Daylight()
    day = day or data.today()
    if day is None:
        return state
    state.sunrise = day.sunrise
    state.sunset = day.sunset
    if day.sunrise and day.sunset:
        state.seconds = max(0.0, (day.sunset - day.sunrise).total_seconds())
    else:
        state.seconds = day.daylight_seconds
    if state.seconds <= 0:
        state.seconds = day.daylight_seconds

    now = data.now_local()
    if day.sunrise and day.sunset:
        sunrise, sunset = day.sunrise, day.sunset
        # если данные пришли за другой день, считаем восход и закат сами
        if sunrise.date() != now.date() or sunset.date() != now.date():
            from . import sun as sun_module

            fresh_rise, fresh_set = sun_module.sun_times(
                now.date(), data.latitude, data.longitude, now.tzinfo)
            if fresh_rise and fresh_set:
                sunrise, sunset = fresh_rise, fresh_set
                state.sunrise, state.sunset = sunrise, sunset
                state.seconds = (sunset - sunrise).total_seconds()
        state.noon = sunrise + (sunset - sunrise) / 2
        state.at_noon = abs((now - state.noon).total_seconds()) <= NOON_WINDOW_MINUTES * 60
        if now <= sunrise:
            state.progress = 0.0
        elif now >= sunset:
            state.progress = 1.0
        else:
            total = (sunset - sunrise).total_seconds()
            state.progress = (now - sunrise).total_seconds() / total if total else 0.0
            state.is_between = True
    return state


def hourly_strip(data: WeatherData, count: int = 6) -> list:
    """Ближайшие часы для компактной строки прогноза."""
    if not data.hours:
        return []
    now = data.now_local()
    start = hour_index(data.hours, now)
    if start < 0:
        return []
    return data.hours[start:start + count]


def next_hours_text(data: WeatherData, count: int = 6) -> str:
    points = hourly_strip(data, count)
    if not points:
        return ""
    parts = []
    for point in points:
        temperature = ru.format_temperature(point.temperature) if point.temperature is not None else "—"
        parts.append(f"{ru.format_hhmm(point.time)} {temperature}")
    return " · ".join(parts)
