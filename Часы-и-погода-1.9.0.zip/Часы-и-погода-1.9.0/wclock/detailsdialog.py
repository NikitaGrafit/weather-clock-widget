# -*- coding: utf-8 -*-
"""Карточка подробностей и текст для буфера обмена.

Карточка строится на общей основе (`dialog.ModernDialog`): то же окно без
рамки, что у справки и выбора города. Так подробностей может быть сколько
угодно, а виджет на экране не растёт.
"""

from __future__ import annotations

import tkinter as tk

from . import texts
from .dialog import ModernDialog
from .widgets import FlatButton

WRAP = 430


def ask_update(parent: tk.Misc, palette: dict | None, version: str, notes: list,
               url: str, size_text: str = "", on_download=None, on_skip=None) -> str:
    """Карточка «доступно обновление»: что нового и три кнопки.

    Ничего не скачивает сама — только сообщает о выборе: 'download' | 'later'
    | 'skip'. Установка начинается лишь после согласия человека.
    """
    dialog = ModernDialog(parent, texts.t("update.title"), palette)
    body = dialog.body
    tk.Label(body, text=texts.t("update.heading", version=version), bg=dialog.panel,
             fg=dialog.accent, font=("Segoe UI", 13, "bold"), anchor="w").pack(fill="x")
    if size_text:
        tk.Label(body, text=texts.t("update.size", value=size_text), bg=dialog.panel,
                 fg=dialog.muted, font=("Segoe UI", 9), anchor="w").pack(fill="x",
                                                                        pady=(2, 0))
    card = tk.Frame(body, bg=dialog.palette.get("bg_top", "#0d1729"))
    card.pack(fill="x", pady=(10, 0))
    tk.Label(card, text=texts.t("update.whats_new"), bg=card["bg"], fg=dialog.muted,
             font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x", padx=14,
                                                            pady=(10, 4))
    for note in notes or [texts.t("update.no_notes")]:
        row = tk.Frame(card, bg=card["bg"])
        row.pack(fill="x", padx=14, pady=(0, 6))
        tk.Label(row, text="•", bg=card["bg"], fg=dialog.accent,
                 font=("Segoe UI", 10)).pack(side="left", anchor="n")
        tk.Label(row, text=note, bg=card["bg"], fg=dialog.text_color,
                 font=("Segoe UI", 9), anchor="w", justify="left",
                 wraplength=WRAP - 40).pack(side="left", fill="x", expand=True, padx=(6, 0))

    choice = {"value": "later"}

    def pick(value: str) -> None:
        choice["value"] = value
        dialog.close()

    button_palette = {
        "panel": dialog.palette.get("bg_bottom", "#141c33"), "border": dialog.divider,
        "accent": dialog.accent, "bg_top": dialog.panel, "text": dialog.text_color,
        "button_font": ("Segoe UI", 10),
    }
    buttons = tk.Frame(body, bg=dialog.panel)
    buttons.pack(fill="x", pady=(14, 0))
    FlatButton(buttons, texts.t("update.later"), lambda: pick("later"),
               palette=button_palette, width=None, height=34).pack(side="left")
    if on_skip is not None or True:
        FlatButton(buttons, texts.t("update.skip"), lambda: pick("skip"),
                   palette=button_palette, width=None, height=34).pack(side="left", padx=8)
    FlatButton(buttons, texts.t("update.download"), lambda: pick("download"),
               palette=button_palette, width=None, height=36).pack(side="right")

    dialog.fit(WRAP + 10)
    dialog.show()
    dialog.wait()
    return choice["value"]


def ask_details(parent: tk.Misc, palette: dict | None, title: str,
                rows: list[tuple[str, str]], copy_text: str = "") -> None:
    """Показать карточку с подробностями и кнопкой «Скопировать»."""
    dialog = ModernDialog(parent, title, palette)
    body = dialog.body
    card = tk.Frame(body, bg=dialog.palette.get("bg_top", "#0d1729"))
    card.pack(fill="x")

    if not rows:
        tk.Label(card, text=texts.t("details.empty"), bg=card["bg"], fg=dialog.muted,
                 font=("Segoe UI", 10), anchor="w").pack(fill="x", padx=14, pady=14)
    for index, (name, value) in enumerate(rows):
        row = tk.Frame(card, bg=card["bg"])
        row.pack(fill="x", padx=14, pady=(10 if index == 0 else 6,
                                          10 if index == len(rows) - 1 else 0))
        tk.Label(row, text=name, bg=card["bg"], fg=dialog.muted, font=("Segoe UI", 10),
                 anchor="w", width=20).pack(side="left")
        tk.Label(row, text=value, bg=card["bg"], fg=dialog.text_color,
                 font=("Segoe UI", 10, "bold"), anchor="w", justify="left",
                 wraplength=WRAP - 190).pack(side="left", fill="x", expand=True)

    copied = tk.Label(body, text=texts.t("details.copied"), bg=dialog.panel,
                      fg=dialog.accent, font=("Segoe UI", 9), anchor="w")

    def copy_to_clipboard() -> None:
        try:
            dialog.window.clipboard_clear()
            dialog.window.clipboard_append(copy_text)
            copied.pack(fill="x", pady=(10, 0))
        except tk.TclError:
            pass

    buttons = tk.Frame(body, bg=dialog.panel)
    buttons.pack(fill="x", pady=(14, 0))
    button_palette = {
        "panel": dialog.palette.get("bg_bottom", "#141c33"),
        "border": dialog.divider, "accent": dialog.accent,
        "bg_top": dialog.panel, "text": dialog.text_color,
        "button_font": ("Segoe UI", 10),
    }
    FlatButton(buttons, texts.t("about.close"), dialog.close, palette=button_palette,
               width=None, height=34).pack(side="right")
    if copy_text:
        FlatButton(buttons, texts.t("details.copy"), copy_to_clipboard,
                   palette=button_palette, width=None, height=34).pack(side="right",
                                                                       padx=8)

    dialog.fit(WRAP + 10)
    dialog.show()
    dialog.wait()
