# -*- coding: utf-8 -*-
"""Тексты интерфейса на русском и английском + текущий язык.

Все подписи виджета берутся отсюда: `t("ключ")`. Язык переключается
значком RU | EN в шапке виджета, выбор хранится в настройках.
"""

from __future__ import annotations

LANGUAGES = ("ru", "en")
LANGUAGE_TITLES = {"ru": "Русский", "en": "English"}

_active = "ru"


def set_language(code: str | None) -> str:
    """Установить язык виджета. Возвращает принятое значение."""
    global _active
    value = (code or "").strip().lower()[:2]
    _active = value if value in LANGUAGES else "ru"
    return _active


def language() -> str:
    return _active


def is_english() -> bool:
    return _active == "en"


def t(key: str, **kwargs) -> str:
    """Строка по ключу на текущем языке (с подстановкой {…})."""
    entry = STRINGS.get(key)
    if entry is None:
        return key
    template = entry.get(_active) or entry.get("ru") or key
    if not kwargs:
        return template
    try:
        return template.format(**kwargs)
    except (KeyError, IndexError):
        return template


# Названия мест: геокодер отдаёт их по-русски, для английского переводим сами.
PLACES_EN = {
    "Россия": "Russia",
    "Москва": "Moscow",
    "Санкт-Петербург": "Saint Petersburg",
    "Новосибирск": "Novosibirsk",
    "Екатеринбург": "Yekaterinburg",
    "Казань": "Kazan",
    "Нижний Новгород": "Nizhny Novgorod",
    "Челябинск": "Chelyabinsk",
    "Самара": "Samara",
    "Омск": "Omsk",
    "Ростов-на-Дону": "Rostov-on-Don",
    "Уфа": "Ufa",
    "Красноярск": "Krasnoyarsk",
    "Воронеж": "Voronezh",
    "Пермь": "Perm",
    "Волгоград": "Volgograd",
    "Краснодар": "Krasnodar",
    "Саратов": "Saratov",
    "Тюмень": "Tyumen",
    "Тольятти": "Tolyatti",
    "Ижевск": "Izhevsk",
    "Барнаул": "Barnaul",
    "Ульяновск": "Ulyanovsk",
    "Иркутск": "Irkutsk",
    "Хабаровск": "Khabarovsk",
    "Ярославль": "Yaroslavl",
    "Владивосток": "Vladivostok",
    "Махачкала": "Makhachkala",
    "Томск": "Tomsk",
    "Оренбург": "Orenburg",
    "Кемерово": "Kemerovo",
    "Новокузнецк": "Novokuznetsk",
    "Рязань": "Ryazan",
    "Астрахань": "Astrakhan",
    "Набережные Челны": "Naberezhnye Chelny",
    "Пенза": "Penza",
    "Липецк": "Lipetsk",
    "Киров": "Kirov",
    "Тула": "Tula",
    "Чебоксары": "Cheboksary",
    "Калининград": "Kaliningrad",
    "Брянск": "Bryansk",
    "Курск": "Kursk",
    "Иваново": "Ivanovo",
    "Магнитогорск": "Magnitogorsk",
    "Тверь": "Tver",
    "Ставрополь": "Stavropol",
    "Белгород": "Belgorod",
    "Сочи": "Sochi",
    "Симферополь": "Simferopol",
    "Севастополь": "Sevastopol",
    "Сургут": "Surgut",
    "Владимир": "Vladimir",
    "Архангельск": "Arkhangelsk",
    "Калуга": "Kaluga",
    "Смоленск": "Smolensk",
    "Вологда": "Vologda",
    "Мурманск": "Murmansk",
    "Якутск": "Yakutsk",
    "Краснодарский край": "Krasnodar Krai",
    "Московская область": "Moscow Oblast",
    "Ленинградская область": "Leningrad Oblast",
    "Новосибирская область": "Novosibirsk Oblast",
    "Свердловская область": "Sverdlovsk Oblast",
    "Татарстан": "Tatarstan",
    "Нижегородская область": "Nizhny Novgorod Oblast",
    "Челябинская область": "Chelyabinsk Oblast",
    "Самарская область": "Samara Oblast",
    "Омская область": "Omsk Oblast",
    "Ростовская область": "Rostov Oblast",
    "Башкортостан": "Bashkortostan",
    "Красноярский край": "Krasnoyarsk Krai",
    "Воронежская область": "Voronezh Oblast",
    "Пермский край": "Perm Krai",
    "Волгоградская область": "Volgograd Oblast",
    "Саратовская область": "Saratov Oblast",
    "Тюменская область": "Tyumen Oblast",
    "Удмуртия": "Udmurtia",
    "Алтайский край": "Altai Krai",
    "Ульяновская область": "Ulyanovsk Oblast",
    "Иркутская область": "Irkutsk Oblast",
    "Хабаровский край": "Khabarovsk Krai",
    "Ярославская область": "Yaroslavl Oblast",
    "Приморский край": "Primorsky Krai",
    "Дагестан": "Dagestan",
    "Томская область": "Tomsk Oblast",
    "Оренбургская область": "Orenburg Oblast",
    "Кемеровская область": "Kemerovo Oblast",
    "Рязанская область": "Ryazan Oblast",
    "Астраханская область": "Astrakhan Oblast",
    "Пензенская область": "Penza Oblast",
    "Липецкая область": "Lipetsk Oblast",
    "Кировская область": "Kirov Oblast",
    "Тульская область": "Tula Oblast",
    "Чувашия": "Chuvashia",
    "Калининградская область": "Kaliningrad Oblast",
    "Брянская область": "Bryansk Oblast",
    "Курская область": "Kursk Oblast",
    "Ивановская область": "Ivanovo Oblast",
    "Тверская область": "Tver Oblast",
    "Ставропольский край": "Stavropol Krai",
    "Белгородская область": "Belgorod Oblast",
    "Крым": "Crimea",
    "Ханты-Мансийский автономный округ": "Khanty-Mansi Autonomous Okrug",
    "Владимирская область": "Vladimir Oblast",
    "Архангельская область": "Arkhangelsk Oblast",
    "Калужская область": "Kaluga Oblast",
    "Смоленская область": "Smolensk Oblast",
    "Вологодская область": "Vologda Oblast",
    "Мурманская область": "Murmansk Oblast",
    "Саха": "Sakha",
    "Беларусь": "Belarus",
    "Казахстан": "Kazakhstan",
    "Украина": "Ukraine",
    "Грузия": "Georgia",
    "Армения": "Armenia",
    "Турция": "Türkiye",
    "Германия": "Germany",
    "Франция": "France",
    "Италия": "Italy",
    "Испания": "Spain",
    "США": "United States",
    "Великобритания": "United Kingdom",
    "Объединённые Арабские Эмираты": "United Arab Emirates",
    "Таиланд": "Thailand",
    "Египет": "Egypt",
}


def place(name: str) -> str:
    """Название города, региона или страны на текущем языке."""
    if not name:
        return name
    if _active != "en":
        return name
    return PLACES_EN.get(name, name)


STRINGS: dict[str, dict[str, str]] = {
    # ------------------------------------------------------------------ шапка
    "city.none": {"ru": "Город не выбран", "en": "No city selected"},
    "header.language": {"ru": "Язык", "en": "Language"},

    # ------------------------------------------------------------------ виджет
    "desc.loading": {"ru": "Загрузка прогноза…", "en": "Loading forecast…"},
    "feels": {"ru": "ощущается {value}", "en": "feels like {value}"},
    "temp.max": {"ru": "макс {value}", "en": "high {value}"},
    "temp.min": {"ru": "мин {value}", "en": "low {value}"},
    "wind": {"ru": "ветер {value}", "en": "wind {value}"},
    "humidity": {"ru": "влажность {value}%", "en": "humidity {value}%"},
    "daylight": {"ru": "Световой день: {value}", "en": "Daylight: {value}"},
    "daylight.noon": {"ru": "Солнце в зените", "en": "Sun at its zenith"},
    "daylight.until_sunset": {"ru": "до заката {value}", "en": "sunset in {value}"},
    "daylight.until_sunrise": {"ru": "до восхода {value}", "en": "sunrise in {value}"},
    "tomorrow": {"ru": "Завтра: {value}", "en": "Tomorrow: {value}"},
    "precip.waiting": {"ru": "Ожидаю данные метеослужбы…",
                       "en": "Waiting for weather data…"},
    "hour.now": {"ru": "сейчас", "en": "now"},
    "clock.am": {"ru": "AM", "en": "AM"},
    "clock.pm": {"ru": "PM", "en": "PM"},

    # ------------------------------------------------------------------ подвал
    "footer.updated": {"ru": "обновлено {stamp} · источник: {source}",
                       "en": "updated {stamp} · source: {source}"},
    "footer.refreshing": {"ru": "обновляю прогноз… последние данные {stamp}",
                          "en": "refreshing… last data {stamp}"},
    "footer.offline": {"ru": "нет связи с метеослужбой — данные от {stamp}",
                       "en": "no connection — data from {stamp}"},
    "footer.stale": {"ru": "данные от {stamp} устарели — проверьте интернет",
                     "en": "data from {stamp} is outdated — check your internet"},
    "status.refreshing": {"ru": "обновляю прогноз…", "en": "refreshing…"},
    "status.detecting_city": {"ru": "определяю город…", "en": "detecting the city…"},
    "status.loading": {"ru": "загружаю прогноз…", "en": "loading forecast…"},
    "window.title": {"ru": "Часы и погода", "en": "Clock and weather"},
    "status.offline": {"ru": "нет связи с метеослужбой",
                       "en": "no connection to the weather service"},

    # ------------------------------------------------------------------ осадки
    "precip.none": {"ru": "Осадков в ближайшие 24 ч не ожидается",
                    "en": "No precipitation expected in the next 24 hours"},
    "precip.none.max": {"ru": " (макс. вероятность {value}%)",
                        "en": " (max chance {value}%)"},
    "precip.fallback": {"ru": "Осадки", "en": "Precipitation"},
    "precip.now.soon_end": {"ru": "{noun} сейчас, закончатся в течение часа",
                            "en": "{noun} now, ending within the hour"},
    "precip.now.left": {"ru": "{noun} сейчас, ещё около {duration}",
                        "en": "{noun} now, about {duration} left"},
    "precip.tomorrow": {"ru": "{noun} ожидается завтра около {start}, продлятся ≈ {duration}",
                        "en": "{noun} expected tomorrow around {start}, lasting ≈ {duration}"},
    "precip.soon": {"ru": "{noun} в ближайший час (около {start}), продлятся ≈ {duration}",
                    "en": "{noun} within the hour (around {start}), lasting ≈ {duration}"},
    "precip.later": {"ru": "{noun} через {hours} {word} (около {start}), продлятся ≈ {duration}",
                     "en": "{noun} in {hours} {word} (around {start}), lasting ≈ {duration}"},
    "precip.rain": {"ru": "Дождь", "en": "Rain"},
    "precip.snow": {"ru": "Снег", "en": "Snow"},
    "precip.sleet": {"ru": "Ледяной дождь", "en": "Freezing rain"},
    "precip.thunder": {"ru": "Гроза", "en": "Thunderstorm"},

    # ------------------------------------------------------------------ пробки
    "traffic.title": {"ru": "Пробки: {level} из 10", "en": "Traffic: {level} of 10"},
    "traffic.free": {"ru": "Дороги свободны", "en": "Roads are clear"},
    "traffic.busy": {"ru": "Движение затруднено", "en": "Heavy traffic"},
    "traffic.jam": {"ru": "Серьёзные пробки", "en": "Major traffic jams"},
    "traffic.growing": {"ru": "растут", "en": "growing"},
    "traffic.falling": {"ru": "спадают", "en": "easing"},
    "traffic.demo_source": {"ru": "тестовые данные", "en": "test data"},
    "traffic.waiting": {"ru": "Смотрю пробки…", "en": "Checking traffic…"},
    "traffic.none": {"ru": "Пробки: нет данных", "en": "Traffic: no data"},
    "menu.traffic": {"ru": "Пробки (тестовый режим)",
                     "en": "Traffic (test mode)"},
    "menu.text_outline": {"ru": "Обводка текста (на светлых обоях)",
                          "en": "Text outline (on light wallpapers)"},
    "menu.view": {"ru": "Вид", "en": "Appearance"},
    "menu.data": {"ru": "Данные", "en": "Data"},
    "menu.window": {"ru": "Окно", "en": "Window"},
    "menu.presets": {"ru": "Готовые наборы", "en": "Presets"},
    "menu.preset_minimal": {"ru": "Минимал: только часы и погода",
                            "en": "Minimal: clock and weather only"},
    "menu.preset_normal": {"ru": "Обычный", "en": "Standard"},
    "menu.preset_detailed": {"ru": "Подробный: всё включено",
                             "en": "Detailed: everything on"},
    "menu.tomorrow": {"ru": "Строка «Завтра»", "en": "“Tomorrow” line"},
    "menu.sun_countdown": {"ru": "Отсчёт до заката вместо времени",
                           "en": "Countdown to sunset instead of times"},
    "menu.night_dim": {"ru": "Ночью приглушать", "en": "Dim at night"},
    "menu.hide": {"ru": "Скрыть на время", "en": "Hide for a while"},
    "menu.hide_10": {"ru": "На 10 минут", "en": "For 10 minutes"},
    "menu.hide_60": {"ru": "На час", "en": "For an hour"},
    "menu.hide_morning": {"ru": "До утра", "en": "Until morning"},
    "menu.hide_show": {"ru": "Показать сейчас", "en": "Show now"},
    "menu.games": {"ru": "Скрывать в играх и фильмах",
                   "en": "Hide over fullscreen games and videos"},
    "menu.hotkey": {"ru": "Горячая клавиша Ctrl+Alt+W", "en": "Hotkey Ctrl+Alt+W"},
    "menu.details": {"ru": "Подробности погоды…", "en": "Weather details…"},
    "menu.copy": {"ru": "Скопировать погоду", "en": "Copy weather"},
    "menu.copy_done": {"ru": "Погода скопирована в буфер", "en": "Weather copied"},
    "menu.city_alt_set": {"ru": "Второй город…", "en": "Second city…"},
    "menu.city_alt_clear": {"ru": "Убрать второй город", "en": "Remove second city"},
    "menu.city_switch": {"ru": "Переключить город", "en": "Switch city"},
    "details.title": {"ru": "Подробности погоды", "en": "Weather details"},
    "details.empty": {"ru": "Данных пока нет — идёт загрузка",
                      "en": "No data yet — loading"},
    "weather.now": {"ru": "Сейчас", "en": "Now"},
    "unit.m_s": {"ru": "м/с", "en": "m/s"},
    "week": {"ru": "неделя {value}", "en": "week {value}"},
    "moon.new": {"ru": "новолуние", "en": "new moon"},
    "moon.waxing": {"ru": "растущая Луна", "en": "waxing moon"},
    "moon.full": {"ru": "полнолуние", "en": "full moon"},
    "moon.waning": {"ru": "убывающая Луна", "en": "waning moon"},
    "uv": {"ru": "УФ {value}", "en": "UV {value}"},
    "trend.rising": {"ru": "растёт", "en": "rising"},
    "trend.falling": {"ru": "падает", "en": "falling"},
    "trend.steady": {"ru": "держится", "en": "steady"},
    "menu.week": {"ru": "Номер недели в дате", "en": "Week number in the date"},
    "menu.moon": {"ru": "Фаза Луны у даты", "en": "Moon phase near the date"},
    "menu.hourly_count": {"ru": "Длина почасового ряда", "en": "Hourly row length"},
    "menu.hours": {"ru": "{value} часов", "en": "{value} hours"},
    "menu.updates": {"ru": "Проверить обновления", "en": "Check for updates"},
    "update.title": {"ru": "Обновление виджета", "en": "Widget update"},
    "update.heading": {"ru": "Доступна версия {version}", "en": "Version {version} is available"},
    "update.size": {"ru": "Размер загрузки: {value}", "en": "Download size: {value}"},
    "update.whats_new": {"ru": "Что нового", "en": "What's new"},
    "update.no_notes": {"ru": "Описание изменений не приложено",
                        "en": "No change description attached"},
    "update.download": {"ru": "Скачать", "en": "Download"},
    "update.later": {"ru": "Позже", "en": "Later"},
    "update.skip": {"ru": "Не напоминать", "en": "Don't remind"},
    "update.available": {"ru": "доступна версия {version}", "en": "version {version} available"},
    "update.up_to_date": {"ru": "Установлена последняя версия",
                          "en": "You have the latest version"},
    "update.checking": {"ru": "Проверяю обновления…", "en": "Checking for updates…"},
    "update.offline": {"ru": "Не удалось проверить обновления",
                       "en": "Could not check for updates"},
    "details.moon": {"ru": "Луна", "en": "Moon"},
    "details.uv": {"ru": "УФ-индекс", "en": "UV index"},
    "details.trend": {"ru": "Давление", "en": "Pressure"},
    "details.copy": {"ru": "Скопировать", "en": "Copy"},
    "details.copied": {"ru": "Скопировано в буфер обмена", "en": "Copied to clipboard"},
    "details.feels": {"ru": "Ощущается", "en": "Feels like"},
    "details.range": {"ru": "Максимум и минимум", "en": "High and low"},
    "details.humidity": {"ru": "Влажность", "en": "Humidity"},
    "details.pressure": {"ru": "Давление", "en": "Pressure"},
    "details.wind": {"ru": "Ветер", "en": "Wind"},
    "details.gusts": {"ru": "Порывы", "en": "Gusts"},
    "details.clouds": {"ru": "Облачность", "en": "Cloud cover"},
    "details.sun": {"ru": "Восход и закат", "en": "Sunrise and sunset"},
    "details.daylight": {"ru": "Световой день", "en": "Daylight"},
    "details.precip": {"ru": "Осадки", "en": "Precipitation"},
    "details.traffic": {"ru": "Пробки", "en": "Traffic"},
    "details.tomorrow": {"ru": "Завтра", "en": "Tomorrow"},
    "details.source": {"ru": "Источник данных", "en": "Data source"},

    # ------------------------------------------------------------------ меню
    "menu.refresh": {"ru": "Обновить прогноз", "en": "Refresh forecast"},
    "menu.city": {"ru": "Выбрать город…", "en": "Choose city…"},
    "menu.topmost": {"ru": "Поверх всех окон", "en": "Always on top"},
    "menu.frameless": {"ru": "Оконная рамка", "en": "Window frame"},
    "menu.autostart": {"ru": "Запускать при входе в систему",
                       "en": "Start with Windows"},
    "menu.seconds": {"ru": "Показывать секунды", "en": "Show seconds"},
    "menu.weekday": {"ru": "Показывать день недели", "en": "Show weekday"},
    "menu.hourly": {"ru": "Почасовой прогноз", "en": "Hourly forecast"},
    "menu.bigger": {"ru": "Крупнее", "en": "Bigger"},
    "menu.smaller": {"ru": "Мельче", "en": "Smaller"},
    "menu.normal_size": {"ru": "Обычный размер", "en": "Default size"},
    "menu.alpha": {"ru": "Прозрачность содержимого",
                   "en": "Content transparency"},
    "menu.opaque": {"ru": "Непрозрачный", "en": "Opaque"},
    "menu.plate_solid": {"ru": "100 %", "en": "100 %"},
    "menu.size": {"ru": "Размер виджета", "en": "Widget size"},
    "menu.hour_format": {"ru": "Формат времени", "en": "Time format"},
    "menu.icons": {"ru": "Иконки погоды", "en": "Weather icons"},
    "menu.icons_vivid": {"ru": "Объёмные и красочные", "en": "Volumetric and colourful"},
    "menu.icons_mono": {"ru": "Монохромные", "en": "Monochrome"},
    "menu.hour24": {"ru": "24 часа", "en": "24-hour"},
    "menu.hour12": {"ru": "12 часов (AM/PM)", "en": "12-hour (AM/PM)"},
    "menu.plate_alpha": {"ru": "Фон виджета",
                         "en": "Widget background"},
    "menu.plate_color": {"ru": "Цвет фона (RGB)…", "en": "Background colour (RGB)…"},
    "menu.clock_font": {"ru": "Шрифт времени", "en": "Clock font"},
    "menu.font_default": {"ru": "По умолчанию (моноширинный)",
                          "en": "Default (monospace)"},
    "menu.font_thin": {"ru": "Тонкие", "en": "Thin"},
    "menu.font_medium": {"ru": "Средние", "en": "Regular"},
    "menu.font_wide": {"ru": "Широкие", "en": "Wide"},
    "menu.font_mine": {"ru": "Мои шрифты", "en": "My fonts"},
    "menu.font_load": {"ru": "Загрузить шрифт (TTF/OTF)…",
                       "en": "Load font (TTF/OTF)…"},
    "menu.font_open": {"ru": "Открыть папку со шрифтами",
                       "en": "Open fonts folder"},
    "menu.font_none": {"ru": "пока своих шрифтов нет", "en": "no custom fonts yet"},
    "menu.language": {"ru": "Язык: Русский", "en": "Language: English"},
    "menu.about": {"ru": "Информация о виджете", "en": "About the widget"},
    "menu.quit": {"ru": "Выход", "en": "Quit"},
    "menu.plate_off": {"ru": "Без фона (0 %)", "en": "No background (0 %)"},
    "menu.plate_percent": {"ru": "{value} %", "en": "{value} %"},

    # ------------------------------------------------------------------ сообщения
    "note.autostart_on": {"ru": "автозапуск включён: {path}",
                          "en": "autostart enabled: {path}"},
    "note.autostart_off": {"ru": "автозапуск выключен", "en": "autostart disabled"},
    "note.autostart_failed": {"ru": "Не удалось изменить автозапуск:\n{error}",
                              "en": "Could not change autostart:\n{error}"},
    "title.autostart": {"ru": "Автозапуск", "en": "Autostart"},
    "fonts.loaded": {"ru": "Загружено файлов: {count}. В часах: {family}",
                     "en": "Files loaded: {count}. In the clock: {family}"},
    "fonts.added": {"ru": "Файлов добавлено: {count}.\nВыберите шрифт в меню: "
                          "Шрифт времени → Мои шрифты.",
                    "en": "Files added: {count}.\nPick a font in: "
                          "Clock font → My fonts."},
    "fonts.restart_hint": {"ru": "\nЕсли шрифт не появился в списке — перезапустите виджет.",
                           "en": "\nIf the font is missing from the list, restart the widget."},
    "fonts.title": {"ru": "Мои шрифты", "en": "My fonts"},
    "fonts.choose": {"ru": "Выберите файлы шрифтов", "en": "Choose font files"},
    "fonts.filter": {"ru": "Шрифты", "en": "Fonts"},
    "files.all": {"ru": "Все файлы", "en": "All files"},
    "fonts.open_failed": {"ru": "не удалось открыть папку шрифтов: {error}",
                          "en": "could not open the fonts folder: {error}"},

    # ------------------------------------------------------------------ диалог города
    "city.title": {"ru": "Выбор города", "en": "Choose city"},
    "city.label": {"ru": "Город:", "en": "City:"},
    "city.search": {"ru": "Найти", "en": "Search"},
    "city.detect": {"ru": "Определить по IP", "en": "Detect by IP"},
    "city.popular": {"ru": "Популярные города. Или введите название и нажмите «Найти».",
                     "en": "Popular cities. Or type a name and press Search."},
    "city.found": {"ru": "Найдено: {count}", "en": "Found: {count}"},
    "city.searching": {"ru": "Ищу…", "en": "Searching…"},
    "city.nothing": {"ru": "Ничего не найдено — попробуйте другое написание",
                     "en": "Nothing found — try another spelling"},
    "city.detecting": {"ru": "Определяю город…", "en": "Detecting city…"},
    "city.failed": {"ru": "Не удалось определить город: {error}",
                    "en": "Could not detect the city: {error}"},
    "city.enter_name": {"ru": "Введите название города", "en": "Enter a city name"},
    "city.pick_first": {"ru": "Сначала выберите город в списке",
                        "en": "Pick a city from the list first"},
    "city.search_error": {"ru": "Ошибка поиска: {error}", "en": "Search failed: {error}"},
    "city.detected_ip": {"ru": "Определён по IP: {city} — можно выбрать другой город",
                         "en": "Detected by IP: {city} — you can pick another city"},
    "city.current": {"ru": "Текущий город: {city}. Введите название и нажмите «Найти».",
                     "en": "Current city: {city}. Type a name and press Search."},
    "city.choose": {"ru": "Выбрать", "en": "Select"},
    "city.cancel": {"ru": "Отмена", "en": "Cancel"},

    # ------------------------------------------------------------------ о виджете
    "about.title": {"ru": "Информация о виджете", "en": "About the widget"},
    "about.version": {"ru": "Версия v{version} · {year} год",
                      "en": "Version v{version} · {year}"},
    "about.description": {
        "ru": "Виджет рабочего стола: цифровые часы, дата, погода выбранного "
              "города со значками, длина светового дня, прогноз осадков на сутки, "
              "баллы пробок и почасовой ряд. Фон настраивается вплоть до полного "
              "исчезновения, шрифт часов выбирается из двадцати или загружается "
              "свой, язык интерфейса переключается между русским и английским.",
        "en": "Desktop widget: digital clock, date, weather for the chosen city "
              "with icons, daylight length, a 24-hour precipitation outlook, "
              "traffic score and an hourly strip. The background is adjustable "
              "down to fully transparent, the clock font is chosen from twenty "
              "or loaded by you, and the interface switches between Russian "
              "and English."},
    "about.data": {
        "ru": "Данные: Open-Meteo и MET Norway (погода), Яндекс (пробки). "
              "Ключи API не нужны.",
        "en": "Data: Open-Meteo and MET Norway (weather), Yandex (traffic). "
              "No API keys required."},
    "about.idea": {"ru": "Идея и вдохновение — {name}", "en": "Idea and inspiration — {name}"},
    "about.code": {"ru": "Реализация — {name}", "en": "Implementation — {name}"},
    "about.signature": {"ru": "Подпись в виджете: IDEA by Nikita Konogin и знак проекта",
                        "en": "Signature in the widget: IDEA by Nikita Konogin and the project mark"},
    "about.close": {"ru": "Закрыть", "en": "Close"},
    "about.hint": {"ru": "Обновления нумеруются: major.minor.patch — крупные "
                         "изменения, новые возможности, исправления.",
                   "en": "Updates are numbered major.minor.patch — breaking "
                         "changes, new features, fixes."},

    # ------------------------------------------------------------------ диалог цвета
    "color.title": {"ru": "Цвет фона", "en": "Background colour"},
    "color.heading": {"ru": "Фон виджета", "en": "Widget background"},
    "color.hint": {"ru": "Задайте цвета R, G, B от 0 до 255. Верхний и нижний цвет "
                         "образуют плавный переход.\n"
                         "Если сделать фон светлее текста, буквы и иконки "
                         "станут тёмными автоматически.",
                   "en": "Set R, G, B from 0 to 255. The top and bottom colours "
                         "form a smooth gradient.\n"
                         "If the background becomes lighter than the text, letters "
                         "and icons turn dark automatically."},
    "color.top": {"ru": "Верхний цвет", "en": "Top colour"},
    "color.bottom": {"ru": "Нижний цвет", "en": "Bottom colour"},
    "color.copy": {"ru": "Скопировать верх → низ", "en": "Copy top → bottom"},
    "color.theme": {"ru": "Как в теме", "en": "Theme colours"},
    "color.apply": {"ru": "Применить", "en": "Apply"},
    "color.cancel": {"ru": "Отмена", "en": "Cancel"},
}
