# -*- coding: utf-8 -*-
"""Векторные иконки погоды и времени дня, рисуемые на tkinter.Canvas.

Иконки масштабируются под любой размер окна, потому что все координаты
считаются как доли от переданного размера.
"""

from __future__ import annotations

import math
import tkinter as tk

from . import theme

# Цвет по умолчанию для «фона» внутри иконки (используется для маски луны и
# горизонта у восхода). Вызывающий код передаёт реальный цвет градиента.
DEFAULT_BG = "#121a2e"

# Текущая схема цветов иконок. По умолчанию — тёмная тема; на светлой подложке
# виджет ставит «чернильный» вариант (см. theme.ink_icons).
_COLORS: dict = dict(theme.ICONS)

# Стиль иконок: "mono" — плоский монохромный (как было), "vivid" — объёмный
_STYLE = "mono"


def set_color_scheme(colors: dict | None = None) -> None:
    """Переопределить цвета иконок (None — вернуть цвета текущего стиля)."""
    global _COLORS
    _COLORS = dict(colors) if colors else theme.icon_palette(_STYLE)


def set_style(style: str) -> None:
    """Выбрать стиль иконок: mono (плоский) или vivid (объёмный)."""
    global _STYLE, _COLORS
    _STYLE = style if style in theme.ICON_STYLES else "mono"
    _COLORS = theme.icon_palette(_STYLE)


def style() -> str:
    return _STYLE


def color(name: str) -> str:
    """Цвет иконки с учётом текущей схемы."""
    return _COLORS.get(name) or theme.ICONS.get(name) or "#ffffff"


# --------------------------------------------------------------------------- примитивы

def _sun(cv: tk.Canvas, cx: float, cy: float, r: float, color: str, tag,
         rays: bool = True) -> None:
    if rays:
        width = max(1, int(round(r * 0.26)))
        for index in range(8):
            angle = math.radians(index * 45)
            r1, r2 = r * 1.30, r * 1.78
            cv.create_line(
                cx + math.cos(angle) * r1, cy + math.sin(angle) * r1,
                cx + math.cos(angle) * r2, cy + math.sin(angle) * r2,
                fill=color, width=width, capstyle="round", tags=tag,
            )
    cv.create_oval(cx - r, cy - r, cx + r, cy + r, fill=color, outline="", tags=tag)


def _moon(cv: tk.Canvas, cx: float, cy: float, r: float, color: str, bg: str, tag) -> None:
    cv.create_oval(cx - r, cy - r, cx + r, cy + r, fill=color, outline="", tags=tag)
    # «выкусываем» серп кругом цвета фона
    cv.create_oval(cx - r * 0.45, cy - r * 1.18, cx + r * 1.55, cy + r * 0.82,
                   fill=bg, outline="", tags=tag)


def _halo(cv: tk.Canvas, cx: float, cy: float, r: float, color: str, bg: str,
          tag, strength: float = 0.30) -> None:
    """Мягкое свечение вокруг светила для объёмного стиля.

    В Tk нет прозрачности, поэтому свечение — круги, смешанные с цветом фона.
    """
    for share, radius in ((0.55, 1.42), (0.32, 1.22), (0.18, 1.08)):
        cv.create_oval(cx - r * radius, cy - r * radius, cx + r * radius, cy + r * radius,
                       fill=theme.mix(bg, color, strength * share), outline="", tags=tag)


def _cloud(cv: tk.Canvas, cx: float, cy: float, size: float, color: str, tag,
           light: str | None = None) -> None:
    """Облако. light — цвет верхнего слоя: даёт объём в стиле vivid."""
    puffs = ((-0.28, 0.05, 0.21), (0.02, -0.11, 0.27), (0.30, 0.06, 0.19))
    if light:
        # тень-основание: чуть ниже и шире
        for px, py, pr in puffs:
            r = pr * size * 1.03
            cv.create_oval(cx + px * size - r, cy + (py + 0.06) * size - r,
                           cx + px * size + r, cy + (py + 0.06) * size + r,
                           fill=color, outline="", tags=tag)
        cv.create_rectangle(cx - 0.29 * size, cy - 0.02 * size,
                            cx + 0.31 * size, cy + 0.30 * size,
                            fill=color, outline="", tags=tag)
        # освещённая верхушка
        for px, py, pr in puffs:
            r = pr * size * 0.88
            cv.create_oval(cx + px * size - r, cy + (py - 0.07) * size - r,
                           cx + px * size + r, cy + (py - 0.07) * size + r,
                           fill=light, outline="", tags=tag)
        cv.create_rectangle(cx - 0.26 * size, cy - 0.08 * size,
                            cx + 0.28 * size, cy + 0.16 * size,
                            fill=light, outline="", tags=tag)
        return
    for px, py, pr in puffs:
        r = pr * size
        cv.create_oval(cx + px * size - r, cy + py * size - r,
                       cx + px * size + r, cy + py * size + r,
                       fill=color, outline="", tags=tag)
    cv.create_rectangle(cx - 0.28 * size, cy - 0.06 * size,
                        cx + 0.30 * size, cy + 0.25 * size,
                        fill=color, outline="", tags=tag)


def _rain(cv: tk.Canvas, cx: float, cy: float, size: float, color: str,
          count: int, tag, offset_y: float = 0.0, spread: float = 0.32,
          length: float = 0.20, light: str | None = None) -> None:
    width = max(1, int(round(0.05 * size)))
    for index in range(count):
        fraction = (index / (count - 1) - 0.5) if count > 1 else 0.0
        x = cx + fraction * spread * 2 * size
        y = cy + offset_y * size
        cv.create_line(x, y, x - 0.08 * size, y + length * size,
                       fill=color, width=width, capstyle="round", tags=tag)
        if light:
            # блик на верхней части капли
            cv.create_line(x - 0.01 * size, y + 0.04 * size,
                           x - 0.05 * size, y + length * size * 0.55,
                           fill=light, width=max(1, width - 1), capstyle="round",
                           tags=tag)


def _snow(cv: tk.Canvas, cx: float, cy: float, size: float, color: str,
          count: int, tag, offset_y: float = 0.0, spread: float = 0.30) -> None:
    width = max(1, int(round(0.042 * size)))
    r = 0.075 * size
    for index in range(count):
        fraction = (index / (count - 1) - 0.5) if count > 1 else 0.0
        x = cx + fraction * spread * 2 * size
        y = cy + offset_y * size + r
        for angle_deg in (0, 60, 120):
            angle = math.radians(angle_deg)
            dx, dy = math.cos(angle) * r, math.sin(angle) * r
            cv.create_line(x - dx, y - dy, x + dx, y + dy,
                           fill=color, width=width, capstyle="round", tags=tag)


def _bolt(cv: tk.Canvas, cx: float, cy: float, size: float, color: str, tag,
          light: str | None = None) -> None:
    shape = [(0.03, 0.00), (0.17, 0.00), (0.09, 0.18), (0.19, 0.18),
             (-0.03, 0.44), (0.04, 0.22), (-0.05, 0.22)]
    points = []
    for px, py in shape:
        points.extend((cx + px * size, cy + py * size))
    cv.create_polygon(points, fill=color, outline="", tags=tag)
    if light:
        # светящаяся сердцевина молнии
        inner = []
        for px, py in shape:
            inner.extend((cx + px * size * 0.62 + 0.01 * size,
                          cy + py * size * 0.62 + 0.02 * size))
        cv.create_polygon(inner, fill=light, outline="", tags=tag)


def draw_spark(cv: tk.Canvas, cx: float, cy: float, size: float, color: str, tag,
               glow: str | None = None) -> None:
    """Маленький знак-искра: четыре луча с мягкими впадинами.

    Оригинальный знак проекта (не чей-либо товарный знак): отмечает, что
    виджет сделан вместе с ИИ-помощником.
    """
    s = float(size)
    if glow:
        # очень мягкий ореол: на маленьком размере он не должен «пухнуть»
        for share, radius in ((0.16, 1.62), (0.10, 1.24)):
            cv.create_oval(cx - s * radius / 2.0, cy - s * radius / 2.0,
                           cx + s * radius / 2.0, cy + s * radius / 2.0,
                           fill=theme.mix(glow, color, 0.28 * share), outline="",
                           tags=tag)
    points = ((0.0, -0.5), (0.155, -0.155), (0.5, 0.0), (0.155, 0.155),
              (0.0, 0.5), (-0.155, 0.155), (-0.5, 0.0), (-0.155, -0.155))
    flat = []
    for px, py in points:
        flat.extend((cx + px * s, cy + py * s))
    cv.create_polygon(flat, fill=color, outline="", smooth=False, tags=tag)


def draw_moon(cv: tk.Canvas, cx: float, cy: float, size: float, kind: str, color: str,
              bg: str, tag) -> None:
    """Крошечный значок фазы Луны: круг и «затмевающий» круг цветом фона.

    У Tk нет масок, поэтому неосвещённую часть закрываем кругом цвета фона
    в этом месте — на градиенте это выглядит правильно.
    """
    radius = float(size) / 2.0
    box = (cx - radius, cy - radius, cx + radius, cy + radius)
    if kind == "full":
        cv.create_oval(*box, fill=color, outline="", tags=tag)
        return
    if kind == "new":
        cv.create_oval(*box, fill="", outline=color, width=1, tags=tag)
        return
    # растущая — светлая правая часть, убывающая — левая
    cv.create_oval(*box, fill=color, outline="", tags=tag)
    shift = radius * 0.75
    offset = -shift if kind == "waxing" else shift
    cv.create_oval(cx - radius + offset, cy - radius, cx + radius + offset, cy + radius,
                   fill=bg, outline="", tags=tag)


def _fog_lines(cv: tk.Canvas, cx: float, cy: float, size: float, color: str, tag) -> None:
    width = max(1, int(round(0.055 * size)))
    for index, (offset_y, half) in enumerate(((0.20, 0.30), (0.33, 0.36), (0.46, 0.24))):
        y = cy + offset_y * size
        cv.create_line(cx - half * size, y, cx + half * size, y,
                       fill=color, width=width, capstyle="round", tags=tag)


# --------------------------------------------------------------------------- иконки

def draw_icon(cv: tk.Canvas, x: float, y: float, size: float, kind: str,
              bg: str = DEFAULT_BG, tag="icon") -> None:
    """Нарисовать иконку в квадрате (x, y, x+size, y+size)."""
    if size <= 2:
        return
    cx, cy = x + size / 2.0, y + size / 2.0
    s = float(size)
    sun, moon = color("sun"), color("moon")
    cloud, dark, deep = color("cloud"), color("cloud_dark"), color("cloud_deep")
    # объёмный стиль: свечение вокруг светил, двухслойные облака, блики на каплях
    vivid = _STYLE == "vivid"
    top = theme.mix(cloud, "#ffffff", 0.55) if vivid else None
    spark = theme.mix(color("rain"), "#ffffff", 0.45) if vivid else None
    flake = theme.mix(color("snow"), "#ffffff", 0.5) if vivid else None

    if kind == "clear":
        if vivid:
            _halo(cv, cx, cy, 0.26 * s, sun, bg, tag)
        _sun(cv, cx, cy, 0.26 * s, sun, tag)
    elif kind == "clear-night":
        if vivid:
            _halo(cv, cx, cy, 0.28 * s, moon, bg, tag, 0.20)
        _moon(cv, cx, cy, 0.28 * s, moon, bg, tag)
    elif kind == "partly":
        if vivid:
            _halo(cv, cx - 0.15 * s, cy - 0.16 * s, 0.185 * s, sun, bg, tag)
        _sun(cv, cx - 0.15 * s, cy - 0.16 * s, 0.185 * s, sun, tag)
        _cloud(cv, cx + 0.07 * s, cy + 0.09 * s, 0.78 * s, cloud, tag, light=top)
    elif kind == "partly-night":
        if vivid:
            _halo(cv, cx - 0.16 * s, cy - 0.17 * s, 0.195 * s, moon, bg, tag, 0.18)
        _moon(cv, cx - 0.16 * s, cy - 0.17 * s, 0.195 * s, moon, bg, tag)
        _cloud(cv, cx + 0.07 * s, cy + 0.09 * s, 0.78 * s, cloud, tag, light=top)
    elif kind == "cloudy":
        _cloud(cv, cx + 0.08 * s, cy - 0.03 * s, 0.78 * s, dark, tag, light=top)
        _cloud(cv, cx - 0.02 * s, cy + 0.10 * s, 0.85 * s, cloud, tag, light=top)
    elif kind == "overcast":
        _cloud(cv, cx + 0.09 * s, cy - 0.10 * s, 0.76 * s, deep, tag, light=dark if vivid else None)
        _cloud(cv, cx - 0.03 * s, cy + 0.06 * s, 0.88 * s, dark, tag, light=top)
    elif kind == "fog":
        _cloud(cv, cx, cy - 0.14 * s, 0.78 * s, cloud, tag, light=top)
        _fog_lines(cv, cx, cy, s, color("fog"), tag)
    elif kind == "drizzle":
        _cloud(cv, cx, cy - 0.14 * s, 0.78 * s, cloud, tag, light=top)
        _rain(cv, cx, cy, s, color("rain"), 3, tag, offset_y=0.14, length=0.11,
              light=spark)
    elif kind == "rain":
        _cloud(cv, cx, cy - 0.14 * s, 0.78 * s, cloud, tag, light=top)
        _rain(cv, cx, cy, s, color("rain"), 3, tag, offset_y=0.13, light=spark)
    elif kind == "rain-heavy":
        _cloud(cv, cx, cy - 0.16 * s, 0.78 * s, dark, tag, light=top)
        _rain(cv, cx, cy, s, color("rain"), 4, tag, offset_y=0.12, length=0.24,
              light=spark)
        _rain(cv, cx, cy, s, color("rain"), 3, tag, offset_y=0.30, length=0.14,
              spread=0.22, light=spark)
    elif kind == "snow":
        _cloud(cv, cx, cy - 0.14 * s, 0.78 * s, cloud, tag, light=top)
        _snow(cv, cx, cy, s, color("snow"), 3, tag, offset_y=0.13)
    elif kind == "sleet":
        _cloud(cv, cx, cy - 0.14 * s, 0.78 * s, cloud, tag, light=top)
        _rain(cv, cx - 0.15 * s, cy, s * 0.7, color("rain"), 2, tag, offset_y=0.16,
              spread=0.20, light=spark)
        _snow(cv, cx + 0.20 * s, cy, s, color("snow"), 1, tag, offset_y=0.12)
    elif kind == "thunder":
        _cloud(cv, cx, cy - 0.16 * s, 0.80 * s, dark, tag, light=top)
        _bolt(cv, cx, cy, s, color("lightning"), tag, light=flake if vivid else None)
    elif kind in ("sunrise", "sunset"):
        warm = kind == "sunset"
        sun_color = color("sun_warm") if warm else color("sun")
        horizon = cy + 0.18 * s
        _sun(cv, cx, horizon, 0.24 * s, sun_color, tag)
        # прячем нижнюю половину солнца «под горизонт»
        cv.create_rectangle(cx - 0.55 * s, horizon, cx + 0.55 * s, cy + 0.55 * s,
                            fill=bg, outline="", tags=tag)
        cv.create_line(cx - 0.46 * s, horizon, cx + 0.46 * s, horizon,
                       fill=color("cloud_dark"), width=max(1, int(0.035 * s)),
                       capstyle="round", tags=tag)
    elif kind == "sun":
        _sun(cv, cx, cy, 0.26 * s, sun, tag)
    elif kind == "moon":
        _moon(cv, cx, cy, 0.28 * s, moon, bg, tag)
    else:
        _cloud(cv, cx, cy, 0.80 * s, cloud, tag)


# --------------------------------------------------------------------------- фон

def rounded_points(x0: float, y0: float, x1: float, y1: float, r: float) -> list[float]:
    r = max(0.0, min(r, (x1 - x0) / 2.0, (y1 - y0) / 2.0))
    return [
        x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r,
        x1, y1 - r, x1, y1, x1 - r, y1, x0 + r, y1,
        x0, y1, x0, y1 - r, x0, y0 + r, x0, y0,
    ]


def _corner_inset(y: float, height: float, radius: float) -> float:
    if radius <= 0:
        return 0.0
    if y < radius:
        delta = radius - y
    elif y > height - radius:
        delta = y - (height - radius)
    else:
        return 0.0
    return radius - math.sqrt(max(0.0, radius * radius - delta * delta))


def draw_background(cv: tk.Canvas, w: int, h: int, pal: dict, radius: float = 0.0,
                    tag="bg", top: str | None = None, bottom: str | None = None,
                    stripes: int | None = None) -> None:
    """Вертикальный градиент подложки со скруглёнными углами.

    Контур (обводка) не рисуется: подложка полупрозрачная, рамка ей не нужна.
    Цвета можно переопределить (top/bottom), иначе берутся из темы времени дня.
    stripes — сколько полос рисовать (меньше полос = быстрее, для анимации).
    """
    top_color = top or pal["bg_top"]
    bottom_color = bottom or pal["bg_bottom"]
    # по умолчанию полосы высотой 1 пиксель: тогда скругление углов получается
    # ровным кругом, а не «лесенкой» из крупных ступеней
    steps = stripes if stripes else max(60, min(900, int(round(h))))
    steps = max(12, int(steps))
    step = h / float(steps)
    for index in range(steps):
        y0 = index * step
        y1 = y0 + step + 0.9
        color = theme.lerp(top_color, bottom_color, index / float(max(1, steps - 1)))
        inset = _corner_inset(y0 + step / 2.0, h, radius)
        cv.create_rectangle(inset, y0, w - inset, y1,
                            fill=color, outline=color, width=0, tags=tag)


def bg_at(pal: dict, h: int, y: float) -> str:
    """Цвет фона в точке y — нужен иконкам, которые «вырезают» часть себя."""
    if h <= 0:
        return pal["bg_top"]
    return theme.gradient_at(pal, max(0.0, min(1.0, y / float(h))))

