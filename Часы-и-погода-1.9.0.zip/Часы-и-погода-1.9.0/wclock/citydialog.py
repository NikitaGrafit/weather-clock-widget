# -*- coding: utf-8 -*-
"""Диалог выбора города: поиск в геокодере, популярные города, определение по IP.

Окно построено на общей основе (`dialog.ModernDialog`) — без системной рамки,
со скруглением и в цветах виджета.
"""

from __future__ import annotations

import queue
import threading
import tkinter as tk

from . import api, texts
from .dialog import ModernDialog
from .widgets import FlatButton

DIALOG_WIDTH, DIALOG_HEIGHT = 520, 560
POLL_INTERVAL_MS = 200


def ask_city(parent: tk.Misc, current: api.City | None = None,
             frameless: bool = False, palette: dict | None = None) -> api.City | None:
    """Показать диалог выбора города. Возвращает выбранный City или None."""
    dialog = ModernDialog(parent, texts.t("city.title"), palette)
    panel, text_color = dialog.panel, dialog.text_color
    muted, accent, divider = dialog.muted, dialog.accent, dialog.divider
    base = dialog.palette.get("bg_top", "#0d1729")
    body = dialog.body

    result: dict = {"city": None}
    state: dict = {"cities": [], "queue": queue.Queue(), "seq": 0, "alive": True}

    # ---------------------------------------------------------------- виджеты
    top = tk.Frame(body, bg=panel)
    top.pack(fill="x")
    tk.Label(top, text=texts.t("city.label"), bg=panel, fg=muted,
             font=("Segoe UI", 10)).pack(side="left")
    entry_var = tk.StringVar(value=current.name if current else "")
    entry = tk.Entry(top, textvariable=entry_var, font=("Segoe UI", 11),
                     bg=base, fg=text_color, insertbackground=accent,
                     relief="flat", highlightthickness=1, highlightbackground=divider,
                     highlightcolor=accent)
    entry.pack(side="left", fill="x", expand=True, padx=(8, 8), ipady=3)
    search_button = FlatButton(top, texts.t("city.search"), None,
                               palette=_button_palette(dialog), width=88, height=30)
    search_button.pack(side="left")

    list_frame = tk.Frame(body, bg=panel)
    list_frame.pack(fill="both", expand=True, pady=(10, 6))
    scrollbar = tk.Scrollbar(list_frame, orient="vertical", width=14, bd=0,
                             troughcolor=panel, bg=divider, activebackground=accent,
                             highlightthickness=0)
    listbox = tk.Listbox(list_frame, font=("Segoe UI", 11), activestyle="none",
                         yscrollcommand=scrollbar.set, selectmode="browse",
                         bg=base, fg=text_color, selectbackground=accent,
                         selectforeground=base, highlightthickness=1,
                         highlightbackground=divider, relief="flat", bd=0,
                         height=12)
    scrollbar.config(command=listbox.yview)
    scrollbar.pack(side="right", fill="y")
    listbox.pack(side="left", fill="both", expand=True)

    status_var = tk.StringVar(value="")
    tk.Label(body, textvariable=status_var, bg=panel, fg=muted, font=("Segoe UI", 9),
             anchor="w", justify="left", wraplength=DIALOG_WIDTH - 60,
             height=2).pack(fill="x")

    bottom = tk.Frame(body, bg=panel)
    bottom.pack(fill="x", pady=(8, 0))

    # ---------------------------------------------------------------- логика
    def fill(cities: list[api.City], status: str) -> None:
        state["cities"] = cities
        listbox.delete(0, "end")
        for city in cities:
            suffix = (f"  ({city.population:,} чел.)".replace(",", " ")
                      if city.population else "")
            listbox.insert("end", city.label() + suffix)
        status_var.set(status)
        if cities:
            listbox.selection_clear(0, "end")
            listbox.selection_set(0)
            listbox.activate(0)

    def choose(*_args) -> None:
        selection = listbox.curselection()
        if not selection:
            status_var.set(texts.t("city.pick_first"))
            return
        index = selection[0]
        if 0 <= index < len(state["cities"]):
            result["city"] = state["cities"][index]
            close()

    def close() -> None:
        state["alive"] = False
        dialog.close()

    def start_search(*_args) -> None:
        query = entry_var.get().strip()
        if not query:
            status_var.set(texts.t("city.enter_name"))
            return
        state["seq"] += 1
        status_var.set(texts.t("city.searching", query=query))
        threading.Thread(target=search_worker, args=(query, state["seq"]),
                         daemon=True).start()

    def search_worker(query: str, seq: int) -> None:
        try:
            cities = api.search_cities(query, count=20)
            message = (texts.t("city.found", count=len(cities)) if cities
                       else texts.t("city.nothing"))
            state["queue"].put((seq, {"cities": cities, "status": message}))
        except Exception as exc:            # noqa: BLE001 — сеть бывает разной
            state["queue"].put((seq, {"cities": [],
                                      "status": texts.t("city.search_error", error=exc)}))

    def detect_ip() -> None:
        status_var.set(texts.t("city.detecting"))

        def worker() -> None:
            try:
                city = api.locate_by_ip()
                state["queue"].put(("ip", {
                    "cities": [city],
                    "status": texts.t("city.detected_ip", city=city.label()),
                }))
            except Exception as exc:        # noqa: BLE001
                state["queue"].put(("ip", {"cities": [],
                                           "status": texts.t("city.failed", error=exc)}))

        threading.Thread(target=worker, daemon=True).start()

    def poll() -> None:
        if not state["alive"]:
            return
        while True:
            try:
                tag, payload = state["queue"].get_nowait()
            except queue.Empty:
                break
            if tag == "ip" or tag == state["seq"]:
                fill(payload["cities"], payload["status"])
        try:
            dialog.window.after(POLL_INTERVAL_MS, poll)
        except tk.TclError:
            pass

    search_button.command = start_search
    search_button.bind("<ButtonRelease-1>", lambda event: start_search(), add="+")

    button_palette = _button_palette(dialog)
    FlatButton(bottom, texts.t("city.detect"), detect_ip, palette=button_palette,
               width=186, height=34).pack(side="left")
    FlatButton(bottom, texts.t("city.choose"), choose, palette=button_palette,
               width=118, height=34).pack(side="right")
    FlatButton(bottom, texts.t("city.cancel"), close, palette=button_palette,
               width=102, height=34).pack(side="right", padx=8)

    listbox.bind("<Double-Button-1>", choose)
    listbox.bind("<Return>", choose)
    entry.bind("<Return>", start_search)
    dialog.window.bind("<Escape>", lambda event: close())

    if current:
        fill([current], texts.t("city.current", city=current.label()))
    else:
        fill(list(api.POPULAR_CITIES), texts.t("city.popular"))
    if current and current.name:
        start_search()

    dialog.fit(DIALOG_WIDTH)
    dialog.show()
    entry.focus_set()
    dialog.window.after(POLL_INTERVAL_MS, poll)
    dialog.wait()
    return result["city"]


def _button_palette(dialog: ModernDialog) -> dict:
    return {
        "panel": dialog.palette.get("bg_top", "#0d1729"),
        "border": dialog.divider,
        "accent": dialog.accent,
        "bg_top": dialog.panel,
        "text": dialog.text_color,
        "button_font": ("Segoe UI", 10),
    }
