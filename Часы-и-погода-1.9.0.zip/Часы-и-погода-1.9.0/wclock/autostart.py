# -*- coding: utf-8 -*-
"""Автозапуск виджета при входе пользователя в систему.

В папку «Автозагрузка» кладётся маленький .vbs-файл, который запускает
виджет без окна консоли. Файл пишется в UTF-16: так Windows Script Host
корректно читает пути с кириллицей (например, «Часы и погода»).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

LAUNCHER_NAME = "WeatherClockWidget.vbs"
STARTUP_RELATIVE = Path("Microsoft/Windows/Start Menu/Programs/Startup")


def startup_dir() -> Path:
    """Папка «Автозагрузка» текущего пользователя."""
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / "AppData/Roaming"
    return base / STARTUP_RELATIVE


def launcher_path(directory: Path | str | None = None) -> Path:
    return (Path(directory) if directory else startup_dir()) / LAUNCHER_NAME


def widget_script() -> Path:
    """Путь к weather_widget.py (на уровень выше пакета wclock)."""
    return Path(__file__).resolve().parent.parent / "weather_widget.py"


def pythonw_path() -> str:
    """Интерпретатор без консоли: pythonw рядом с текущим python."""
    executable = Path(sys.executable)
    candidates = []
    if executable.name.lower() == "pythonw.exe":
        candidates.append(executable)
    else:
        candidates.append(executable.with_name("pythonw.exe"))
    candidates.append(executable.parent / "pythonw.exe")
    local = os.environ.get("LOCALAPPDATA")
    if local:
        for version in ("Python313", "Python312", "Python311", "Python310"):
            candidates.append(Path(local) / "Programs" / "Python" / version / "pythonw.exe")
    for candidate in candidates:
        try:
            if candidate.is_file():
                return str(candidate)
        except OSError:
            continue
    return "pythonw.exe"      # подхватится из PATH


def launcher_content(script: Path | None = None, interpreter: str | None = None) -> str:
    """Содержимое .vbs-запускателя."""
    target = Path(script) if script else widget_script()
    python = interpreter or pythonw_path()
    return (
        "' Weather Clock Widget - autostart on user logon\r\n"
        "Option Explicit\r\n"
        "Dim shell\r\n"
        "Set shell = CreateObject(\"WScript.Shell\")\r\n"
        f'shell.CurrentDirectory = "{target.parent}"\r\n'
        f'shell.Run """{python}"" ""{target}""", 0, False\r\n'
    )


def is_enabled(directory: Path | str | None = None) -> bool:
    try:
        return launcher_path(directory).is_file()
    except OSError:
        return False


def enable(directory: Path | str | None = None, script: Path | None = None,
           interpreter: str | None = None) -> Path:
    """Включить автозапуск. Возвращает путь созданного файла."""
    path = launcher_path(directory)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = launcher_content(script, interpreter)
    # utf-16 (с BOM) — WSH читает такой файл как Unicode
    with open(path, "w", encoding="utf-16", newline="") as handle:
        handle.write(content)
    return path


def disable(directory: Path | str | None = None) -> bool:
    """Выключить автозапуск. True, если файл был и его удалили."""
    path = launcher_path(directory)
    try:
        if path.is_file():
            path.unlink()
            return True
    except OSError:
        return False
    return False
