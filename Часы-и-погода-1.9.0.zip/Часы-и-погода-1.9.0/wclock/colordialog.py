# -*- coding: utf-8 -*-
"""Диалог настройки цвета фона виджета в формате RGB.

Окно построено на общей основе (`dialog.ModernDialog`): без системной
рамки, со скруглением, в тёмных цветах виджета — как меню и справка.
"""

from __future__ import annotations

import tkinter as tk

from . import texts, theme
from .dialog import ModernDialog
from .widgets import FlatButton

WRAP = 460


def ask_plate_colors(parent: tk.Misc, top: str | None, bottom: str | None,
                     default_top: str, default_bottom: str,
                     palette: dict | None = None):
    """Диалог RGB-настройки фона.

    Возвращает (верх, низ) со значениями «#RRGGBB» или None (цвет из темы).
    Возвращает None, если пользователь отказался.
    """
    dialog = ModernDialog(parent, texts.t("color.title"), palette)
    panel, text_color = dialog.panel, dialog.text_color
    muted, accent, divider = dialog.muted, dialog.accent, dialog.divider
    base = dialog.palette.get("bg_top", "#0d1729")
    body = dialog.body

    result: dict = {"value": None}
    start_top = theme.valid_color(top) or default_top
    start_bottom = theme.valid_color(bottom) or default_bottom

    tk.Label(body, text=texts.t("color.heading"), bg=panel, fg=text_color,
             font=("Segoe UI", 11, "bold"), anchor="w").pack(fill="x")
    tk.Label(body, text=texts.t("color.hint"), bg=panel, fg=muted,
             font=("Segoe UI", 9), anchor="w", justify="left",
             wraplength=WRAP).pack(fill="x", pady=(4, 10))

    preview = tk.Canvas(body, height=64, bg=panel, highlightthickness=1,
                        highlightbackground=divider)
    preview.pack(fill="x", pady=(0, 12))

    scales: dict[str, list[tk.Scale]] = {"top": [], "bottom": []}
    swatches: dict[str, int] = {}
    hex_labels: dict[str, tk.Label] = {}

    def rgb_of(group: str) -> tuple[int, int, int]:
        return tuple(int(scale.get()) for scale in scales[group])  # type: ignore[return-value]

    def hex_of(group: str) -> str:
        return theme.rgb_to_hex(rgb_of(group))

    def redraw(*_args) -> None:
        top_hex, bottom_hex = hex_of("top"), hex_of("bottom")
        for group, color in (("top", top_hex), ("bottom", bottom_hex)):
            preview.itemconfigure(swatches[group], fill=color)
            hex_labels[group].configure(text=color.upper())
        width = max(40, preview.winfo_width())
        height = 64
        steps = 64
        preview.delete("grad")
        for index in range(steps):
            y0 = index * height / steps
            color = theme.lerp(top_hex, bottom_hex, index / (steps - 1))
            preview.create_rectangle(0, y0, width, y0 + height / steps + 1,
                                     fill=color, outline=color, tags="grad")
        preview.tag_lower("grad")

    def make_group(title: str, group: str, start_color: str) -> None:
        card = tk.Frame(body, bg=base)
        card.pack(fill="x", pady=(0, 10))
        tk.Label(card, text=title, bg=base, fg=muted, font=("Segoe UI", 10, "bold"),
                 anchor="w").pack(fill="x", padx=12, pady=(8, 2))
        start_rgb = theme.hex_to_rgb(start_color)
        for name, value in zip(("R", "G", "B"), start_rgb):
            row = tk.Frame(card, bg=base)
            row.pack(fill="x", padx=12)
            tk.Label(row, text=name, width=2, bg=base, fg=text_color,
                     font=("Consolas", 11), anchor="w").pack(side="left")
            scale = tk.Scale(row, from_=0, to=255, orient="horizontal", length=320,
                             resolution=1, bg=base, fg=muted, highlightthickness=0,
                             troughcolor=divider, activebackground=accent,
                             bd=0, sliderrelief="flat", command=redraw)
            scale.set(value)
            scale.pack(side="left", fill="x", expand=True, padx=(4, 8))
            scales[group].append(scale)
        bottom_row = tk.Frame(card, bg=base)
        bottom_row.pack(fill="x", padx=12, pady=(6, 10))
        swatch = tk.Canvas(bottom_row, width=48, height=20, highlightthickness=1,
                           highlightbackground=divider, bg=base)
        swatch.pack(side="left")
        swatches[group] = swatch.create_rectangle(0, 0, 48, 20, fill=start_color,
                                                  outline="")
        label = tk.Label(bottom_row, text=start_color.upper(), bg=base,
                         font=("Consolas", 10), fg=text_color)
        label.pack(side="left", padx=8)
        hex_labels[group] = label

    make_group(texts.t("color.top"), "top", start_top)
    make_group(texts.t("color.bottom"), "bottom", start_bottom)

    def copy_top_to_bottom() -> None:
        for scale, value in zip(scales["bottom"], rgb_of("top")):
            scale.set(value)
        redraw()

    def reset_to_theme() -> None:
        result["value"] = (None, None)
        dialog.close()

    def apply() -> None:
        result["value"] = (hex_of("top"), hex_of("bottom"))
        dialog.close()

    button_palette = dict(dialog.palette)
    button_palette.update({"panel": base, "border": divider, "accent": accent,
                           "bg_top": panel, "text": text_color,
                           "button_font": ("Segoe UI", 9)})
    buttons = tk.Frame(body, bg=panel)
    buttons.pack(fill="x", pady=(4, 0))
    FlatButton(buttons, texts.t("color.copy"), copy_top_to_bottom,
               palette=button_palette, width=196, height=34).pack(side="left")
    FlatButton(buttons, texts.t("color.theme"), reset_to_theme,
               palette=button_palette, width=118, height=34).pack(side="left", padx=8)
    FlatButton(buttons, texts.t("color.apply"), apply,
               palette=button_palette, width=118, height=34).pack(side="right")
    FlatButton(buttons, texts.t("color.cancel"), dialog.close,
               palette=button_palette, width=102, height=34).pack(side="right", padx=8)

    dialog.fit()   # ширина по самому широкому элементу
    dialog.show()
    redraw()
    dialog.body.update_idletasks()
    redraw()
    dialog.wait()
    return result["value"]
