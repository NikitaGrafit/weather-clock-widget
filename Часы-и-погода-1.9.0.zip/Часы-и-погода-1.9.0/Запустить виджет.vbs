' Weather Clock Widget launcher (no console window).
' Double-click this file to show the widget on the desktop.
' NOTE: keep this file ASCII-only, Windows Script Host reads .vbs in ANSI.
Option Explicit

Dim shell, fso, base, candidates, i, pythonw, cmd
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = base

candidates = Array( _
    "C:\Users\konog\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\pythonw.exe", _
    shell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe"), _
    shell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"), _
    shell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe"), _
    shell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\Python\Python310\pythonw.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python313\pythonw.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python312\pythonw.exe"), _
    "pythonw.exe")

pythonw = ""
For i = 0 To UBound(candidates)
    If candidates(i) = "pythonw.exe" Then
        pythonw = candidates(i)
        Exit For
    ElseIf fso.FileExists(candidates(i)) Then
        pythonw = candidates(i)
        Exit For
    End If
Next

If pythonw = "" Then
    MsgBox "pythonw.exe not found. Install Python 3 and run: python weather_widget.py", 48, "Weather Clock"
    WScript.Quit 1
End If

cmd = """" & pythonw & """ """ & base & "\weather_widget.py"""
shell.Run cmd, 0, False
