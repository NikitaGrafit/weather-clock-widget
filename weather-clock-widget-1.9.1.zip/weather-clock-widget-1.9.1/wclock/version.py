# -*- coding: utf-8 -*-
"""Версия виджета и правила её изменения.

Версия хранится в одном месте — здесь. При каждой правке она поднимается
по правилам семантического версионирования (major.minor.patch):

* **major** (1.0.0 → 2.0.0) — несовместимые и крупные изменения: другая
  структура окна, смена способа отрисовки, удаление возможностей;
* **minor** (1.0.0 → 1.1.0) — новая возможность: пункт меню, блок с данными,
  язык, формат, стиль оформления;
* **patch** (1.0.0 → 1.0.1) — исправление ошибки или правка вида без новой
  возможности.
"""

from __future__ import annotations

NAME = "Часы и погода"
VERSION = "1.9.1"
RELEASED = "2026"
AUTHOR_IDEA = "Никита Коногин"
AUTHOR_CODE = "DeepSeek Harness"


def parts() -> tuple[int, int, int]:
    """Версия по частям: (major, minor, patch)."""
    try:
        major, minor, patch = (int(piece) for piece in VERSION.split("."))
    except ValueError:
        return 1, 0, 0
    return major, minor, patch


def version_text() -> str:
    return f"v{VERSION}"


def bump(kind: str) -> str:
    """Следующая версия по типу изменения: major | minor | patch."""
    major, minor, patch = parts()
    if kind == "major":
        return f"{major + 1}.0.0"
    if kind == "minor":
        return f"{major}.{minor + 1}.0"
    return f"{major}.{minor}.{patch + 1}"
