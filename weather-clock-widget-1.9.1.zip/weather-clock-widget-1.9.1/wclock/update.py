# -*- coding: utf-8 -*-
"""Проверка обновлений: тихая, без самовольной установки.

Виджет раз в сутки (и при запуске) спрашивает маленький файл `latest.json`,
который лежит рядом с архивом новой версии. Если версия новее — показываем
аккуратное уведомление и список изменений; ничего не скачиваем и не ставим
без согласия человека.

Любая ошибка (нет сети, нет файла, мусор в ответе) означает «обновлений нет»:
в интерфейсе не должно появляться ни одной ошибки из-за проверки.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field

# Адрес файла с описанием последней версии. Лежит в корне репозитория,
# поэтому читается напрямую с raw.githubusercontent.com — без токенов и API.
DEFAULT_FEED = ("https://raw.githubusercontent.com/NikitaGrafit/"
                "weather-clock-widget/main/latest.json")

REQUEST_TIMEOUT = 6.0
USER_AGENT = "WeatherClockWidget"

# Имя файла рядом с настройками: в нём можно задать адрес описания версий,
# не трогая код — удобно, если репозиторий переедет.
FEED_FILE = "update_url.txt"


def feed_url(base_dir=None) -> str:
    """Адрес описания версий: сначала файл рядом с настройками, потом константа."""
    if base_dir:
        try:
            from pathlib import Path

            path = Path(base_dir) / FEED_FILE
            if path.exists():
                text = path.read_text(encoding="utf-8").strip()
                if text.startswith("http"):
                    return text
        except OSError:
            pass
    return DEFAULT_FEED


@dataclass
class Update:
    """Что известно о новой версии."""

    version: str = ""
    notes: list = field(default_factory=list)
    url: str = ""
    sha256: str = ""
    size: int = 0
    required: bool = False

    def size_text(self) -> str:
        if not self.size:
            return ""
        megabytes = self.size / (1024 * 1024)
        if megabytes < 1:
            return f"{self.size / 1024:.0f} КБ"
        return f"{megabytes:.1f} МБ"


def parse_version(text: str) -> tuple:
    """«1.8.3» или «v1.8.3» → (1, 8, 3). Мусор → (0, 0, 0)."""
    numbers = re.findall(r"\d+", str(text or ""))
    if not numbers:
        return (0, 0, 0)
    parts = [int(value) for value in numbers[:3]]
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)          # type: ignore[return-value]


def is_newer(candidate: str, current: str) -> bool:
    """Свежее ли предлагаемая версия текущей."""
    return parse_version(candidate) > parse_version(current)


def notes_from_changelog(text: str, version: str = "", limit: int = 8) -> list:
    """Взять из журнала строки про нужную версию — это и есть «что нового».

    Журнал у нас в виде таблицы: | **1.8.3** | 2026 | patch | описание |
    """
    notes: list = []
    for line in (text or "").splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) < 3 or set(cells[0]) <= set("-: "):
            continue
        header = cells[0]
        if version and version not in header:
            continue
        description = cells[-1].strip()
        if description and not description.startswith("Что сделано"):
            notes.append(description)
        if len(notes) >= limit:
            break
    return notes


def parse_feed(payload: str, current_version: str) -> Update | None:
    """Разобрать ответ сервера. None — если обновляться не нужно или ответ плохой."""
    try:
        data = json.loads(payload)
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict):
        return None
    latest = str(data.get("version") or "").strip()
    if not latest or not is_newer(latest, current_version):
        return None
    notes = data.get("notes")
    if isinstance(notes, str):
        notes = [line.strip() for line in notes.splitlines() if line.strip()]
    if not isinstance(notes, list):
        notes = []
    return Update(
        version=latest,
        notes=[str(note) for note in notes][:8],
        url=str(data.get("url") or "").strip(),
        sha256=str(data.get("sha256") or "").strip().lower(),
        size=int(data.get("size") or 0),
        required=bool(data.get("required")),
    )


def safe_url(url: str) -> str:
    """Привести ссылку к виду, который принимает urllib.

    В именах файлов бывает кириллица («Часы-и-погода-1.9.0.zip»), а urllib
    умеет работать только с латинскими символами — без этого скачивание
    падало с ошибкой кодировки.
    """
    if not url:
        return ""
    try:
        from urllib.parse import quote, urlsplit, urlunsplit

        parts = urlsplit(url.strip())
        return urlunsplit((parts.scheme, parts.netloc,
                           quote(parts.path, safe="/%"), parts.query,
                           parts.fragment))
    except (ValueError, AttributeError):
        return url.strip()


def fetch_latest(url: str = "", current_version: str = "",
                 timeout: float = REQUEST_TIMEOUT) -> Update | None:
    """Спросить сервер о новой версии. Любая ошибка — просто None."""
    feed = safe_url(url or DEFAULT_FEED)
    if not feed:
        return None
    request = urllib.request.Request(feed, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = response.read().decode("utf-8", errors="replace")
    except (urllib.error.URLError, OSError, ValueError):
        return None
    return parse_feed(payload, current_version)
